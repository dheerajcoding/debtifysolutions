import { useEffect, useState } from "react";
import { api } from "../lib/api.js";
import { usd } from "../lib/format.js";

// Admin dashboard: KPIs, compliance clarity, funnel, drop-offs, backends, exception desk, recent sessions.
export default function Admin() {
  const [samples, setSamples] = useState(true);
  const [d, setD] = useState(null);
  const [err, setErr] = useState(null);

  useEffect(() => {
    let alive = true;
    const load = () => api.stats(samples).then((r) => alive && (setD(r), setErr(null))).catch((e) => alive && setErr(e.message));
    load();
    const t = setInterval(load, 4000);
    return () => { alive = false; clearInterval(t); };
  }, [samples]);

  if (err && !d) return <p className="alert">Could not load stats: {err}</p>;
  if (!d) return <p className="small">Loading…</p>;
  const k = d.kpis;
  const top = k.leads || 1;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div className="toolbar">
        <h1 style={{ fontSize: 22 }}>Admin · last 30 days</h1>
        <label className="toggle">
          <input type="checkbox" checked={samples} onChange={(e) => setSamples(e.target.checked)} /> Include sample data ({d.sampleCount || 180} example leads)
        </label>
      </div>
      <p className="small">
        {d.store === "mongodb" ? "MongoDB" : "In-memory store"}: {d.demoCount} real session{d.demoCount === 1 ? "" : "s"} from this app. Refreshes every few seconds.
      </p>
      <div className="kpis">
        <div className="kpi"><div className="v">{k.leads}</div><div className="k">Leads</div></div>
        <div className="kpi"><div className="v">{k.enrolled}</div><div className="k">Enrolled</div></div>
        <div className="kpi"><div className="v">{k.conversion}%</div><div className="k">Lead to enrolled</div></div>
        <div className="kpi"><div className="v">{usd(k.feesEarned)}</div><div className="k">Fees earned</div></div>
        <div className="kpi"><div className="v">{k.clawbackRate}%</div><div className="k">Clawback rate</div></div>
        <div className="kpi"><div className="v">{k.spanishShare}%</div><div className="k">Sessions in Spanish</div></div>
      </div>

      <div className="panel">
        <h3>Compliance clarity: how people rated each point</h3>
        <p className="small">Every disclosure and risk has a "Clear / Explain simpler" answer. A high "explain simpler" share means the wording needs work before launch.</p>
        <div className="tbl">
          <table>
            <thead><tr><th>Point</th><th className="r">Answers</th><th className="r">Clear</th><th className="r">Explain simpler</th><th style={{ width: "30%" }}>Split</th></tr></thead>
            <tbody>
              {d.clarity.map((r) => (
                <tr key={r.id}>
                  <td>{r.name}</td>
                  <td className="r">{r.n}</td>
                  <td className="r">{r.n ? Math.round((r.clear / r.n) * 100) : 0}%</td>
                  <td className="r">
                    {r.n ? Math.round((r.simpler / r.n) * 100) : 0}%{r.n && r.simpler / r.n > 0.25 ? <> <span className="chip c-warn">Review wording</span></> : null}
                  </td>
                  <td>
                    <div className="split">
                      {r.n ? (<><i className="ok" style={{ width: `${(r.clear / r.n) * 100}%` }} /><i className="no" style={{ width: `${(r.simpler / r.n) * 100}%` }} /></>) : null}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="panel">
        <h3>Funnel by screen (furthest step reached)</h3>
        <div className="tbl">
          <table>
            <thead><tr><th>Step</th><th>Screen</th><th className="r">Leads</th><th style={{ width: "45%" }}>Share of starts</th></tr></thead>
            <tbody>
              {d.funnel.map((f) => (
                <tr key={f.step}><td>{f.step}</td><td>{f.name}</td><td className="r">{f.count}</td><td><div className="fbar" style={{ width: `${(f.count / top) * 100}%` }} /></td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="cols">
        <div className="panel">
          <h3>Drop-off reasons</h3>
          <div className="tbl">
            <table>
              <thead><tr><th>Reason</th><th>Code</th><th className="r">Leads</th></tr></thead>
              <tbody>
                {d.dropReasons.length ? d.dropReasons.map((r) => (
                  <tr key={r.code}><td>{r.label}</td><td className="small">{r.code}</td><td className="r">{r.count}</td></tr>
                )) : <tr><td colSpan={3} className="small">No drop-offs yet.</td></tr>}
              </tbody>
            </table>
          </div>
          <p className="small">{d.resaleEligible} consented drop-offs are eligible for resale with their reason code. Failed ID checks are never resold.</p>
        </div>
        <div className="panel">
          <h3>By backend</h3>
          <div className="tbl">
            <table>
              <thead><tr><th>Backend</th><th className="r">Enrolled</th><th className="r">P1 cleared</th><th className="r">Clawbacks</th></tr></thead>
              <tbody>
                {d.byBackend.length ? d.byBackend.map((b) => (
                  <tr key={b.id}><td>{b.name}</td><td className="r">{b.enrolled}</td><td className="r">{b.p1}</td><td className="r">{b.clawbacks}</td></tr>
                )) : <tr><td colSpan={4} className="small">No enrollments yet.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="panel">
        <h3>Exception desk ({d.exceptions.length})</h3>
        <div className="tbl">
          <table>
            <thead><tr><th>Lead</th><th>Name</th><th>State</th><th>Lang</th><th>Status</th><th>Why</th></tr></thead>
            <tbody>
              {d.exceptions.length ? d.exceptions.map((s) => (
                <tr key={s.leadId}><td className="small">{s.leadId.slice(-6)}</td><td>{s.first || "–"}</td><td>{s.state}</td><td>{(s.lang || "en").toUpperCase()}</td><td><span className="chip c-warn">{s.status}</span></td><td>{s.why}</td></tr>
              )) : <tr><td colSpan={6} className="small">Nothing waiting.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      <div className="panel">
        <h3>Recent sessions</h3>
        <div className="tbl">
          <table>
            <thead><tr><th>Lead</th><th>Name</th><th>Lang</th><th>State</th><th>Furthest step</th><th>Status</th><th>Fee</th></tr></thead>
            <tbody>
              {d.recent.length ? d.recent.map((s) => (
                <tr key={s.leadId}>
                  <td className="small">{s.leadId}</td>
                  <td>{s.first || "–"}</td>
                  <td>{(s.lang || "en").toUpperCase()}</td>
                  <td>{s.state}</td>
                  <td>{s.stepName}</td>
                  <td><span className={"chip " + (s.status === "DECLINED" ? "c-bad" : s.maxStep >= 12 ? "c-good" : "c-info")}>{s.label}</span></td>
                  <td>{s.feeStatus === "NOT_EARNED" ? "–" : <span className={"chip " + (s.feeStatus === "CLAWED_BACK" ? "c-bad" : "c-good")}>{s.feeStatus}</span>}</td>
                </tr>
              )) : <tr><td colSpan={7} className="small">Run a flow in the Consumer app tab and it appears here.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
