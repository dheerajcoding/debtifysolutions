import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useApp } from "../context/AppContext.jsx";
import { api } from "../lib/api.js";
import { PERSONAS } from "../lib/copy.js";
import { clock, fmtDate, usd } from "../lib/format.js";
import Flow from "../components/Flow.jsx";
import { Logo, StageProgress } from "../components/Layout.jsx";
import { Alert, LangSwitch, Spinner } from "../components/ui.jsx";
import Admin from "./Admin.jsx";
import Library from "./Library.jsx";

function Log({ logs }) {
  const ref = useRef(null);
  useEffect(() => { if (ref.current) ref.current.scrollTop = ref.current.scrollHeight; }, [logs]);
  return (
    <div className="log" ref={ref} aria-live="polite">
      {logs.map((l, i) => (
        <div key={i}><span className="t">{clock(l.at)}</span><span className={"tag-" + l.tag}>{l.tag}</span><span>{l.text}</span></div>
      ))}
    </div>
  );
}

function DemoApp() {
  const { persona, choosePersona, restart, logs, lead, meta } = useApp();
  if (!meta?.demoMode) return <Alert kind="info">Demo mode is off (DEMO_MODE=false). Test personas are disabled in this environment.</Alert>;
  return (
    <section className="stage">
      <div>
        <div className="phone-head"><StageProgress step={lead ? lead.step : 1} compact /><LangSwitch /></div>
        <Flow framed />
      </div>
      <div className="side">
        <div className="panel">
          <div className="toolbar"><h3>Test personas</h3><button className="mini" onClick={() => restart(persona, true)}>Restart flow</button></div>
          <p className="small">Pick one and press Continue on each screen. Demo applications are tagged "demo", skip email verification, and never appear on a customer's dashboard. All vendors are simulated.</p>
          <div className="personas">
            {PERSONAS.map((p) => (
              <button key={p.id} className={"persona " + (p.id === persona.id ? "on" : "")} onClick={() => choosePersona(p)}><b>{p.name}</b><span>{p.note}</span></button>
            ))}
          </div>
        </div>
        <div className="panel"><h3>Behind the scenes</h3><Log logs={logs} /></div>
      </div>
    </section>
  );
}

function Applications() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [rows, setRows] = useState(null);
  const [sel, setSel] = useState(null);
  const [msg, setMsg] = useState(null);
  const load = () => api.adminLeads(q, status).then((r) => setRows(r.leads)).catch((e) => setMsg(e.message));
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [q, status]); // eslint-disable-line react-hooks/exhaustive-deps
  const open = (id) => api.adminLead(id).then(setSel).catch((e) => setMsg(e.message));
  const fire = async (type) => {
    try { await api.backendEvent(sel.lead.leadId, type); await open(sel.lead.leadId); load(); } catch (e) { setMsg(e.message); }
  };
  return (
    <div className="cols wide-left">
      <div className="panel">
        <div className="toolbar">
          <h3>Applications</h3>
          <div className="row-wrap">
            <input className="field slim" placeholder="Search name, ID, state" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search" />
            <select className="field slim" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
              <option value="">All statuses</option>
              {["STARTED", "QUALIFIED", "MATCHED", "SIGNED", "ENROLLED", "PAYMENT1_CLEARED", "PAYMENT2_CLEARED", "CLAWBACK", "DECLINED", "CANCELLED"].map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <Alert>{msg}</Alert>
        {!rows ? <Spinner /> : (
          <div className="tbl">
            <table>
              <thead><tr><th>ID</th><th>Name</th><th>State</th><th>Step</th><th>Status</th><th className="r">Deposit</th><th>Created</th></tr></thead>
              <tbody>
                {rows.length ? rows.map((l) => (
                  <tr key={l.leadId} className={"clickable" + (sel?.lead.leadId === l.leadId ? " sel" : "")} onClick={() => open(l.leadId)}>
                    <td className="small">{l.leadId.slice(-8)}{l.source === "demo" && <span className="chip c-info">demo</span>}</td>
                    <td>{l.first ? `${l.first} ${l.last || ""}` : "–"}{l.person && !l.resolved && <span className="chip c-warn">call</span>}</td>
                    <td>{l.state}</td><td className="small">{l.stepName}</td>
                    <td><span className={"chip " + (l.status === "DECLINED" ? "c-bad" : ["ENROLLED", "PAYMENT1_CLEARED", "PAYMENT2_CLEARED"].includes(l.status) ? "c-good" : "c-info")}>{l.reason || l.status}</span></td>
                    <td className="r">{l.deposit ? usd(l.deposit) : "–"}</td><td className="small">{fmtDate(l.createdAt, "en")}</td>
                  </tr>
                )) : <tr><td colSpan={7} className="small">No applications match.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <div className="panel">
        {!sel ? <p className="small">Select an application to see its details and activity log.</p> : (
          <div className="stack">
            <div className="row-between"><h3>{sel.lead.first || "Guest"} {sel.lead.last || ""}</h3><button className="mini" onClick={() => setSel(null)}>Close</button></div>
            <p className="small">{sel.lead.leadId} · {sel.lead.source} · {sel.lead.lang?.toUpperCase()} · {sel.owner ? sel.owner.email : "no account yet"}</p>
            <div className="kv"><span>Status</span><span>{sel.lead.status}{sel.lead.dropReason ? ` (${sel.lead.dropReason})` : ""}</span></div>
            {sel.lead.program && <>
              <div className="kv"><span>Program</span><span>{sel.lead.program.backendName} · {usd(sel.lead.program.monthlyDeposit)} × {sel.lead.program.termMonths}</span></div>
              <div className="kv"><span>Fee</span><span>{sel.lead.feeStatus} · {usd(sel.lead.program.debtifyFee)}</span></div>
            </>}
            {sel.lead.deposits?.length > 0 && (
              <div className="row-wrap">
                <span className="small">Simulate partner event:</span>
                <button className="mini" onClick={() => fire("PAYMENT1_CLEARED")}>Payment 1 cleared</button>
                <button className="mini" onClick={() => fire("PAYMENT2_CLEARED")}>Payment 2 cleared</button>
                <button className="mini" onClick={() => fire("PAYMENT2_FAILED")}>Payment 2 failed</button>
                <button className="mini" onClick={() => fire("DEBT_SETTLED")}>Settle a debt</button>
              </div>
            )}
            {(sel.lead.person || sel.lead.dropReason === "CALL_NEEDS_HUMAN") && !sel.lead.resolved && (
              <button className="mini" onClick={async () => { await api.resolve(sel.lead.leadId); open(sel.lead.leadId); load(); }}>Mark exception resolved</button>
            )}
            <h3>Activity</h3>
            <Log logs={sel.events} />
          </div>
        )}
      </div>
    </div>
  );
}

function Users() {
  const { user } = useApp();
  const [rows, setRows] = useState(null);
  const [err, setErr] = useState(null);
  const load = () => api.users().then((r) => setRows(r.users)).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);
  return (
    <div className="panel">
      <h3>Users and roles</h3>
      <p className="small">Staff can use this console. Admins can also manage roles. Changing a role signs that person out.</p>
      <Alert>{err}</Alert>
      {!rows ? <Spinner /> : (
        <div className="tbl"><table>
          <thead><tr><th>Name</th><th>Email</th><th>Verified</th><th>Joined</th><th>Role</th></tr></thead>
          <tbody>{rows.map((u) => (
            <tr key={u.userId}>
              <td>{u.first} {u.last}</td><td>{u.email}</td><td>{u.emailVerified ? "✓" : "–"}</td><td className="small">{fmtDate(u.createdAt, "en")}</td>
              <td>{u.userId === user.userId ? <b>{u.role}</b> : (
                <select className="field slim" value={u.role} onChange={async (e) => { try { await api.setRole(u.userId, e.target.value); load(); } catch (e2) { setErr(e2.message); } }}>
                  <option value="user">user</option><option value="staff">staff</option><option value="admin">admin</option>
                </select>
              )}</td>
            </tr>
          ))}</tbody>
        </table></div>
      )}
    </div>
  );
}

function DemoGuide() {
  return (
    <section className="panel guide-steps">
      <h3>A 5-minute demo script</h3>
      <ol>
        <li><b>Quick check.</b> Pick "Maria, Texas". Screen 1 is three taps; screen 2 shows an instant estimate. As staff you skip account creation.</li>
        <li><b>Find debts.</b> On "Your debts", confirm the unclear account as a medical bill.</li>
        <li><b>Disclosures you can see.</b> On "Your plan" tap "Explain simpler" on a point. It's counted in the Dashboard tab's clarity table.</li>
        <li><b>Ask Jay.</b> Tap a question chip; the chat answers from approved facts.</li>
        <li><b>Enroll.</b> Link the bank, sign, take the welcome call. Then simulate "Payment 1 cleared".</li>
        <li><b>Declines and handoff.</b> Try "Budget too tight", "ID check fails" or "Call needs a person" (shows up in Applications with a call flag).</li>
        <li><b>Real customer view.</b> Open the site in a private window, apply as a new user, then see the customer dashboard.</li>
      </ol>
    </section>
  );
}

export default function Staff() {
  const { user, setDemo, restart, persona, logout, loadLead } = useApp();
  const [tab, setTab] = useState("demo");
  const isAdmin = user.role === "admin";
  useEffect(() => {
    document.title = "Staff console · Debtify";
    setDemo(true);
    restart(persona, true, { abandon: false });
    // Leaving the console: drop the demo session and reload the staff member's own application, if any.
    return () => {
      setDemo(false);
      restart(PERSONAS[0], false);
      loadLead();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const TABS = [["demo", "Demo app"], ["apps", "Applications"], ["stats", "Dashboard"], ["library", "Explainer library"], ...(isAdmin ? [["users", "Users"]] : []), ["guide", "How to demo"]];
  return (
    <div id="ops">
      <header className="top">
        <div className="brand"><Logo /> <span className="pill">Staff console</span></div>
        <div className="tabs" role="tablist">
          {TABS.map(([id, label]) => <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}>{label}</button>)}
        </div>
        <div className="row-wrap">
          <span className="small">{user.email} · {user.role}</span>
          <Link className="mini as-link" to="/">Website</Link>
          <button className="mini" onClick={logout}>Log out</button>
        </div>
      </header>
      <main className="wrap">
        {tab === "demo" && <DemoApp />}
        {tab === "apps" && <Applications />}
        {tab === "stats" && <Admin />}
        {tab === "library" && <Library />}
        {tab === "users" && isAdmin && <Users />}
        {tab === "guide" && <DemoGuide />}
      </main>
    </div>
  );
}
