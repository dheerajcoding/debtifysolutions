import { useEffect, useRef, useState } from "react";
import { Link, useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { useApp } from "../context/AppContext.jsx";
import { api } from "../lib/api.js";
import { digits, isEmail, maskPhone } from "../lib/format.js";
import { Alert, Check, Field, PasswordField, Spinner } from "../components/ui.jsx";
import { Logo } from "../components/Layout.jsx";

export function AuthShell({ title, sub, children, foot }) {
  const { meta, a } = useApp();
  return (
    <div className="auth">
      <div className="auth-top"><Logo /></div>
      <div className="auth-card">
        <h1>{title}</h1>
        {sub && <p className="sub">{sub}</p>}
        {children}
        {foot && <div className="auth-foot">{foot}</div>}
      </div>
      {meta?.devMail && <p className="small center">{a.devMail} <Link to="/dev/outbox">{a.openOutbox}</Link></p>}
    </div>
  );
}

const next = (loc, fallback = "/dashboard") => {
  const n = new URLSearchParams(loc.search).get("next");
  return n && n.startsWith("/") && !n.startsWith("//") ? n : fallback;
};

export function Login() {
  const { a, login } = useApp();
  const nav = useNavigate();
  const loc = useLocation();
  const [f, setF] = useState({ email: "", password: "" });
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    if (!isEmail(f.email) || !f.password) return setErr(a.loginSub);
    setBusy(true);
    setErr(null);
    try {
      const u = await login(f);
      nav(next(loc, ["staff", "admin"].includes(u.role) ? "/staff" : "/dashboard"), { replace: true });
    } catch (e2) {
      setErr(e2.message);
    }
    setBusy(false);
  };
  return (
    <AuthShell title={a.loginH} sub={a.loginSub} foot={<>{a.noAcct} <Link to={"/signup" + loc.search}>{a.signupL}</Link></>}>
      <form onSubmit={submit} className="stack" noValidate>
        <Field label={a.email} type="email" autoComplete="email" inputMode="email" value={f.email} onChange={(v) => setF({ ...f, email: v })} autoFocus />
        <PasswordField label={a.password} value={f.password} onChange={(v) => setF({ ...f, password: v })} />
        <Link className="small-link" to="/forgot-password">{a.forgot}</Link>
        <Alert>{err}</Alert>
        <button className="btn" disabled={busy}>{busy ? <Spinner /> : a.nav.login}</button>
      </form>
    </AuthShell>
  );
}

export function Signup() {
  const { a, register, lang } = useApp();
  const nav = useNavigate();
  const loc = useLocation();
  const [f, setF] = useState({ first: "", last: "", email: "", phone: "", password: "", terms: false });
  const [errs, setErrs] = useState({});
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const on = (k) => (v) => { setF({ ...f, [k]: k === "phone" ? maskPhone(v) : v }); setErrs({ ...errs, [k]: null }); };
  const es = lang === "es";
  const submit = async (e) => {
    e.preventDefault();
    const bad = {
      first: !f.first.trim() && (es ? "Escribe tu nombre" : "Enter your first name"),
      last: !f.last.trim() && (es ? "Escribe tu apellido" : "Enter your last name"),
      email: !isEmail(f.email) && (es ? "Escribe un correo válido" : "Enter a valid email address"),
      phone: digits(f.phone).length !== 10 && (es ? "Escribe un celular de 10 dígitos" : "Enter a 10-digit mobile number"),
      password: !(f.password.length >= 8 && /[a-z]/i.test(f.password) && /\d/.test(f.password)) && a.pwHint,
      terms: !f.terms && (es ? "Acepta para continuar" : "Please agree to continue"),
    };
    const clean = Object.fromEntries(Object.entries(bad).filter(([, v]) => v));
    setErrs(clean);
    if (Object.keys(clean).length) return;
    setBusy(true);
    setErr(null);
    try {
      await register({ ...f, phone: digits(f.phone), terms: true });
      nav(next(loc), { replace: true });
    } catch (e2) {
      if (e2.field) setErrs({ [e2.field]: e2.message });
      else setErr(e2.message);
    }
    setBusy(false);
  };
  return (
    <AuthShell title={a.signupH} sub={a.signupSub} foot={<>{a.haveAcct} <Link to={"/login" + loc.search}>{a.loginL}</Link></>}>
      <form onSubmit={submit} className="stack" noValidate>
        <div className="grid2">
          <Field label={a.first} autoComplete="given-name" value={f.first} onChange={on("first")} error={errs.first} />
          <Field label={a.last} autoComplete="family-name" value={f.last} onChange={on("last")} error={errs.last} />
        </div>
        <Field label={a.email} type="email" autoComplete="email" inputMode="email" value={f.email} onChange={on("email")} error={errs.email} />
        <Field label={a.phone} type="tel" autoComplete="tel-national" inputMode="tel" value={f.phone} onChange={on("phone")} error={errs.phone} placeholder="(512) 555-0142" />
        <PasswordField label={a.password} value={f.password} onChange={on("password")} error={errs.password} showMeter autoComplete="new-password" />
        <Check checked={f.terms} onChange={on("terms")} error={errs.terms}>{a.terms(<Link key="t" to="/terms" target="_blank">{a.termsL}</Link>, <Link key="p" to="/privacy" target="_blank">{a.privacyL}</Link>)}</Check>
        {errs.terms && <span className="f-err">{errs.terms}</span>}
        <Alert>{err}</Alert>
        <button className="btn" disabled={busy}>{busy ? <Spinner /> : a.createBtn}</button>
      </form>
    </AuthShell>
  );
}

export function Forgot() {
  const { a } = useApp();
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    if (!isEmail(email)) return setErr(a.forgotSub);
    setBusy(true);
    try { await api.forgot(email); setDone(true); } catch (e2) { setErr(e2.message); }
    setBusy(false);
  };
  return (
    <AuthShell title={a.forgotH} sub={done ? null : a.forgotSub} foot={<Link to="/login">← {a.nav.login}</Link>}>
      {done ? <Alert kind="ok">{a.forgotDone}</Alert> : (
        <form onSubmit={submit} className="stack" noValidate>
          <Field label={a.email} type="email" autoComplete="email" value={email} onChange={setEmail} autoFocus />
          <Alert>{err}</Alert>
          <button className="btn" disabled={busy}>{busy ? <Spinner /> : a.sendLink}</button>
        </form>
      )}
    </AuthShell>
  );
}

export function Reset() {
  const { a, setUser } = useApp();
  const [sp] = useSearchParams();
  const nav = useNavigate();
  const [pw, setPw] = useState("");
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      const r = await api.reset(sp.get("token") || "", pw);
      setUser(r.user);
      nav("/dashboard", { replace: true, state: { flash: a.resetDone } });
    } catch (e2) { setErr(e2.message); }
    setBusy(false);
  };
  return (
    <AuthShell title={a.resetH}>
      <form onSubmit={submit} className="stack" noValidate>
        <PasswordField label={a.newPassword} value={pw} onChange={setPw} showMeter autoComplete="new-password" />
        <Alert>{err}</Alert>
        <button className="btn" disabled={busy}>{busy ? <Spinner /> : a.resetBtn}</button>
      </form>
    </AuthShell>
  );
}

export function Verify() {
  const { a, setUser, user } = useApp();
  const [sp] = useSearchParams();
  const [state, setState] = useState("busy");
  const ran = useRef(false);
  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    api.verifyEmail(sp.get("token") || "")
      .then((r) => { setState("ok"); if (user !== null) setUser(r.user); })
      .catch(() => setState("bad"));
  }, [sp, setUser, user]);
  return (
    <AuthShell title={state === "busy" ? a.verifyH : state === "ok" ? a.verifyOk : a.verifyBad}>
      {state === "busy" ? <p className="center"><Spinner /></p> : (
        <div className="stack">
          <Link className="btn as-link" to={user ? "/apply" : "/login"}>{user ? a.continueApp : a.nav.login}</Link>
          {user && <Link className="ghost as-link" to="/dashboard">{a.nav.dashboard}</Link>}
        </div>
      )}
    </AuthShell>
  );
}

export function DevOutbox() {
  const [emails, setEmails] = useState(null);
  useEffect(() => {
    const load = () => api.outbox().then((r) => setEmails(r.emails)).catch(() => setEmails([]));
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, []);
  return (
    <AuthShell title="Dev outbox" sub="Emails the app would send. Only available in development (no SMTP configured).">
      {!emails ? <Spinner /> : !emails.length ? <p className="small">No emails yet.</p> : (
        <div className="stack">
          {emails.map((m) => (
            <div key={m.id} className="card">
              <b>{m.subject}</b>
              <span className="small">To {m.to} · {new Date(m.at).toLocaleTimeString()}</span>
              {m.link && <a className="btn as-link" href={m.link.replace(/^https?:\/\/[^/]+/, "")}>Open link</a>}
            </div>
          ))}
        </div>
      )}
    </AuthShell>
  );
}
