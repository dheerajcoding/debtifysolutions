import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext.jsx";
import { api } from "../lib/api.js";
import { digits, maskPhone } from "../lib/format.js";
import { Alert, Check, Field, LangSwitch, PasswordField } from "../components/ui.jsx";
import { SiteLayout } from "../components/Layout.jsx";

export default function Settings() {
  const { a, user, setUser, logout } = useApp();
  const nav = useNavigate();
  const [p, setP] = useState({ first: user.first || "", last: user.last || "", phone: maskPhone(user.phone || "") });
  const [pMsg, setPMsg] = useState(null);
  const [pw, setPw] = useState({ current: "", password: "" });
  const [pwMsg, setPwMsg] = useState(null);
  const [prefs, setPrefs] = useState(null);
  const [del, setDel] = useState({ open: false, password: "", err: null });

  useEffect(() => {
    document.title = "Settings · Debtify";
    api.application().then((r) => {
      const c = r.application?.consents || [];
      if (c.length) setPrefs(Object.fromEntries(c.map((k) => [k.type, k.granted])));
    }).catch(() => {});
  }, []);

  const saveProfile = async (e) => {
    e.preventDefault();
    try {
      const r = await api.updateMe({ first: p.first, last: p.last, phone: digits(p.phone) });
      setUser(r.user);
      setPMsg({ ok: a.savedOk });
    } catch (e2) { setPMsg({ err: e2.message }); }
  };
  const savePw = async (e) => {
    e.preventDefault();
    try {
      const r = await api.changePassword(pw);
      setUser(r.user);
      setPw({ current: "", password: "" });
      setPwMsg({ ok: a.pwOk });
    } catch (e2) { setPwMsg({ err: e2.message }); }
  };
  const setPref = async (k, v) => {
    setPrefs({ ...prefs, [k]: v });
    try { await api.preferences({ [k]: v }); } catch {}
  };
  const remove = async (e) => {
    e.preventDefault();
    try {
      await api.deleteMe(del.password);
      await logout();
      nav("/", { replace: true });
    } catch (e2) { setDel({ ...del, err: e2.message }); }
  };

  return (
    <SiteLayout>
      <div className="page narrow-page">
        <h1>{a.setH}</h1>

        <form className="panel stack" onSubmit={saveProfile} noValidate>
          <h3>{a.profileH}</h3>
          <div className="grid2">
            <Field label={a.first} value={p.first} onChange={(v) => setP({ ...p, first: v })} autoComplete="given-name" />
            <Field label={a.last} value={p.last} onChange={(v) => setP({ ...p, last: v })} autoComplete="family-name" />
          </div>
          <Field label={a.email} value={user.email} onChange={() => {}} disabled hint={user.emailVerified ? "✓" : undefined} />
          <Field label={a.phone} type="tel" value={p.phone} onChange={(v) => setP({ ...p, phone: maskPhone(v) })} autoComplete="tel-national" />
          <Alert kind={pMsg?.ok ? "ok" : "err"}>{pMsg?.ok || pMsg?.err}</Alert>
          <button className="btn narrow">{a.save}</button>
        </form>

        <div className="panel stack">
          <h3>{a.langH}</h3>
          <LangSwitch />
        </div>

        {prefs && (
          <div className="panel stack" id="prefs">
            <h3>{a.prefsH}</h3>
            <Check checked={prefs.CALLS_TEXTS} onChange={(v) => setPref("CALLS_TEXTS", v)}>{a.prefCalls}</Check>
            <Check checked={prefs.SHARING} onChange={(v) => setPref("SHARING", v)}>{a.prefShare}</Check>
          </div>
        )}

        <form className="panel stack" onSubmit={savePw} noValidate>
          <h3>{a.pwH}</h3>
          <PasswordField label={a.currentPassword} value={pw.current} onChange={(v) => setPw({ ...pw, current: v })} />
          <PasswordField label={a.newPassword} value={pw.password} onChange={(v) => setPw({ ...pw, password: v })} showMeter autoComplete="new-password" />
          <Alert kind={pwMsg?.ok ? "ok" : "err"}>{pwMsg?.ok || pwMsg?.err}</Alert>
          <button className="btn narrow">{a.pwChange}</button>
        </form>

        <div className="panel stack">
          <h3>{a.dataH}</h3>
          <div className="row-wrap">
            <a className="mini as-link" href="/api/me/export" download>{a.exportBtn}</a>
            <button className="mini" onClick={async () => { await api.logoutAll(); await logout(); nav("/login"); }}>{a.logoutAll}</button>
          </div>
        </div>

        <div className="panel stack danger-zone">
          <h3>{a.deleteH}</h3>
          <p className="small">{a.deleteSub}</p>
          {del.open ? (
            <form className="stack" onSubmit={remove}>
              <PasswordField label={a.deleteConfirm} value={del.password} onChange={(v) => setDel({ ...del, password: v, err: null })} />
              <Alert>{del.err}</Alert>
              <button className="mini danger">{a.deleteGo}</button>
            </form>
          ) : <button className="mini danger" onClick={() => setDel({ ...del, open: true })}>{a.deleteBtn}</button>}
        </div>
      </div>
    </SiteLayout>
  );
}
