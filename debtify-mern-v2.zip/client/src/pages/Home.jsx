import { Link, useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext.jsx";
import { AP, RISKS, SITE } from "../lib/copy.js";
import { HOW_ICONS, viz } from "../lib/viz.js";
import { usd } from "../lib/format.js";
import { Html } from "../components/ui.jsx";
import { SiteLayout } from "../components/Layout.jsx";

const RANGES = [["7500-10000", "$7.5k – $10k"], ["10000-15000", "$10k – $15k"], ["15000-25000", "$15k – $25k"], ["25000-50000", "$25k – $50k"], ["50000-75000", "$50k – $75k"], ["75000-100000", "$75k+"]];
const NEED = {
  en: { h: "What you'll need", items: ["About 5 minutes", "Your monthly income and expenses", "Your Social Security number (for a soft check that won't hurt your score)", "Your bank login, if you decide to enroll"] },
  es: { h: "Lo que necesitas", items: ["Unos 5 minutos", "Tus ingresos y gastos mensuales", "Tu número de Seguro Social (para una consulta suave que no afecta tu puntaje)", "Los datos de tu banco, si decides inscribirte"] },
};
const QUICK = { en: { q: "How much do you owe?", hint: "Tap one to start. No credit check yet.", small: "Under $7,500? Start anyway and we'll point you to free help." }, es: { q: "¿Cuánto debes?", hint: "Toca una opción para empezar. Sin consulta de crédito.", small: "¿Menos de $7,500? Empieza igual y te orientaremos a ayuda gratuita." } };

export default function Home() {
  const { lang, meta, lead, setUi, a, x: fx } = useApp();
  const nav = useNavigate();
  const x = SITE[lang], ap = AP[lang], q = QUICK[lang], need = NEED[lang];
  const hp = meta?.sample;
  const resume = lead && lead.step > 1 && lead.step < 10;
  const start = (range) => {
    if (range) setUi({ debtRange: range });
    nav("/apply");
  };

  return (
    <SiteLayout>
      <div className="heroband">
        <section className="hero">
          <div className="hero-copy">
            <p className="s-eyebrow">{x.eyebrow}</p>
            <h1 className="s-h1">{x.h1}</h1>
            <p className="s-sub">{x.sub}</p>
            <ul className="trust">
              {x.chips.map((c) => (
                <li key={c}><Html as="span" className="ic" html={'<svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="9" class="v-g"/><path d="M6 10l3 3 5-6" stroke="var(--on-accent)" stroke-width="2" fill="none"/></svg>'} />{c}</li>
              ))}
            </ul>
          </div>
          <div className="quickstart">
            {resume ? (
              <>
                <p className="qs-h">{a.inProgress}</p>
                <p className="small">{a.stepOf(lead.step, fx.stepNames[lead.step])}</p>
                <button className="btn" onClick={() => start()}>{a.continueApp}</button>
              </>
            ) : (
              <>
                <p className="qs-h">{q.q}</p>
                <p className="small">{q.hint}</p>
                <div className="tapgrid">
                  {RANGES.map(([id, label]) => <button key={id} className="tap" onClick={() => start(id)}>{label}</button>)}
                </div>
                <p className="small">{q.small} <button className="linkish" onClick={() => start("lt7500")}>{lang === "es" ? "Empezar" : "Start"}</button></p>
              </>
            )}
            {hp && (
              <div className="qs-example">
                <span className="plan-tag">{ap.planTag}</span>
                <p className="small">{ap.planWhere}: <b>{usd(hp.enrolledDebt)}</b> → <b>{usd(hp.monthlyDeposit)}/{lang === "es" ? "mes" : "mo"}</b> · {hp.termMonths} {lang === "es" ? "meses" : "months"}</p>
                <p className="plan-note">{ap.planNote}</p>
              </div>
            )}
          </div>
        </section>
      </div>

      <section className="s-sec" id="how">
        <p className="s-eyebrow">{x.howE}</p>
        <h2 className="s-h2">{x.howH}</h2>
        <ol className="steps4">
          {x.how.map(([h, p], i) => (
            <li key={h}><Html className="ic" html={HOW_ICONS[i]} /><span className="n">{i + 1}</span><h3>{h}</h3><p>{p}</p></li>
          ))}
        </ol>
      </section>

      <section className="s-sec split2 tint">
        <div>
          <p className="s-eyebrow">{x.qualE}</p>
          <h2 className="s-h2">{x.qualH}</h2>
          <p className="s-p">{x.qualP}</p>
        </div>
        <div className="figure stack">
          <Html html={viz("debtTypes", lang)} />
          <div>
            <h3>{need.h}</h3>
            <ul className="checklist">{need.items.map((i) => <li key={i}>{i}</li>)}</ul>
          </div>
        </div>
      </section>

      <section className="s-sec split2" id="costs">
        <div>
          <p className="s-eyebrow">{x.costE}</p>
          <h2 className="s-h2">{x.costH}</h2>
          {x.costP.map((p) => <p className="s-p" key={p}>{p}</p>)}
        </div>
        <Html className="figure" html={viz("feeTimeline", lang) + viz("moneyFlow", lang)} />
      </section>

      <section className="s-sec" id="compare">
        <p className="s-eyebrow">{x.cmpE}</p>
        <h2 className="s-h2">{x.cmpH}</h2>
        <div className="tbl s-table">
          <table>
            <thead><tr>{x.cmpCols.map((c, i) => <th key={i} className={i === 1 ? "hl" : undefined}>{c}</th>)}</tr></thead>
            <tbody>{x.cmpRows.map((r) => <tr key={r[0]}>{r.map((c, i) => (i === 0 ? <th scope="row" key={i}>{c}</th> : <td key={i} className={i === 1 ? "hl" : undefined}>{c}</td>))}</tr>)}</tbody>
          </table>
        </div>
        <p className="small">{x.cmpNote}</p>
      </section>

      <section className="s-sec tint" id="risks">
        <p className="s-eyebrow">{x.riskE}</p>
        <h2 className="s-h2">{x.riskH}</h2>
        <div className="risk4">
          {RISKS.map((r) => <div className="rcard" key={r.id}><Html html={viz(r.viz, lang)} /><h3>{r.title[lang]}</h3><p>{r.body[lang]}</p></div>)}
        </div>
      </section>

      <section className="s-sec" id="states">
        <p className="s-eyebrow">{x.statesE}</p>
        <h2 className="s-h2">{x.statesH}</h2>
        <ul className="states">{(meta?.served || []).map((s) => <li key={s}>{s}</li>)}</ul>
        <p className="small">{x.statesP}</p>
      </section>

      <section className="s-sec" id="faq">
        <p className="s-eyebrow">{x.faqE}</p>
        <h2 className="s-h2">{x.faqH}</h2>
        <div className="faq">{x.faq.map(([qq, ans]) => <details key={qq}><summary>{qq}</summary><p>{ans}</p></details>)}</div>
      </section>

      <section className="s-end">
        <h2 className="s-h2">{x.endH}</h2>
        <p>{x.endP}</p>
        <Link className="s-btn" to="/apply">{x.cta}</Link>
      </section>
    </SiteLayout>
  );
}
