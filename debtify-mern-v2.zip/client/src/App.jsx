import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { useApp } from "./context/AppContext.jsx";
import { Spinner } from "./components/ui.jsx";
import Home from "./pages/Home.jsx";
import Apply from "./pages/Apply.jsx";
import { DevOutbox, Forgot, Login, Reset, Signup, Verify } from "./pages/Auth.jsx";
import Dashboard, { Agreement } from "./pages/Dashboard.jsx";
import Settings from "./pages/Settings.jsx";
import Staff from "./pages/Staff.jsx";
import { Contact, NotFound, Privacy, Terms } from "./pages/Legal.jsx";

// Pages that need a signed-in user (optionally with a staff role).
function RequireAuth({ children, roles }) {
  const { user } = useApp();
  const loc = useLocation();
  if (user === undefined) return <p className="center pad"><Spinner /></p>;
  if (!user) return <Navigate to={`/login?next=${encodeURIComponent(loc.pathname)}`} replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />;
  return children;
}
// Login/signup pages bounce signed-in users to their dashboard.
function GuestOnly({ children }) {
  const { user } = useApp();
  if (user === undefined) return <p className="center pad"><Spinner /></p>;
  return user ? <Navigate to="/dashboard" replace /> : children;
}

function ScrollToHash() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) setTimeout(() => document.getElementById(hash.slice(1))?.scrollIntoView({ behavior: "smooth" }), 50);
    else window.scrollTo(0, 0);
    if (pathname === "/") document.title = "Debtify · Settle debt on your own terms";
  }, [pathname, hash]);
  return null;
}

export default function App() {
  return (
    <>
      <ScrollToHash />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/apply" element={<Apply />} />
        <Route path="/login" element={<GuestOnly><Login /></GuestOnly>} />
        <Route path="/signup" element={<GuestOnly><Signup /></GuestOnly>} />
        <Route path="/forgot-password" element={<Forgot />} />
        <Route path="/reset-password" element={<Reset />} />
        <Route path="/verify-email" element={<Verify />} />
        <Route path="/dashboard" element={<RequireAuth><Dashboard /></RequireAuth>} />
        <Route path="/dashboard/agreement" element={<RequireAuth><Agreement /></RequireAuth>} />
        <Route path="/settings" element={<RequireAuth><Settings /></RequireAuth>} />
        <Route path="/staff" element={<RequireAuth roles={["staff", "admin"]}><Staff /></RequireAuth>} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/dev/outbox" element={<DevOutbox />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}
