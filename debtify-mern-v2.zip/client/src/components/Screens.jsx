import { Link } from "react-router-dom";
import { CONSENTS, DECL, QUIZ, RISKS, disclosures } from "../lib/copy.js";
import { G } from "../lib/flowCopy.js";
import { AVATAR, viz } from "../lib/viz.js";
import { fmtDate, maskMoney, maskPhone, maskSsn, usd, digits } from "../lib/format.js";
import { Alert, Check, Field, Html, PasswordField, Spinner } from "./ui.jsx";

export const STATES = "AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY".split(" ");
const STATE_NAMES = { AL: "Alabama", AK: "Alaska", AZ: "Arizona", AR: "Arkansas", CA: "California", CO: "Colorado", CT: "Connecticut", DE: "Delaware", DC: "District of Columbia", FL: "Florida", GA: "Georgia", HI: "Hawaii", ID: "Idaho", IL: "Illinois", IN: "Indiana", IA: "Iowa", KS: "Kansas", KY: "Kentucky", LA: "Louisiana", ME: "Maine", MD: "Maryland", MA: "Massachusetts", MI: "Michigan", MN: "Minnesota", MS: "Mississippi", MO: "Missouri", MT: "Montana", NE: "Nebraska", NV: "Nevada", NH: "New Hampshire", NJ: "New Jersey", NM: "New Mexico", NY: "New York", NC: "North Carolina", ND: "North Dakota", OH: "Ohio", OK: "Oklahoma", OR: "Oregon", PA: "Pennsylvania", RI: "Rhode Island", SC: "South Carolina", SD: "South Dakota", TN: "Tennessee", TX: "Texas", UT: "Utah", VT: "Vermont", VA: "Virginia", WA: "Washington", WV: "West Virginia", WI: "Wisconsin", WY: "Wyoming" };
const RANGES = [["lt7500", "Under $7,500"], ["7500-10000", "$7,500 – $10k"], ["10000-15000", "$10k – $15k"], ["15000-25000", "$15k – $25k"], ["25000-50000", "$25k – $50k"], ["50000-75000", "$50k – $75k"], ["75000-100000", "$75k – $100k"], ["gt100000", "Over $100k"]];

// Field-level error lookup: client-side checks first, then the server's field.
const fe = (ui, field) => ui.fieldErrs?.[field] || (ui.errField === field ? ui.err : null);
const formErr = (ui) => (ui.err && !ui.errField ? ui.err : null);

// Jay's compact tip at the top of each screen.
export function GuideTip({ step, lang, x, act }) {
  const g = G[step];
  if (!g) return null;
  const [say, why] = g[lang];
  const canSpeak = typeof window !== "undefined" && "speechSynthesis" in window;
  return (
    <div className="tip">
      <Html as="span" html={AVATAR} className="tip-av" />
      <div className="tip-body">
        <p><b>{x.guideRole.split(" · ")[0]}:</b> {say}</p>
        <div className="tip-actions">
          <details>
            <summary>{x.why}</summary>
            <p>{why}</p>
          </details>
          {canSpeak && <button type="button" className="linkish" onClick={() => act.listen(step)}>🔊 {x.listen}</button>}
        </div>
        <div className="chips">
          {g.q[lang].map((q) => <button type="button" key={q} className="chip-q" onClick={() => act.askq(q)}>{q}</button>)}
        </div>
      </div>
    </div>
  );
}

// Back + primary action, sticky at the bottom on phones.
function Actions({ ui, onMain, label, disabled, back, x, secondary }) {
  return (
    <div className="actions">
      <Alert>{formErr(ui)}</Alert>
      <div className="actions-row">
        {back && <button type="button" className="ghost back-btn" onClick={back} disabled={ui.pending}>← {x.back}</button>}
        <button type="submit" className="btn" onClick={onMain} disabled={disabled || ui.pending}>
          {ui.pending && ui.busy ? <><Spinner /> {ui.busy}</> : label}
        </button>
      </div>
      {secondary}
    </div>
  );
}

function ClarityRow({ id, x, lead, act }) {
  const v = lead.clarity?.[id];
  return (
    <div className="clarity">
      <span>{x.wasClear}</span>
      <button type="button" className={v === "clear" ? "on" : ""} onClick={() => act.clarity(id, "clear")}>👍 {x.clear}</button>
      <button type="button" className={"simp " + (v === "simpler" ? "on" : "")} onClick={() => act.clarity(id, "simpler")}>{x.simpler}</button>
    </div>
  );
}

function PointCard({ id, title, body, plain, vizKind, p }) {
  const { x, lead, lang } = p;
  return (
    <div className="card point">
      <h2>{title}</h2>
      <Html html={viz(vizKind, lang, { p: lead.program })} />
      <p className="sub">{body}</p>
      {lead.clarity?.[id] === "simpler" && <p className="plain"><b>{x.plain}</b> {plain}</p>}
      <ClarityRow id={id} {...p} />
    </div>
  );
}

const S = {};

// ---------- 1. Quick check ----------
S[1] = (p) => {
  const { x, ui, setUi, act } = p;
  return (
    <>
      <GuideTip step={1} {...p} />
      <h1>{x.q1h}</h1>
      <p className="sub">{x.q1sub}</p>
      <fieldset>
        <legend>{x.q1a}</legend>
        <p className="small">{x.q1aHint}</p>
        <div className="tapgrid">
          {RANGES.map(([id, label]) => (
            <button type="button" key={id} className={"tap" + (ui.debtRange === id ? " on" : "")} aria-pressed={ui.debtRange === id} onClick={() => setUi({ debtRange: id, fieldErrs: {} })}>{label}</button>
          ))}
        </div>
      </fieldset>
      <label className="f">
        <span className="f-label legendish">{x.q1b}</span>
        <select className={"field" + (fe(ui, "state") ? " invalid" : "")} value={ui.state} onChange={(e) => setUi({ state: e.target.value })}>
          <option value="">{x.chooseState}</option>
          {STATES.map((s) => <option key={s} value={s}>{STATE_NAMES[s]}</option>)}
        </select>
      </label>
      <fieldset>
        <legend>{x.q1c}</legend>
        {x.pay.map((o, i) => (
          <button type="button" key={o} className={"choice" + (ui.paymentStatus === i ? " on" : "")} aria-pressed={ui.paymentStatus === i} onClick={() => setUi({ paymentStatus: i })}>{o}</button>
        ))}
      </fieldset>
      <Actions ui={ui} x={x} onMain={act.s1} label={x.seeEstimate} />
    </>
  );
};

// ---------- 2. Estimate + account ----------
function AccountForm({ p }) {
  const { x, a, ui, setUi, act } = p;
  const f = ui.acct;
  const on = (k) => (v) => setUi((u) => ({ acct: { ...u.acct, [k]: k === "phone" ? maskPhone(v) : v }, fieldErrs: { ...u.fieldErrs, [k]: null } }));
  if (ui.authMode === "login")
    return (
      <form className="card stack" onSubmit={(e) => { e.preventDefault(); act.loginInline(); }} noValidate>
        <h2>{x.logIn}</h2>
        <Field label={a.email} type="email" autoComplete="email" value={f.email} onChange={on("email")} error={fe(ui, "email")} />
        <PasswordField label={a.password} value={f.password} onChange={on("password")} error={fe(ui, "password")} />
        <Link className="small-link" to="/forgot-password">{a.forgot}</Link>
        <Actions ui={ui} x={x} label={x.logInCont} />
        <p className="small center">{x.newHere} <button type="button" className="linkish" onClick={() => setUi({ authMode: "signup", err: null })}>{x.createInstead}</button></p>
      </form>
    );
  return (
    <form className="card stack" onSubmit={(e) => { e.preventDefault(); act.registerInline(); }} noValidate>
      <h2>{x.e2acct}</h2>
      <p className="small">{x.e2acctSub}</p>
      <div className="grid2">
        <Field label={a.first} autoComplete="given-name" value={f.first} onChange={on("first")} error={fe(ui, "first")} />
        <Field label={a.last} autoComplete="family-name" value={f.last} onChange={on("last")} error={fe(ui, "last")} />
      </div>
      <Field label={a.email} type="email" autoComplete="email" inputMode="email" value={f.email} onChange={on("email")} error={fe(ui, "email")} />
      <Field label={a.phone} type="tel" autoComplete="tel-national" inputMode="tel" value={f.phone} onChange={on("phone")} error={fe(ui, "phone")} placeholder="(512) 555-0142" />
      <PasswordField label={a.password} value={f.password} onChange={on("password")} error={fe(ui, "password")} showMeter autoComplete="new-password" />
      <Check checked={f.terms} onChange={(v) => setUi((u) => ({ acct: { ...u.acct, terms: v }, fieldErrs: { ...u.fieldErrs, terms: null } }))} error={fe(ui, "terms")}>
        {a.terms(<Link key="t" to="/terms" target="_blank">{a.termsL}</Link>, <Link key="p" to="/privacy" target="_blank">{a.privacyL}</Link>)}
      </Check>
      {fe(ui, "terms") && <span className="f-err">{fe(ui, "terms")}</span>}
      <Actions ui={ui} x={x} label={x.createCont} />
      <p className="small center">{x.haveAcct} <button type="button" className="linkish" onClick={() => setUi({ authMode: "login", err: null })}>{x.logIn}</button></p>
    </form>
  );
}

S[2] = (p) => {
  const { x, ui, act, lead, user } = p;
  const e = lead.estimate;
  return (
    <>
      <GuideTip step={2} {...p} />
      <h1>{x.e2h}</h1>
      {e && (
        <div className="big estimate">
          <span className="k">{x.e2dep}</span>
          <span className="v">{usd(e.depositLow)}–{usd(e.depositHigh)}</span>
          <span className="small-on-dark">{x.e2months(e.monthsLow, e.monthsHigh)}</span>
          <p className="small-on-dark">{x.e2total(usd(e.totalLow), usd(e.totalHigh), usd(e.debt))}</p>
        </div>
      )}
      <p className="small">{x.e2note}</p>
      {user ? <Actions ui={ui} x={x} onMain={act.claim} label={x.e2as(user.first)} back={() => act.back(1)} /> : <AccountForm p={p} />}
    </>
  );
};

// ---------- 3. Verify identity ----------
S[3] = (p) => {
  const { x, ui, setUi, act, lead, lang } = p;
  const f = ui.form;
  const on = (k, mask) => (v) => setUi((u) => ({ form: { ...u.form, [k]: mask ? mask(v) : v }, fieldErrs: { ...u.fieldErrs, [k]: null } }));
  const setC = (type) => (v) => setUi((u) => ({ consents: { ...u.consents, [type]: v }, fieldErrs: { ...u.fieldErrs, [type]: null } }));
  const req = CONSENTS.filter((c) => c.req), opt = CONSENTS.filter((c) => !c.req);
  return (
    <>
      <GuideTip step={3} {...p} />
      <h1>{x.v3h}</h1>
      <p className="sub">{x.v3sub}</p>
      <div className="grid2">
        <Field label={x.dob} type="date" autoComplete="bday" value={f.dob} onChange={on("dob")} error={fe(ui, "dob")} max={new Date(Date.now() - 18 * 365.25 * 864e5).toISOString().slice(0, 10)} />
        <Field label={x.ssnL} hint={x.ssnHint} type="password" inputMode="numeric" autoComplete="off" value={maskSsn(f.ssn)} onChange={on("ssn", maskSsn)} error={fe(ui, "ssn")} placeholder="123-45-6789" />
      </div>
      <Field label={x.a1} autoComplete="address-line1" value={f.address} onChange={on("address")} error={fe(ui, "address")} />
      <div className="grid2">
        <Field label={x.city} autoComplete="address-level2" value={f.city} onChange={on("city")} error={fe(ui, "city")} />
        <Field label={x.zip} inputMode="numeric" autoComplete="postal-code" value={f.zip} onChange={on("zip", (v) => digits(v).slice(0, 5))} error={fe(ui, "zip")} />
      </div>
      <p className="small">{x.stateLine(lead.state).split(".")[0]}.</p>
      <p className="secure">🔒 {x.v3secure}</p>
      <fieldset className="perms">
        <legend>{x.perms} · {x.required}</legend>
        {req.map((c) => (
          <div key={c.type} className={"perm" + (fe(ui, c.type) ? " invalid" : "")}>
            <Check checked={ui.consents[c.type]} onChange={setC(c.type)}><b>{c.label[lang]}.</b> {c.plain[lang]}</Check>
            <details><summary>{x.fullText}</summary><p className="small">{c.text[lang]}</p></details>
          </div>
        ))}
      </fieldset>
      <details className="perms-opt">
        <summary>{x.optional}</summary>
        {opt.map((c) => (
          <div key={c.type} className="perm">
            <Check checked={ui.consents[c.type]} onChange={setC(c.type)}><b>{c.label[lang]}.</b> {c.plain[lang]}</Check>
            <details><summary>{x.fullText}</summary><p className="small">{c.text[lang]}</p></details>
          </div>
        ))}
      </details>
      <Actions ui={ui} x={x} onMain={act.s3} label={x.find} />
    </>
  );
};

// ---------- 4. Your debts ----------
S[4] = (p) => {
  const { x, ui, act, lead } = p;
  const tls = ui.tls || lead.tradelines || [];
  const en = tls.filter((tl) => tl.enrollable || tl.needsReview);
  const no = tls.filter((tl) => !tl.enrollable && !tl.needsReview);
  const total = en.filter((tl) => tl.selected && tl.enrollable).reduce((s, tl) => s + tl.balance, 0);
  return (
    <>
      <GuideTip step={4} {...p} />
      <h1>{x.h4(lead.first)}</h1>
      <p className="sub">{x.s4sub}</p>
      {en.map((tl) => (
        <div className={"card debtcard" + (tl.selected ? " on" : "")} key={tl.tlId}>
          <label className="debt">
            <input type="checkbox" checked={!!tl.selected} disabled={tl.needsReview && !tl.confirmed} onChange={(e) => act.pick(tl.tlId, e.target.checked)} />
            <span className="grow"><b>{tl.creditor}</b><br /><span className="small">{tl.needsReview && !tl.confirmed ? x.tell : x.types[tl.confirmed || tl.type] || tl.type}</span></span>
            <b>{usd(tl.balance)}</b>
          </label>
          {tl.needsReview && (
            <select className="field" value={tl.confirmed || ""} onChange={(e) => act.confirm(tl.tlId, e.target.value)}>
              <option value="">{x.kind}</option>
              {Object.entries(x.kinds).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          )}
        </div>
      ))}
      {no.length > 0 && (
        <details className="card">
          <summary><b>{x.cant(no.length)}</b></summary>
          {no.map((tl) => <p className="small" key={tl.tlId}>{tl.creditor}: {usd(tl.balance)}, {x.types[tl.type]} · {x.cantWhy}</p>)}
        </details>
      )}
      <div className="card kv total"><span>{x.enrolling}</span><span>{usd(total)}</span></div>
      <Actions ui={ui} x={x} onMain={act.s4} label={x.cont} disabled={total === 0} back={() => act.back(3)} />
    </>
  );
};

// ---------- 5. Budget ----------
S[5] = (p) => {
  const { x, ui, setUi, act, lead, lang } = p;
  const inc = +digits(ui.inc) || 0, exp = +digits(ui.exp) || 0;
  return (
    <>
      <GuideTip step={5} {...p} />
      <h1>{x.h5}</h1>
      <p className="sub">{x.s5sub}</p>
      <Field label={x.inc} prefix="$" inputMode="numeric" value={maskMoney(ui.inc)} onChange={(v) => setUi({ inc: digits(v) })} error={fe(ui, "income")} placeholder="4,200" />
      <Field label={x.exp} prefix="$" inputMode="numeric" value={maskMoney(ui.exp)} onChange={(v) => setUi({ exp: digits(v) })} placeholder="3,300" />
      {inc > 0 && <Html html={viz("budget", lang, { inc, exp })} className="card" />}
      <div className="card kv total"><span>{x.left}</span><span>{usd(inc - exp)}</span></div>
      <button type="button" className="ghost" onClick={act.bank1}>{lead.bankLinked ? x.bankOn : x.bankOpt}</button>
      <Actions ui={ui} x={x} onMain={act.s5} label={x.seeProg} back={() => act.back(4)} />
    </>
  );
};

// ---------- 6. Your plan + costs ----------
S[6] = (p) => {
  const { x, ui, setUi, act, lead, lang } = p;
  const pr = lead.program;
  return (
    <>
      <GuideTip step={6} {...p} />
      <h1>{x.h6}</h1>
      <p className="sub" dangerouslySetInnerHTML={{ __html: x.prov(pr.backendName) }} />
      <div className="big">
        <span className="k">{x.dep}</span>
        <span className="v">{usd(pr.monthlyDeposit)}</span>
        <span className="small-on-dark">{x.depSub(pr.termMonths)}</span>
      </div>
      <Html html={viz("compare", lang, { p: pr })} className="card" />
      <div className="card">
        <div className="kv"><span>{x.rDebt}</span><span>{usd(pr.enrolledDebt)}</span></div>
        <div className="kv"><span>{x.rCost}</span><span>{usd(pr.estTotalCost)}</span></div>
        <div className="kv"><span>{x.rSave}</span><span>{usd(pr.estSavings)}</span></div>
        <div className="kv"><span>{x.rFee}</span><span>{x.feeTxt(Math.round(pr.clientFeePct * 100))}</span></div>
      </div>
      {(() => {
        const left = (lead.tradelines || []).filter((t) => t.selected && t.enrollable && pr.includedTlIds && !pr.includedTlIds.includes(t.tlId));
        return left.length ? <p className="alert info">{x.notIncl(pr.backendName, left.map((t) => t.creditor).join(", "))}</p> : null;
      })()}
      <p className="small">{x.s6note}</p>
      <h2 className="sec-h">{x.p6how}</h2>
      {disclosures(pr, lang).map((d) => <PointCard key={d.id} id={d.id} title={d.title} body={d.body} plain={d.plain} vizKind={d.viz} p={p} />)}
      <Check checked={ui.ack} onChange={(v) => setUi({ ack: v, err: null })}>{x.ack}</Check>
      <Actions ui={ui} x={x} onMain={act.s6} label={x.cont} back={() => act.back(5)} />
    </>
  );
};

// ---------- 7. Risks + quick check ----------
S[7] = (p) => {
  const { x, ui, act, lang } = p;
  return (
    <>
      <GuideTip step={7} {...p} />
      <h1>{x.h8}</h1>
      {RISKS.map((r) => <PointCard key={r.id} id={r.id} title={r.title[lang]} body={r.body[lang]} plain={r.plain[lang]} vizKind={r.viz} p={p} />)}
      <h2 className="sec-h">{x.quizH}</h2>
      {QUIZ.map((q, qi) => (
        <fieldset key={q.id}>
          <legend>{qi + 1}. {q.q[lang]}</legend>
          {q.o[lang].map((o, i) => <button type="button" key={o} className={"choice" + (ui.answers[q.id] === i ? " on" : "")} aria-pressed={ui.answers[q.id] === i} onClick={() => act.ans(q.id, i)}>{o}</button>)}
          {ui.wrong?.includes(q.id) && <p className="alert info">{q.ex[lang]}</p>}
        </fieldset>
      ))}
      <Actions ui={ui} x={x} onMain={act.s7} label={x.checkA} disabled={QUIZ.some((q) => ui.answers[q.id] === undefined)} back={() => act.back(6)} />
    </>
  );
};

// ---------- 8. Deposits + sign ----------
S[8] = (p) => {
  const { x, ui, setUi, act, lead, user, demo, lang } = p;
  const pr = lead.program;
  const needVerify = !demo && user && !user.emailVerified;
  return (
    <>
      <GuideTip step={8} {...p} />
      <h1>{x.d8h}</h1>
      <p className="sub">{x.d8sub}</p>
      <Html html={viz("moneyFlow", lang)} className="card" />
      <button type="button" className={"ghost" + (lead.depositAccountLinked ? " done" : "")} onClick={act.bank2}>{lead.depositAccountLinked ? x.bankOn : x.bank2}</button>
      <Field label={x.draft} type="date" value={ui.draft} onChange={(v) => setUi({ draft: v })} hint={x.draftSub} error={fe(ui, "draftDate")}
        min={new Date(Date.now() + 3 * 864e5).toISOString().slice(0, 10)} max={new Date(Date.now() + 45 * 864e5).toISOString().slice(0, 10)} />
      <div className="card">
        <h2>{x.keyT}</h2>
        <div className="kv"><span>{x.company}</span><span>{pr.backendName}</span></div>
        <div className="kv"><span>{x.mdep}</span><span>{usd(pr.monthlyDeposit)}</span></div>
        <div className="kv"><span>{x.first}</span><span>{fmtDate(ui.draft, lang)}</span></div>
        <div className="kv"><span>{x.len}</span><span>{x.months(pr.termMonths)}</span></div>
        <div className="kv"><span>{x.feeL}</span><span>{x.feeTxt(Math.round(pr.clientFeePct * 100))}</span></div>
        <div className="kv"><span>{x.cancel}</span><span>{x.anytime}</span></div>
      </div>
      <p className="small">{x.full(pr.backendName)}</p>
      {needVerify && (
        <div className="alert info">
          {x.verifyFirst} <b>{user.email}</b>.{" "}
          <button type="button" className="linkish" onClick={act.resend}>{ui.resent ? x.resent : x.resend}</button>
        </div>
      )}
      <Actions ui={ui} x={x} onMain={act.sign} label={x.signCont} disabled={!lead.depositAccountLinked} back={() => act.back(7)}
        secondary={<button type="button" className="ghost" onClick={act.nosign} disabled={ui.pending}>{x.notNow}</button>} />
    </>
  );
};

// ---------- 9. Welcome call ----------
S[9] = (p) => {
  const { x, ui, act, lead } = p;
  return (
    <>
      <GuideTip step={9} {...p} />
      <h1>{x.h11}</h1>
      <div className="card call" aria-live="polite">
        {ui.call.length ? ui.call.map((l, i) => <p className="small" key={i}><b>{l.who}:</b> {l.text}</p>) : <p className="small">{x.covers}</p>}
        {ui.calling && <p className="small"><Spinner /> …</p>}
      </div>
      {lead.callResult === "NEEDS_HUMAN" && !ui.calling ? <p className="alert info">{x.humanMsg}</p> : ui.calling ? null : <Actions ui={ui} x={x} onMain={act.call} label={x.callMe} />}
    </>
  );
};

// ---------- 10. Enrolled ----------
S[10] = (p) => {
  const { x, lead, lang, act, demo } = p;
  const pr = lead.program;
  return (
    <>
      <div className="done-badge">✓</div>
      <h1>{x.done9}</h1>
      <div className="big">
        <span className="k">{x.first}</span>
        <span className="v">{usd(pr.monthlyDeposit)}</span>
        <span className="small-on-dark">{x.on(fmtDate(lead.draftDate, lang, { month: "long", day: "numeric" }))}</span>
      </div>
      <div className="card">
        <h2>{x.next}</h2>
        <ol className="sub steps-list">{x.nextL(pr.backendName).map((l) => <li key={l}>{l}</li>)}</ol>
      </div>
      {demo ? (
        <div className="card dashed">
          <p className="demo-note">Demo control (staff only): simulate partner events</p>
          <p className="small">Fee status: <b>{lead.feeStatus}</b> · Debtify fee {usd(pr.debtifyFee)}</p>
          <div className="row-wrap">
            <button type="button" className="mini" onClick={() => act.backend("PAYMENT1_CLEARED")}>Payment 1 cleared</button>
            <button type="button" className="mini" onClick={() => act.backend("PAYMENT2_CLEARED")}>Payment 2 cleared</button>
            <button type="button" className="mini" onClick={() => act.backend("PAYMENT2_FAILED")}>Payment 2 failed</button>
            <button type="button" className="mini" onClick={() => act.backend("DEBT_SETTLED")}>Settle a debt</button>
          </div>
        </div>
      ) : (
        <Link className="btn as-link" to="/dashboard">{x.toDash}</Link>
      )}
    </>
  );
};

function Declined({ x, lang, lead, act }) {
  const [h, b] = DECL[lang][lead.dropReason] || DECL[lang].NO_BACKEND_FIT;
  return (
    <>
      <div className="tip">
        <Html as="span" html={AVATAR} className="tip-av" />
        <div className="tip-body"><p>{b}</p></div>
      </div>
      <h1>{h}</h1>
      <div className="card">
        <p className="sub">{lang === "es" ? "Un consejero de crédito sin fines de lucro puede revisar tu caso gratis. Busca uno acreditado por la NFCC:" : "A nonprofit credit counselor can review your situation for free. Find one accredited by the NFCC:"}</p>
        <a className="small-link" href="https://www.nfcc.org/" target="_blank" rel="noreferrer">nfcc.org</a>
      </div>
      <button type="button" className="ghost" onClick={act.restart}>{x.restart}</button>
    </>
  );
}

export function Screen(props) {
  const { step } = props;
  if (!step) return <Declined {...props} />;
  const C = S[step];
  return C ? C(props) : null;
}
