import { useEffect, useMemo, useRef } from "react";
import { useApp } from "../context/AppContext.jsx";
import { api } from "../lib/api.js";
import { CONSENTS } from "../lib/copy.js";
import { G } from "../lib/flowCopy.js";
import { digits, isEmail } from "../lib/format.js";
import { Screen } from "./Screens.jsx";
import Chat from "./Chat.jsx";

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const MSG = {
  en: { debtRange: "Choose how much you owe", state: "Choose your state", paymentStatus: "Choose where you are with payments", first: "Enter your first name", last: "Enter your last name", email: "Enter a valid email address", phone: "Enter a 10-digit mobile number", password: "Use at least 8 characters with letters and a number", terms: "Please agree to the Terms and Privacy Policy", dob: "Enter your date of birth", ssn: "Enter all 9 digits", address: "Enter your street address", city: "Enter your city", zip: "Enter a 5-digit ZIP code", consent: "Please check this box to continue", income: "Enter your monthly take-home income", fix: "Please fix the highlighted fields." },
  es: { debtRange: "Elige cuánto debes", state: "Elige tu estado", paymentStatus: "Elige cómo vas con tus pagos", first: "Escribe tu nombre", last: "Escribe tu apellido", email: "Escribe un correo válido", phone: "Escribe un celular de 10 dígitos", password: "Usa al menos 8 caracteres con letras y un número", terms: "Acepta los Términos y la Política de privacidad", dob: "Escribe tu fecha de nacimiento", ssn: "Escribe los 9 dígitos", address: "Escribe tu dirección", city: "Escribe tu ciudad", zip: "Escribe un código postal de 5 dígitos", consent: "Marca esta casilla para continuar", income: "Escribe tu ingreso mensual neto", fix: "Corrige los campos marcados." },
};

// Every button in the application maps to one of these actions.
function useActions() {
  const app = useApp();
  const ref = useRef(app);
  ref.current = app;

  return useMemo(() => {
    const A = () => ref.current;
    const id = () => A().lead?.leadId;
    const U = () => A().ui;
    const m = () => MSG[A().lang];
    // Shows field errors; returns true when the form is valid.
    const check = (errs) => {
      const bad = Object.fromEntries(Object.entries(errs).filter(([, v]) => v));
      A().setUi({ fieldErrs: bad, err: Object.keys(bad).length ? m().fix : null, errField: null });
      return !Object.keys(bad).length;
    };
    const claimAfterAuth = async () => {
      const lid = id();
      if (lid) await A().run(null, () => api.claim(lid));
    };
    return {
      listen: (step) => {
        try {
          speechSynthesis.cancel();
          const u = new SpeechSynthesisUtterance(G[step][A().lang].join(" "));
          u.lang = A().lang === "es" ? "es-US" : "en-US";
          speechSynthesis.speak(u);
        } catch {}
      },
      askq: (q) => A().sendChat(q),
      clarity: (pid, v) => A().run(null, () => api.patchLead(id(), { clarity: { [pid]: v } })),
      back: (n) => A().run(null, () => api.patchLead(id(), { step: n })),
      s1: () => {
        const u = U();
        if (!check({ debtRange: !u.debtRange && m().debtRange, state: !u.state && m().state, paymentStatus: u.paymentStatus == null && m().paymentStatus })) return;
        return A().run(null, () => api.createLead({ debtRange: u.debtRange, state: u.state, paymentStatus: u.paymentStatus, lang: A().lang, source: A().demo ? "demo" : "web", persona: A().demo ? A().persona.id : undefined }));
      },
      registerInline: async () => {
        const f = U().acct;
        const ok = check({
          first: !f.first.trim() && m().first, last: !f.last.trim() && m().last, email: !isEmail(f.email) && m().email,
          phone: digits(f.phone).length !== 10 && m().phone, password: !(f.password.length >= 8 && /[a-z]/i.test(f.password) && /\d/.test(f.password)) && m().password, terms: !f.terms && m().terms,
        });
        if (!ok) return;
        A().setUi({ pending: true, busy: null, err: null });
        try {
          await A().register({ first: f.first, last: f.last, email: f.email, phone: digits(f.phone), password: f.password, terms: true });
          A().setUi({ pending: false });
          await claimAfterAuth();
        } catch (e) {
          A().setUi({ pending: false, err: e.message, errField: e.field || null, ...(e.code === "EMAIL_TAKEN" ? { authMode: "login" } : {}) });
        }
      },
      loginInline: async () => {
        const f = U().acct;
        if (!check({ email: !isEmail(f.email) && m().email, password: !f.password && m().password })) return;
        A().setUi({ pending: true, err: null });
        try {
          const keep = id();
          await A().login({ email: f.email, password: f.password });
          A().setUi({ pending: false });
          if (keep) await A().run(null, () => api.claim(keep));
        } catch (e) {
          A().setUi({ pending: false, err: e.message });
        }
      },
      claim: () => A().run(null, () => api.claim(id())),
      s3: () => {
        const f = U().form, c = U().consents, mm = m();
        const errs = { dob: !f.dob && mm.dob, ssn: digits(f.ssn).length !== 9 && mm.ssn, address: f.address.trim().length < 3 && mm.address, city: f.city.trim().length < 2 && mm.city, zip: digits(f.zip).length !== 5 && mm.zip };
        CONSENTS.filter((k) => k.req).forEach((k) => (errs[k.type] = !c[k.type] && mm.consent));
        if (!check(errs)) return;
        const L = A().lang;
        return A().run(A().x.checking, () =>
          api.identity(id(), {
            dob: f.dob, ssn: digits(f.ssn), address: f.address, city: f.city, zip: digits(f.zip), consents: c,
            consentTexts: Object.fromEntries(CONSENTS.map((k) => [k.type, k.text[L]])),
            ...(A().demo ? { first: f.first, last: f.last, phone: f.phone } : {}),
          })
        ).then((r) => r && A().setUi({ tls: null }));
      },
      pick: (tlId, checked) => A().setUi((u) => ({ tls: (u.tls || A().lead.tradelines).map((t) => (t.tlId === tlId ? { ...t, selected: checked } : t)) })),
      confirm: (tlId, v) => A().setUi((u) => ({ tls: (u.tls || A().lead.tradelines).map((t) => (t.tlId === tlId ? { ...t, confirmed: v || null, enrollable: !!v, selected: !!v } : t)) })),
      s4: async () => {
        const tls = U().tls || A().lead.tradelines;
        const r = await A().run(null, () => api.debts(id(), { tradelines: tls.map((t) => ({ tlId: t.tlId, selected: !!t.selected, confirmed: t.confirmed || null })), advance: true }));
        if (r) A().setUi({ tls: null });
      },
      bank1: () => A().run(null, () => api.budget(id(), { income: +digits(U().inc) || 0, expenses: +digits(U().exp) || 0, bankLinked: true, linkOnly: true })),
      s5: () => {
        if (!check({ income: !(+digits(U().inc) > 0) && m().income })) return;
        return A().run(A().x.finding, () => api.budget(id(), { income: +digits(U().inc), expenses: +digits(U().exp) || 0, bankLinked: !!A().lead.bankLinked }));
      },
      s6: () => {
        if (!U().ack) return A().setUi({ err: A().x.needAck, errField: null });
        return A().run(null, () => api.acknowledge(id()));
      },
      ans: (qid, i) => A().setUi((u) => ({ answers: { ...u.answers, [qid]: i } })),
      s7: async () => {
        const r = await A().run(null, () => api.quiz(id(), U().answers));
        if (r) A().setUi({ wrong: r.wrong || [] });
      },
      bank2: () => A().run(null, () => api.linkDeposits(id())),
      resend: async () => {
        try { await api.resendVerification(); A().setUi({ resent: true }); } catch (e) { A().setUi({ err: e.message }); }
      },
      sign: async () => {
        const d = new Date(U().draft + "T12:00:00Z").getTime();
        if (!d || d < Date.now() + 3 * 864e5 - 432e5 || d > Date.now() + 45 * 864e5) return A().setUi({ fieldErrs: { draftDate: A().x.badDate }, err: null });
        A().setUi({ fieldErrs: {} });
        // pick up a just-confirmed email (verified in another tab)
        if (A().user && !A().user.emailVerified) {
          try { const me = await api.me(); if (me.user) A().setUser(me.user); } catch {}
        }
        return A().run(null, () => api.enroll(id(), { accept: true, draftDate: U().draft }));
      },
      nosign: () => A().run(null, () => api.enroll(id(), { accept: false })),
      call: async () => {
        A().setUi({ calling: true, call: [], err: null });
        try {
          const r = await api.call(id());
          A().addEvents(r.events.slice(0, 1));
          for (const line of r.call.lines) {
            await wait(600);
            A().setUi((u) => ({ call: [...u.call, line] }));
          }
          await wait(500);
          A().addEvents(r.events.slice(1));
          A().setLead(r.lead);
        } catch (e) {
          A().setUi({ err: e.message });
        }
        A().setUi({ calling: false });
      },
      backend: (type) => A().run(null, () => api.backendEvent(id(), type)),
      restart: () => A().restart(A().persona, A().demo),
    };
  }, []);
}

// The application. `framed` shows it inside a phone frame (staff console demo).
export default function Flow({ framed = false }) {
  const app = useApp();
  const { lead, ui, setUi, x, a, lang, user, demo } = app;
  const act = useActions();
  const screenRef = useRef(null);
  const step = lead ? lead.step : 1;

  useEffect(() => {
    if (framed && screenRef.current) screenRef.current.scrollTop = 0;
    if (!framed) window.scrollTo(0, 0);
    setUi({ err: null, errField: null, fieldErrs: {} });
  }, [step, lead?.leadId, framed, setUi]);

  const props = { x, a, lang, lead: lead || { step: 1, clarity: {} }, ui, setUi, act, step, user, demo };
  const body = (
    <div className="app">
      <Screen {...props} />
    </div>
  );
  if (!framed)
    return (
      <div className="flow-main">
        {body}
        <Chat />
      </div>
    );
  return (
    <div className="phone">
      <div className="screen" ref={screenRef}>
        {body}
        <Chat />
      </div>
    </div>
  );
}
