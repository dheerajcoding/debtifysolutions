import { useEffect, useRef, useState } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext.jsx";
import { api } from "../lib/api.js";
import { SITE } from "../lib/copy.js";
import { MIN_LEFT, STAGE_OF } from "../lib/flowCopy.js";
import { LOGO } from "../lib/viz.js";
import { Html, LangSwitch } from "./ui.jsx";

export const Logo = () => (
  <Link to="/" className="brandmark" aria-label="Debtify home">
    <Html as="span" html={LOGO} className="logo-wrap" />
    <b>Debtify</b>
  </Link>
);

function AccountMenu() {
  const { user, a, logout } = useApp();
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const ref = useRef(null);
  useEffect(() => {
    const close = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, []);
  return (
    <div className="acct" ref={ref}>
      <button type="button" className="acct-btn" aria-expanded={open} onClick={() => setOpen(!open)}>
        <span className="initial">{(user.first || user.email)[0].toUpperCase()}</span>
        <span className="hide-sm">{user.first}</span>
      </button>
      {open && (
        <div className="menu" role="menu">
          <Link role="menuitem" to="/dashboard" onClick={() => setOpen(false)}>{a.nav.dashboard}</Link>
          <Link role="menuitem" to="/settings" onClick={() => setOpen(false)}>{a.nav.settings}</Link>
          {["staff", "admin"].includes(user.role) && <Link role="menuitem" to="/staff" onClick={() => setOpen(false)}>{a.nav.staff}</Link>}
          <button role="menuitem" type="button" onClick={async () => { setOpen(false); await logout(); nav("/"); }}>{a.nav.logout}</button>
        </div>
      )}
    </div>
  );
}

export function Header() {
  const { user, a, lang } = useApp();
  const loc = useLocation();
  const onHome = loc.pathname === "/";
  const sec = (id) => (onHome ? `#${id}` : `/#${id}`);
  return (
    <header className="sitehead">
      <div className="in">
        <Logo />
        <nav id="siteNav" aria-label="Main">
          <a href={sec("how")}>{a.nav.how}</a>
          <a href={sec("costs")}>{a.nav.costs}</a>
          <a href={sec("faq")}>{a.nav.faq}</a>
          <NavLink to="/contact">{a.nav.contact}</NavLink>
        </nav>
        <div className="right">
          <LangSwitch />
          {user === undefined ? null : user ? <AccountMenu /> : <Link className="navlink hide-sm" to="/login">{a.nav.login}</Link>}
          {!user && <Link id="siteCta" to="/apply">{SITE[lang].cta}</Link>}
        </div>
      </div>
    </header>
  );
}

export function VerifyBanner() {
  const { user, a } = useApp();
  const [sent, setSent] = useState(false);
  if (!user || user.emailVerified || user.role !== "user") return null;
  return (
    <div className="banner" role="status">
      {a.verifyBanner} <b>{user.email}</b>.{" "}
      <button type="button" className="linkish" disabled={sent} onClick={async () => { try { await api.resendVerification(); setSent(true); } catch {} }}>{sent ? a.resent : a.resend}</button>
    </div>
  );
}

export function Footer() {
  const { lang, a, meta } = useApp();
  const x = SITE[lang];
  return (
    <footer className="s-foot">
      <div className="s-footin">
        <div className="foot-top">
          <Logo />
          <nav className="foot-links" aria-label="Footer">
            <Link to="/apply">{a.nav.start}</Link>
            <Link to="/contact">{a.nav.contact}</Link>
            <Link to="/privacy">{a.privacyL}</Link>
            <Link to="/terms">{a.termsL}</Link>
            <Link to="/login">{a.nav.login}</Link>
          </nav>
        </div>
        <p>{x.legal}</p>
        {meta?.demoMode && <p className="demo-note">{x.stageNote}</p>}
        <p className="small">© {new Date().getFullYear()} Debtify</p>
      </div>
    </footer>
  );
}

export function SiteLayout({ children }) {
  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <Header />
      <VerifyBanner />
      <main id="main">{children}</main>
      <Footer />
    </>
  );
}

// 4-stage progress bar used on the application page and in the staff demo phone.
export function StageProgress({ step, compact = false }) {
  const { x } = useApp();
  const st = step ? STAGE_OF[step] : 0;
  const pct = step ? Math.min(100, ((step - 1) / 9) * 100 + 4) : 0;
  return (
    <div className={"stages" + (compact ? " compact" : "")}>
      <ol>
        {x.stages.map((name, i) => (
          <li key={name} className={i < st || step === 10 ? "done" : i === st && step ? "now" : ""}>
            <span className="dot">{i < st || step === 10 ? "✓" : i + 1}</span>
            <span className="nm">{name}</span>
          </li>
        ))}
      </ol>
      <div className="bar"><i style={{ width: `${step === 10 ? 100 : pct}%` }} /></div>
      {step > 0 && step < 10 && <p className="minleft">{x.stepNames[step]} · {x.minLeft(MIN_LEFT[step])}</p>}
    </div>
  );
}
