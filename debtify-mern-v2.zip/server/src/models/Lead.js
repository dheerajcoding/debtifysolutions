import mongoose from "mongoose";

const Mixed = mongoose.Schema.Types.Mixed;

const TradelineSchema = new mongoose.Schema(
  { tlId: String, creditor: String, type: String, balance: Number, enrollable: Boolean, selected: Boolean, needsReview: Boolean, confirmed: { type: String, default: null }, status: String },
  { _id: false }
);
const ConsentSchema = new mongoose.Schema({ type: String, granted: Boolean, lang: String, version: String, textHash: String, at: Date }, { _id: false });
const EventSchema = new mongoose.Schema({ tag: String, text: String, at: Date }, { _id: false });

// One application (lead) per enrollment attempt. Owned by a user once they create an account.
const LeadSchema = new mongoose.Schema(
  {
    leadId: { type: String, unique: true, index: true },
    userId: { type: String, index: true, default: null },
    guestTokenHash: { type: String, index: true, default: null },
    source: { type: String, enum: ["demo", "sample", "web"], default: "web", index: true },
    lang: { type: String, default: "en" },
    persona: String,
    state: String,
    debtRange: String,
    debt: Number,
    paymentStatus: Number,
    estimate: { type: Mixed, default: null },
    step: { type: Number, default: 1 },
    maxStep: { type: Number, default: 1 },
    status: { type: String, default: "STARTED", index: true },
    dropReason: { type: String, default: null },
    // Identity. The full SSN is never stored; DOB and address are AES-256-GCM encrypted.
    first: String,
    last: String,
    phone: String,
    ssnLast4: String,
    dobEnc: String,
    addressEnc: String,
    kyc: String,
    consents: [ConsentSchema],
    share: { type: Boolean, default: false },
    tradelines: [TradelineSchema],
    income: Number,
    expenses: Number,
    bankLinked: { type: Boolean, default: false },
    depositAccountLinked: { type: Boolean, default: false },
    program: { type: Mixed, default: null },
    backend: { type: String, default: null },
    costsAcknowledged: { type: Boolean, default: false },
    quizAttempts: { type: Number, default: 0 },
    draftDate: String,
    signedAt: Date,
    enrolledAt: Date,
    cancelledAt: Date,
    callResult: String,
    deposits: { type: [Mixed], default: [] },
    feeStatus: { type: String, default: "NOT_EARNED" },
    clarity: { type: Mixed, default: {} },
    chats: { type: Number, default: 0 },
    person: { type: Boolean, default: false },
    resolved: { type: Boolean, default: false },
    events: [EventSchema],
  },
  { timestamps: true, minimize: false }
);

export const Lead = mongoose.models.Lead || mongoose.model("Lead", LeadSchema);
