import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "../config/db.js";
import { ah, HttpError, validate } from "../lib/http.js";
import { decrypt } from "../lib/crypto.js";
import { sendMail } from "../lib/mailer.js";
import { clearSession, publicUser, requireAuth, setSession } from "../middleware/auth.js";
import { passwordSchema } from "./auth.js";
import { dashboardView } from "../services/program.js";

const router = Router();
router.use(requireAuth);

const latestLead = async (userId) => (await db.leads.list({ userId, source: "web" }, { limit: 1, omit: ["events"] }))[0] || null;

// Customer dashboard: the latest application, its program, deposits and debts.
router.get(
  "/application",
  ah(async (req, res) => {
    res.json({ application: dashboardView(await latestLead(req.user.userId)) });
  })
);

router.get(
  "/applications",
  ah(async (req, res) => {
    const all = await db.leads.list({ userId: req.user.userId, source: "web" }, { limit: 50, omit: ["events"] });
    res.json({ applications: all.map((l) => ({ leadId: l.leadId, status: l.status, step: l.step, dropReason: l.dropReason, createdAt: l.createdAt, program: l.program ? { backendName: l.program.backendName, monthlyDeposit: l.program.monthlyDeposit } : null })) });
  })
);

// Right to cancel at any time.
router.post(
  "/application/cancel",
  validate(z.object({ reason: z.string().max(300).optional() })),
  ah(async (req, res) => {
    const lead = await latestLead(req.user.userId);
    if (!lead || ["CANCELLED", "DECLINED"].includes(lead.status)) throw new HttpError(409, "There's no active program to cancel", "NOTHING_TO_CANCEL");
    const deposits = (lead.deposits || []).map((d) => (d.status === "SCHEDULED" ? { ...d, status: "CANCELLED" } : d));
    const updated = await db.leads.update(lead.leadId, { status: "CANCELLED", cancelledAt: new Date().toISOString(), deposits, dropReason: lead.dropReason || "CANCELLED_BY_CLIENT" });
    await db.leads.pushEvents(lead.leadId, [{ tag: "EVENT", text: `cancelled by client${req.body.reason ? ": " + req.body.reason : ""}`, at: new Date().toISOString() }]);
    res.json({ application: dashboardView(updated) });
  })
);

// Communication preferences (optional consents) can be changed any time.
router.patch(
  "/preferences",
  validate(z.object({ CALLS_TEXTS: z.boolean().optional(), SHARING: z.boolean().optional() })),
  ah(async (req, res) => {
    const lead = await latestLead(req.user.userId);
    if (!lead) throw new HttpError(404, "No application yet", "NOT_FOUND");
    const consents = (lead.consents || []).map((c) => (c.type in req.body ? { ...c, granted: req.body[c.type], at: new Date().toISOString() } : c));
    const patch = { consents };
    if ("SHARING" in req.body) patch.share = req.body.SHARING;
    const updated = await db.leads.update(lead.leadId, patch);
    await db.leads.pushEvents(lead.leadId, Object.entries(req.body).map(([k, v]) => ({ tag: "CONSENT", text: `${k} ${v ? "granted" : "withdrawn"} from dashboard`, at: new Date().toISOString() })));
    res.json({ application: dashboardView(updated) });
  })
);

router.patch(
  "/",
  validate(z.object({
    first: z.string().trim().min(1, "Enter your first name").max(60).optional(),
    last: z.string().trim().min(1, "Enter your last name").max(60).optional(),
    phone: z.string().transform((s) => s.replace(/\D/g, "")).refine((s) => s.length === 10 || (s.length === 11 && s.startsWith("1")), "Enter a 10-digit US mobile number").optional(),
    lang: z.enum(["en", "es"]).optional(),
  })),
  ah(async (req, res) => {
    const u = await db.users.update(req.user.userId, req.body);
    res.json({ user: publicUser(u) });
  })
);

router.post(
  "/password",
  validate(z.object({ current: z.string().min(1, "Enter your current password").max(128), password: passwordSchema })),
  ah(async (req, res) => {
    if (!(await bcrypt.compare(req.body.current, req.user.passwordHash))) throw new HttpError(400, "Your current password isn't right", "BAD_PASSWORD", { field: "current" });
    const u = await db.users.update(req.user.userId, { passwordHash: await bcrypt.hash(req.body.password, 12), tokenVersion: (req.user.tokenVersion || 0) + 1 });
    await sendMail(u.email, "passwordChanged", { first: u.first, lang: u.lang });
    setSession(res, u); // keep this device signed in, sign out everywhere else
    res.json({ user: publicUser(u) });
  })
);

// Download a copy of your data (privacy).
router.get(
  "/export",
  ah(async (req, res) => {
    const leads = await db.leads.list({ userId: req.user.userId }, { omit: ["guestTokenHash"] });
    const data = {
      exportedAt: new Date().toISOString(),
      account: publicUser(req.user),
      applications: leads.map(({ dobEnc, addressEnc, events, ...l }) => ({ ...l, dateOfBirth: decrypt(dobEnc), address: decrypt(addressEnc) ? JSON.parse(decrypt(addressEnc)) : null, activity: events })),
    };
    res.setHeader("Content-Disposition", 'attachment; filename="debtify-my-data.json"');
    res.json(data);
  })
);

// Delete account: removes the login and personal details; keeps de-identified
// application records needed for compliance reporting.
router.delete(
  "/",
  validate(z.object({ password: z.string().min(1, "Enter your password to confirm").max(128) })),
  ah(async (req, res) => {
    if (!(await bcrypt.compare(req.body.password, req.user.passwordHash))) throw new HttpError(400, "That password isn't right", "BAD_PASSWORD", { field: "password" });
    const leads = await db.leads.list({ userId: req.user.userId }, { omit: ["events"] });
    for (const l of leads)
      await db.leads.update(l.leadId, { userId: null, guestTokenHash: null, first: null, last: null, phone: null, dobEnc: null, addressEnc: null, ssnLast4: null, status: ["ENROLLED", "SIGNED"].includes(l.status) ? "CANCELLED" : l.status });
    await db.users.remove(req.user.userId);
    clearSession(res);
    res.json({ ok: true });
  })
);

export default router;
