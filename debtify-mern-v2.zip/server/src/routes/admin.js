import { Router } from "express";
import { z } from "zod";
import { db } from "../config/db.js";
import { STEP_NAMES } from "../data/backends.js";
import { ah, HttpError, validate } from "../lib/http.js";
import { publicUser, requireRole } from "../middleware/auth.js";
import { buildSamples } from "../services/samples.js";
import { computeStats, reasonLabel } from "../services/stats.js";
import { publicLead } from "./leads.js";

const router = Router();
router.use(requireRole("staff", "admin"));
const usd = (n) => "$" + Math.round(n).toLocaleString("en-US");

router.get(
  "/stats",
  ah(async (req, res) => {
    const withSamples = req.query.samples !== "0";
    const real = await db.leads.list({ source: { $in: ["demo", "web"] } }, { omit: ["events"] });
    const samples = withSamples ? await db.leads.list({ source: "sample" }, { omit: ["events"] }) : [];
    res.json({ ...computeStats([...samples, ...real], real), store: db.kind, sampleCount: samples.length });
  })
);

// Searchable list of real applications.
router.get(
  "/leads",
  ah(async (req, res) => {
    const q = String(req.query.q || "").trim().slice(0, 60);
    const status = String(req.query.status || "");
    const query = { source: { $in: ["demo", "web"] } };
    if (status) query.status = status;
    let rows = await db.leads.list(query, { limit: 500, omit: ["events", "dobEnc", "addressEnc", "guestTokenHash"] });
    if (q) {
      const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      rows = rows.filter((l) => re.test(`${l.leadId} ${l.first || ""} ${l.last || ""} ${l.state || ""} ${l.status}`));
    }
    res.json({
      leads: rows.slice(0, 200).map((l) => ({
        leadId: l.leadId, source: l.source, first: l.first, last: l.last, state: l.state, lang: l.lang, status: l.status, step: l.step,
        stepName: STEP_NAMES[l.step] || "Declined", reason: l.dropReason ? reasonLabel(l.dropReason) : null, feeStatus: l.feeStatus,
        deposit: l.program?.monthlyDeposit || null, backend: l.program?.backendName || null, person: !!l.person, resolved: !!l.resolved, createdAt: l.createdAt,
      })),
    });
  })
);

router.get(
  "/leads/:id",
  ah(async (req, res) => {
    const l = await db.leads.get(req.params.id);
    if (!l || l.source === "sample") throw new HttpError(404, "Not found");
    const owner = l.userId ? publicUser(await db.users.get(l.userId)) : null;
    res.json({ lead: publicLead(l), events: l.events || [], owner });
  })
);

// Simulated partner webhooks: deposit results and fee lifecycle.
router.post(
  "/leads/:id/backend-event",
  validate(z.object({ type: z.enum(["PAYMENT1_CLEARED", "PAYMENT2_CLEARED", "PAYMENT2_FAILED", "DEBT_SETTLED"]) })),
  ah(async (req, res) => {
    const l = await db.leads.get(req.params.id);
    if (!l || !l.program?.monthlyDeposit) throw new HttpError(404, "No enrolled program");
    const type = req.body.type;
    const deposits = [...(l.deposits || [])];
    const setDep = (n, status) => { const d = deposits.find((x) => x.n === n); if (d) d.status = status; };
    const patch = { deposits };
    let text;
    if (type === "PAYMENT1_CLEARED" && l.feeStatus === "NOT_EARNED") {
      setDep(1, "CLEARED");
      Object.assign(patch, { feeStatus: "EARNED", status: "PAYMENT1_CLEARED" });
      text = `PAYMENT1_CLEARED → fee ${usd(l.program.debtifyFee)} EARNED`;
    } else if (type === "PAYMENT2_CLEARED" && l.feeStatus === "EARNED") {
      setDep(2, "CLEARED");
      Object.assign(patch, { feeStatus: "FINAL", status: "PAYMENT2_CLEARED" });
      text = "PAYMENT2_CLEARED → fee FINAL";
    } else if (type === "PAYMENT2_FAILED" && l.feeStatus === "EARNED") {
      setDep(2, "FAILED");
      Object.assign(patch, { feeStatus: "CLAWED_BACK", status: "CLAWBACK" });
      text = "PAYMENT2_FAILED → fee CLAWED BACK";
    } else if (type === "DEBT_SETTLED") {
      const t = (l.tradelines || []).find((x) => x.status === "ENROLLED");
      if (!t) throw new HttpError(409, "All enrolled debts are already settled");
      patch.tradelines = l.tradelines.map((x) => (x.tlId === t.tlId ? { ...x, status: "SETTLED" } : x));
      text = `DEBT_SETTLED → ${t.creditor}`;
    } else throw new HttpError(409, `Event ${type} not valid when fee is ${l.feeStatus}`);
    const ev = { tag: "BACKEND", text, at: new Date().toISOString() };
    const saved = await db.leads.update(l.leadId, patch);
    await db.leads.pushEvents(l.leadId, [ev]);
    res.json({ lead: publicLead(saved), events: [ev] });
  })
);

router.post(
  "/leads/:id/resolve",
  ah(async (req, res) => {
    const l = await db.leads.get(req.params.id);
    if (!l) throw new HttpError(404, "Not found");
    const ev = { tag: "EVENT", text: `exception resolved by ${req.user.email}`, at: new Date().toISOString() };
    await db.leads.update(l.leadId, { resolved: true });
    await db.leads.pushEvents(l.leadId, [ev]);
    res.json({ ok: true });
  })
);

// ---------- admin only: users and roles ----------
router.get(
  "/users",
  requireRole("admin"),
  ah(async (req, res) => {
    const users = await db.users.list({}, { limit: 500 });
    res.json({ users: users.map(publicUser) });
  })
);

router.patch(
  "/users/:id",
  requireRole("admin"),
  validate(z.object({ role: z.enum(["user", "staff", "admin"]) })),
  ah(async (req, res) => {
    if (req.params.id === req.user.userId) throw new HttpError(400, "You can't change your own role");
    const u = await db.users.update(req.params.id, { role: req.body.role, tokenVersion: Date.now() % 1e6 });
    if (!u) throw new HttpError(404, "Not found");
    res.json({ user: publicUser(u) });
  })
);

router.post(
  "/seed",
  requireRole("admin"),
  ah(async (req, res) => {
    if ((await db.leads.count({ source: "sample" })) === 0) await db.leads.insertMany(buildSamples());
    res.json({ ok: true, samples: await db.leads.count({ source: "sample" }) });
  })
);

export default router;
