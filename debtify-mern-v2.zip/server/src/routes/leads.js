import { Router } from "express";
import { z } from "zod";
import { db } from "../config/db.js";
import { env } from "../config/env.js";
import { CONSENT_TYPES, CONSENT_VERSION, DEBT_RANGES, DONE_STEP, MIN_DEBT, QUIZ_ANSWERS, SERVED, STATES, STEP_NAMES } from "../data/backends.js";
import { ah, HttpError, validate } from "../lib/http.js";
import { encrypt, newId, sha256 } from "../lib/crypto.js";
import { sendMail } from "../lib/mailer.js";
import { ensureGuest, guestHash, requireAuth } from "../middleware/auth.js";
import { route, tagTradeline } from "../services/routing.js";
import { idCheck, softPull, welcomeCall } from "../services/vendors.js";
import { buildDeposits, quickEstimate } from "../services/program.js";

const router = Router();
const usd = (n) => "$" + Math.round(n).toLocaleString("en-US");
const pad = (n) => String(n).padStart(2, "0");
const ACTIVE = ["STARTED", "QUALIFIED", "MATCHED", "SIGNED"];

// What the browser is allowed to see of a lead.
export function publicLead(l) {
  if (!l) return null;
  const { events, guestTokenHash, dobEnc, addressEnc, ...rest } = l;
  return rest;
}

function canAccess(req, lead) {
  if (!lead || lead.source === "sample") return false;
  if (lead.userId) return !!req.user && (req.user.userId === lead.userId || ["staff", "admin"].includes(req.user.role) && lead.source === "demo");
  const gh = guestHash(req);
  return !!gh && gh === lead.guestTokenHash;
}

// Loads the lead the caller may access, runs the handler, saves patch + events,
// and responds { lead, events, ...extra }.
const withLead = (fn, { auth = false } = {}) =>
  ah(async (req, res) => {
    if (auth && !req.user) throw new HttpError(401, "Please log in to continue", "AUTH_REQUIRED");
    const lead = await db.leads.get(req.params.id);
    if (!canAccess(req, lead)) throw new HttpError(404, "Application not found", "NOT_FOUND");
    const events = [];
    const log = (tag, text) => events.push({ tag, text, at: new Date().toISOString() });
    const ctx = { lead, log, patch: {}, extra: {}, user: req.user };
    await fn(req, ctx);
    let saved = lead;
    if (Object.keys(ctx.patch).length) saved = await db.leads.update(lead.leadId, ctx.patch);
    if (events.length) await db.leads.pushEvents(lead.leadId, events);
    res.json({ lead: publicLead(saved), events, ...ctx.extra });
  });

function goStep(ctx, n) {
  ctx.patch.step = n;
  ctx.patch.maxStep = Math.max(ctx.lead.maxStep || 1, n);
  ctx.log("EVENT", `step_view ${pad(n)} ${STEP_NAMES[n]} · ${(ctx.patch.lang || ctx.lead.lang || "en").toUpperCase()}`);
}
function decline(ctx, code) {
  Object.assign(ctx.patch, { status: "DECLINED", dropReason: code, step: 0 });
  ctx.log("DB", `application ${ctx.lead.leadId} → DECLINED (${code})`);
}
const atStep = (lead, ...steps) => {
  if (!steps.includes(lead.step)) throw new HttpError(409, "This step isn't available right now. Refresh to continue where you left off.", "WRONG_STEP");
};
const requireProgram = (lead) => {
  if (!lead.program?.monthlyDeposit) throw new HttpError(409, "No matched program yet", "NO_PROGRAM");
};

// ---------- screen 1: quick check (no account needed) ----------
router.post(
  "/",
  validate(z.object({
    debtRange: z.enum(Object.keys(DEBT_RANGES), { errorMap: () => ({ message: "Choose how much you owe" }) }),
    state: z.enum(STATES, { errorMap: () => ({ message: "Choose your state" }) }),
    paymentStatus: z.number().int().min(0).max(2, "Choose where you are with payments"),
    lang: z.enum(["en", "es"]).default("en"),
    source: z.enum(["web", "demo"]).default("web"),
    persona: z.string().max(40).optional(),
  })),
  ah(async (req, res) => {
    const b = req.body;
    const isStaff = req.user && ["staff", "admin"].includes(req.user.role);
    const source = b.source === "demo" && isStaff && env.demoMode ? "demo" : "web";
    const debt = DEBT_RANGES[b.debtRange].mid;
    const events = [];
    const log = (tag, text) => events.push({ tag, text, at: new Date().toISOString() });

    // Starting again replaces any unfinished application.
    const owner = req.user ? { userId: req.user.userId } : { guestTokenHash: ensureGuest(req, res), userId: null };
    if (source === "web") {
      const open = await db.leads.list({ ...owner, status: { $in: ACTIVE } }, { omit: ["events"] });
      for (const o of open) if (!o.dropReason && o.step < DONE_STEP && o.status !== "SIGNED") await db.leads.update(o.leadId, { dropReason: "LEFT_AT_STEP_" + pad(o.step) });
    }
    const lead = {
      leadId: newId("app"), ...owner, guestTokenHash: owner.guestTokenHash || null, source, persona: b.persona || null, lang: b.lang,
      state: b.state, debtRange: b.debtRange, debt, paymentStatus: b.paymentStatus, step: 1, maxStep: 1, status: "STARTED", dropReason: null,
      tradelines: [], program: null, feeStatus: "NOT_EARNED", clarity: {}, consents: [], deposits: [], events: [],
    };
    log("DB", `application ${lead.leadId} created · ${b.state} · ${DEBT_RANGES[b.debtRange].label} · ${b.lang.toUpperCase()}`);
    const ctx = { lead, log, patch: {} };
    const est = quickEstimate(b.state, debt);
    if (!SERVED.includes(b.state)) decline(ctx, "STATE_NOT_SERVED");
    else if (debt < MIN_DEBT) decline(ctx, "DEBT_UNDER_MIN");
    else if (!est) decline(ctx, "NO_BACKEND_FIT");
    else {
      ctx.patch.estimate = est;
      log("ROUTING", `quick estimate: ${usd(est.depositLow)}–${usd(est.depositHigh)}/mo over ${est.monthsLow}–${est.monthsHigh} months`);
      goStep(ctx, 2);
    }
    Object.assign(lead, ctx.patch, { events });
    const saved = await db.leads.create(lead);
    res.status(201).json({ lead: publicLead(saved), events });
  })
);

// The caller's most recent application (guest or signed in).
router.get(
  "/current",
  ah(async (req, res) => {
    let lead = null;
    if (req.user) lead = (await db.leads.list({ userId: req.user.userId, source: "web" }, { limit: 1, omit: ["events"] }))[0];
    if (!lead) {
      const gh = guestHash(req);
      if (gh) lead = (await db.leads.list({ guestTokenHash: gh, userId: null }, { limit: 1, omit: ["events"] }))[0];
    }
    res.json({ lead: publicLead(lead || null) });
  })
);

router.get("/:id", withLead(async () => {}));

// ---------- screen 2: estimate → account. Attach the application to the signed-in user. ----------
router.post(
  "/:id/claim",
  withLead(async (req, ctx) => {
    if (!ctx.lead.userId) {
      ctx.patch.userId = req.user.userId;
      ctx.log("DB", `application linked to account ${req.user.userId}`);
    }
    if (ctx.lead.step === 2) goStep(ctx, 3);
  }, { auth: true })
);

// Back navigation, language, and "Was this clear?" answers.
router.patch(
  "/:id",
  validate(z.object({ step: z.number().int().min(1).max(9).optional(), lang: z.enum(["en", "es"]).optional(), clarity: z.record(z.enum(["clear", "simpler"])).optional() })),
  withLead(async (req, ctx) => {
    const { step, lang, clarity } = req.body;
    if (lang && lang !== ctx.lead.lang) {
      ctx.patch.lang = lang;
      ctx.log("UX", `language → ${lang === "es" ? "Español" : "English"}`);
    }
    if (clarity) {
      const next = { ...ctx.lead.clarity };
      for (const [id, v] of Object.entries(clarity).slice(0, 10)) {
        next[id.slice(0, 20)] = v;
        ctx.log("UX", `clarity · ${id}: ${v === "simpler" ? "asked to explain simpler" : "marked clear"}`);
      }
      ctx.patch.clarity = next;
    }
    if (step !== undefined) {
      const l = ctx.lead;
      const locked = ["SIGNED", "ENROLLED", "DECLINED", "CANCELLED"].includes(l.status) || l.step >= 9;
      if (locked || step > l.maxStep || step < 3 && l.userId) throw new HttpError(409, "You can't go back to that step", "STEP_LOCKED");
      goStep(ctx, step);
    }
  })
);

// ---------- screen 3: verify identity + permissions → ID check + soft credit pull ----------
const identitySchema = z.object({
  dob: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Enter your date of birth"),
  ssn: z.string().transform((s) => s.replace(/\D/g, "")).refine((s) => s.length === 9, "Enter all 9 digits of your Social Security number"),
  address: z.string().trim().min(3, "Enter your street address").max(120),
  city: z.string().trim().min(2, "Enter your city").max(60),
  zip: z.string().trim().regex(/^\d{5}$/, "Enter a 5-digit ZIP code"),
  consents: z.record(z.boolean()),
  consentTexts: z.record(z.string().max(2000)).optional(),
  first: z.string().trim().max(60).optional(),
  last: z.string().trim().max(60).optional(),
  phone: z.string().max(20).optional(),
});
router.post(
  "/:id/identity",
  validate(identitySchema),
  withLead(async (req, ctx) => {
    atStep(ctx.lead, 3);
    const b = req.body;
    const age = (Date.now() - new Date(b.dob + "T12:00:00Z").getTime()) / (365.25 * 864e5);
    if (!(age >= 18 && age < 120)) throw new HttpError(400, "You must be 18 or older to apply", "VALIDATION", { field: "dob" });
    for (const c of CONSENT_TYPES) {
      if (c.required && !b.consents[c.type]) {
        ctx.log("GUARD", `blocked: ${c.type} consent is required`);
        throw new HttpError(400, "Please agree to the required permissions to continue", "CONSENT_REQUIRED", { field: c.type });
      }
    }
    const lang = ctx.lead.lang || "en";
    ctx.patch.consents = CONSENT_TYPES.map((c) => {
      const granted = !!b.consents[c.type];
      ctx.log("CONSENT", `${c.type} ${granted ? "granted" : "declined"} · ${lang.toUpperCase()} text v ${CONSENT_VERSION} · sha256 stored`);
      return { type: c.type, granted, lang, version: CONSENT_VERSION, textHash: sha256(b.consentTexts?.[c.type] || c.type), at: new Date().toISOString() };
    });
    // Demo personas may override name/phone; real users use their account details.
    const demo = ctx.lead.source === "demo";
    const u = ctx.user;
    Object.assign(ctx.patch, {
      first: (demo && b.first) || u.first,
      last: (demo && b.last) || u.last,
      phone: String((demo && b.phone) || u.phone || "").replace(/\D/g, ""),
      ssnLast4: b.ssn.slice(-4),
      dobEnc: encrypt(b.dob),
      addressEnc: encrypt(JSON.stringify({ address: b.address, city: b.city, zip: b.zip, state: ctx.lead.state })),
      share: !!b.consents.SHARING,
    });
    const kyc = await idCheck(b.ssn);
    ctx.patch.kyc = kyc;
    ctx.log("VENDOR", `ID check (mock) → ${kyc}`);
    if (kyc === "FAIL") return decline(ctx, "KYC_FAILED");
    const raw = await softPull(b.ssn);
    if (!raw) {
      ctx.log("VENDOR", "soft pull → no credit file");
      return decline(ctx, "NO_CREDIT_FILE");
    }
    ctx.log("VENDOR", `soft pull (mock) → ${raw.length} accounts`);
    const tradelines = raw.map(tagTradeline);
    tradelines.forEach((tl) => ctx.log(tl.needsReview ? "AI" : "ROUTING", `${tl.creditor}: ${tl.type}${tl.needsReview ? " (unclear → ask user)" : ""} → ${tl.enrollable ? "enrollable" : "excluded"}`));
    ctx.log("DB", "full SSN discarded after vendor calls; date of birth and address encrypted (AES-256-GCM)");
    Object.assign(ctx.patch, { tradelines, status: "QUALIFIED" });
    goStep(ctx, 4);
  }, { auth: true })
);

// ---------- screen 4: choose debts ----------
router.put(
  "/:id/debts",
  validate(z.object({ tradelines: z.array(z.object({ tlId: z.string(), selected: z.boolean().optional(), confirmed: z.string().nullable().optional() })).max(50), advance: z.boolean().optional() })),
  withLead(async (req, ctx) => {
    atStep(ctx.lead, 4);
    const allowed = ["MEDICAL", "CREDIT_CARD", "COLLECTION"];
    const tradelines = ctx.lead.tradelines.map((tl) => {
      const p = req.body.tradelines.find((z) => z.tlId === tl.tlId);
      if (!p) return tl;
      const next = { ...tl };
      if (tl.needsReview) {
        if (allowed.includes(p.confirmed)) {
          if (next.confirmed !== p.confirmed) ctx.log("DB", `${tl.creditor} confirmed by user as ${p.confirmed}`);
          Object.assign(next, { confirmed: p.confirmed, type: p.confirmed, enrollable: true });
        } else Object.assign(next, { confirmed: null, type: "OTHER", enrollable: false });
      }
      next.selected = next.enrollable ? !!p.selected : false;
      return next;
    });
    const total = tradelines.filter((z) => z.selected && z.enrollable).reduce((s, z) => s + z.balance, 0);
    ctx.patch.tradelines = tradelines;
    ctx.extra.total = total;
    if (req.body.advance) {
      if (!total) throw new HttpError(400, "Choose at least one debt to include", "NO_DEBTS");
      ctx.log("DB", `debts selected: ${usd(total)}`);
      goStep(ctx, 5);
    }
  }, { auth: true })
);

// ---------- screen 5: budget → matching engine ----------
router.post(
  "/:id/budget",
  validate(z.object({ income: z.coerce.number().min(0).max(1e6), expenses: z.coerce.number().min(0).max(1e6), bankLinked: z.boolean().optional(), linkOnly: z.boolean().optional() })),
  withLead(async (req, ctx) => {
    atStep(ctx.lead, 5);
    const { income, expenses } = req.body;
    if (req.body.bankLinked && !ctx.lead.bankLinked) ctx.log("VENDOR", "Plaid Link (mock) → account linked");
    Object.assign(ctx.patch, { income, expenses, bankLinked: !!req.body.bankLinked || ctx.lead.bankLinked });
    if (req.body.linkOnly) return;
    if (!income) throw new HttpError(400, "Enter your monthly take-home income", "VALIDATION", { field: "income" });
    const r = route({ state: ctx.lead.state, debts: ctx.lead.tradelines, income, expenses });
    r.rejected.forEach((z) => ctx.log("ROUTING", `${z.id}: rejected (${z.r.join(", ")})`));
    if (r.decision !== "MATCH") {
      ctx.log("ROUTING", `no fit → ${r.reasonCode}`);
      return decline(ctx, r.reasonCode);
    }
    r.scores.forEach(([n, s]) => ctx.log("ROUTING", `${n}: fits · score ${s}`));
    Object.assign(ctx.patch, { program: r.program, backend: r.program.backendId, status: "MATCHED" });
    ctx.log("ROUTING", `matched ${r.program.backendName}: ${usd(r.program.monthlyDeposit)}/mo × ${r.program.termMonths}`);
    goStep(ctx, 6);
  }, { auth: true })
);

// ---------- screen 6: your plan (costs and timing acknowledged) ----------
router.post(
  "/:id/acknowledge",
  validate(z.object({ acknowledged: z.literal(true, { errorMap: () => ({ message: "Please confirm you've read how the fees and timing work" }) }) })),
  withLead(async (req, ctx) => {
    atStep(ctx.lead, 6);
    requireProgram(ctx.lead);
    ctx.patch.costsAcknowledged = true;
    ctx.log("CONSENT", `costs and timing acknowledged · ${(ctx.lead.lang || "en").toUpperCase()}`);
    goStep(ctx, 7);
  }, { auth: true })
);

// ---------- screen 7: risks + quick check (graded on the server) ----------
router.post(
  "/:id/quiz",
  validate(z.object({ answers: z.record(z.number().int()) })),
  withLead(async (req, ctx) => {
    atStep(ctx.lead, 7);
    const wrong = Object.entries(QUIZ_ANSWERS).filter(([id, c]) => req.body.answers[id] !== c).map(([id]) => id);
    const attempts = (ctx.lead.quizAttempts || 0) + 1;
    ctx.patch.quizAttempts = attempts;
    ctx.extra.wrong = wrong;
    if (wrong.length) return ctx.log("AI", `quick check attempt ${attempts}: ${wrong.length} wrong → re-explained`);
    ctx.log("EVENT", `quick check passed on attempt ${attempts}`);
    goStep(ctx, 8);
  }, { auth: true })
);

// ---------- screen 8: deposits + sign ----------
router.post(
  "/:id/deposits",
  withLead(async (req, ctx) => {
    atStep(ctx.lead, 8);
    ctx.patch.depositAccountLinked = true;
    ctx.log("VENDOR", "Plaid Link (mock) → deposit account verified");
  }, { auth: true })
);

router.post(
  "/:id/enroll",
  validate(z.object({ accept: z.boolean(), draftDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional() })),
  withLead(async (req, ctx) => {
    atStep(ctx.lead, 8);
    requireProgram(ctx.lead);
    if (!req.body.accept) {
      ctx.log("EVENT", "declined to sign");
      return decline(ctx, "ESIGN_DECLINED");
    }
    if (!ctx.lead.depositAccountLinked) throw new HttpError(400, "Link the bank account for your deposits first", "BANK_REQUIRED");
    const d = new Date(req.body.draftDate + "T12:00:00Z").getTime();
    if (!d || d < Date.now() + 3 * 864e5 - 432e5 || d > Date.now() + 45 * 864e5) throw new HttpError(400, "Choose a first deposit date between 3 and 45 days from today", "BAD_DATE", { field: "draftDate" });
    if (ctx.lead.source !== "demo" && !ctx.user.emailVerified) throw new HttpError(403, "Please confirm your email before signing. We sent you a link.", "EMAIL_UNVERIFIED");
    ctx.patch.draftDate = req.body.draftDate;
    ctx.log("DB", `first deposit date ${req.body.draftDate}`);
    ctx.log("VENDOR", `e-sign envelope created and signed (${(ctx.lead.lang || "en").toUpperCase()})`);
    Object.assign(ctx.patch, { status: "SIGNED", signedAt: new Date().toISOString() });
    goStep(ctx, 9);
  }, { auth: true })
);

// ---------- screen 9: welcome call → enrolled ----------
router.post(
  "/:id/call",
  withLead(async (req, ctx) => {
    atStep(ctx.lead, 9);
    requireProgram(ctx.lead);
    const l = ctx.lead;
    if (l.status !== "SIGNED") throw new HttpError(409, "Sign your agreement first", "NOT_SIGNED");
    if (l.callResult === "NEEDS_HUMAN") throw new HttpError(409, "A member of our team will call you to finish up", "NEEDS_HUMAN");
    ctx.log("VENDOR", `AI voice call (mock, ${l.lang === "es" ? "Spanish" : "English"}) → dialing ***${String(l.phone).slice(-4)}, recording on`);
    const call = welcomeCall({ first: l.first, phone: l.phone, program: l.program, lang: l.lang });
    ctx.extra.call = call;
    ctx.patch.callResult = call.result;
    if (call.result === "NEEDS_HUMAN") {
      ctx.patch.dropReason = "CALL_NEEDS_HUMAN";
      ctx.log("GUARD", "promise-of-result detected → exception desk");
      return;
    }
    ctx.log("VENDOR", "call PASSED");
    ctx.log("BACKEND", `enrollment POSTed to ${l.program.backendName} (HMAC-signed)`);
    Object.assign(ctx.patch, {
      status: "ENROLLED",
      enrolledAt: new Date().toISOString(),
      deposits: buildDeposits(l.program, l.draftDate),
      tradelines: l.tradelines.map((t) => (t.selected && t.enrollable ? { ...t, status: (l.program.includedTlIds || []).includes(t.tlId) || !l.program.includedTlIds ? "ENROLLED" : "NOT_INCLUDED" } : t)),
    });
    goStep(ctx, DONE_STEP);
    const date = new Date(l.draftDate + "T12:00:00Z").toLocaleDateString(l.lang === "es" ? "es-US" : "en-US", { month: "long", day: "numeric", timeZone: "UTC" });
    if (ctx.user?.email) await sendMail(ctx.user.email, "enrolled", { first: l.first, deposit: usd(l.program.monthlyDeposit), date, company: l.program.backendName, lang: l.lang });
  }, { auth: true })
);

router.post(
  "/:id/person",
  withLead(async (req, ctx) => {
    ctx.patch.person = true;
    ctx.patch.resolved = false;
    ctx.log("EVENT", "talk_to_person → exception desk");
  })
);

router.post(
  "/:id/abandon",
  withLead(async (req, ctx) => {
    const l = ctx.lead;
    if (l.step > 0 && l.step < DONE_STEP && !l.dropReason && !["SIGNED", "ENROLLED"].includes(l.status)) {
      ctx.patch.dropReason = "LEFT_AT_STEP_" + pad(l.step);
      ctx.log("EVENT", `exit at step ${l.step} → ${ctx.patch.dropReason}`);
    }
  })
);

export default router;
