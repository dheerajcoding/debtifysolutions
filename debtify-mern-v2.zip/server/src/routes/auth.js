import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "../config/db.js";
import { env } from "../config/env.js";
import { ah, HttpError, validate } from "../lib/http.js";
import { newId, randomToken, sha256 } from "../lib/crypto.js";
import { sendMail } from "../lib/mailer.js";
import { clearSession, guestHash, publicUser, requireAuth, setSession } from "../middleware/auth.js";
import { authLimiter, emailLimiter } from "../middleware/security.js";

const router = Router();

const COMMON = new Set(["password", "password1", "password123", "12345678", "123456789", "qwerty123", "iloveyou1", "abc12345", "debtify123", "letmein1"]);
export const passwordSchema = z
  .string()
  .min(8, "Use at least 8 characters for your password")
  .max(128, "Password is too long")
  .refine((p) => /[a-zA-Z]/.test(p) && /\d/.test(p), "Use letters and at least one number in your password")
  .refine((p) => !COMMON.has(p.toLowerCase()), "That password is too common. Try another one");
const email = z.string().trim().toLowerCase().email("Enter a valid email address").max(200);
const name = (label) => z.string().trim().min(1, `Enter your ${label}`).max(60);
const phone = z.string().transform((s) => s.replace(/\D/g, "")).refine((s) => s.length === 10 || (s.length === 11 && s.startsWith("1")), "Enter a 10-digit US mobile number");

const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 12);
const MAX_FAILED = 5;
const LOCK_MIN = 15;

// Attaches any applications started as a guest on this browser to the account.
async function claimGuestLeads(req, user) {
  const gh = guestHash(req);
  if (!gh) return;
  await db.leads.updateMany({ guestTokenHash: gh, userId: null }, { userId: user.userId });
}

async function sendVerification(user) {
  const token = randomToken();
  await db.users.update(user.userId, { verifyTokenHash: sha256(token), verifyExpires: new Date(Date.now() + 24 * 36e5).toISOString() });
  return sendMail(user.email, "verify", { first: user.first, lang: user.lang, url: `${env.appUrl}/verify-email?token=${token}` });
}

router.post(
  "/register",
  authLimiter,
  validate(z.object({ first: name("first name"), last: name("last name"), email, phone, password: passwordSchema, lang: z.enum(["en", "es"]).default("en"), terms: z.literal(true, { errorMap: () => ({ message: "Please agree to the Terms and Privacy Policy" }) }) })),
  ah(async (req, res) => {
    const b = req.body;
    if (await db.users.findOne({ email: b.email })) throw new HttpError(409, "An account with this email already exists. Log in instead.", "EMAIL_TAKEN");
    const user = await db.users.create({
      userId: newId("usr"), email: b.email, passwordHash: await bcrypt.hash(b.password, 12), first: b.first, last: b.last, phone: b.phone,
      lang: b.lang, role: "user", emailVerified: false, tokenVersion: 0, failedLogins: 0,
    });
    await sendVerification(user);
    await claimGuestLeads(req, user);
    setSession(res, user);
    res.status(201).json({ user: publicUser(user) });
  })
);

router.post(
  "/login",
  authLimiter,
  validate(z.object({ email, password: z.string().min(1, "Enter your password").max(128) })),
  ah(async (req, res) => {
    const user = await db.users.findOne({ email: req.body.email });
    const bad = () => new HttpError(401, "That email and password don't match. Try again or reset your password.", "BAD_LOGIN");
    if (!user) {
      await bcrypt.compare(req.body.password, DUMMY_HASH); // keeps response time the same
      throw bad();
    }
    if (user.lockUntil && new Date(user.lockUntil) > new Date()) throw new HttpError(423, `Too many wrong passwords. Try again in ${LOCK_MIN} minutes or reset your password.`, "LOCKED");
    const ok = await bcrypt.compare(req.body.password, user.passwordHash);
    if (!ok) {
      const failed = (user.failedLogins || 0) + 1;
      await db.users.update(user.userId, failed >= MAX_FAILED ? { failedLogins: 0, lockUntil: new Date(Date.now() + LOCK_MIN * 6e4).toISOString() } : { failedLogins: failed });
      throw bad();
    }
    const fresh = await db.users.update(user.userId, { failedLogins: 0, lockUntil: null, lastLoginAt: new Date().toISOString() });
    await claimGuestLeads(req, fresh);
    setSession(res, fresh);
    res.json({ user: publicUser(fresh) });
  })
);

router.post("/logout", (req, res) => {
  clearSession(res);
  res.json({ ok: true });
});

router.post(
  "/logout-all",
  requireAuth,
  ah(async (req, res) => {
    await db.users.update(req.user.userId, { tokenVersion: (req.user.tokenVersion || 0) + 1 });
    clearSession(res);
    res.json({ ok: true });
  })
);

router.get("/me", (req, res) => res.json({ user: publicUser(req.user) }));

router.post(
  "/verify-email",
  validate(z.object({ token: z.string().min(10).max(200) })),
  ah(async (req, res) => {
    const user = await db.users.findOne({ verifyTokenHash: sha256(req.body.token) });
    if (!user || !user.verifyExpires || new Date(user.verifyExpires) < new Date()) throw new HttpError(400, "This link has expired or was already used. Request a new one from your dashboard.", "BAD_TOKEN");
    const u = await db.users.update(user.userId, { emailVerified: true, verifyTokenHash: null, verifyExpires: null });
    res.json({ user: publicUser(u) });
  })
);

router.post(
  "/resend-verification",
  requireAuth,
  emailLimiter,
  ah(async (req, res) => {
    if (req.user.emailVerified) return res.json({ ok: true, already: true });
    await sendVerification(req.user);
    res.json({ ok: true });
  })
);

router.post(
  "/forgot-password",
  emailLimiter,
  validate(z.object({ email })),
  ah(async (req, res) => {
    const user = await db.users.findOne({ email: req.body.email });
    if (user) {
      const token = randomToken();
      await db.users.update(user.userId, { resetTokenHash: sha256(token), resetExpires: new Date(Date.now() + 36e5).toISOString() });
      await sendMail(user.email, "reset", { first: user.first, lang: user.lang, url: `${env.appUrl}/reset-password?token=${token}` });
    }
    // Same answer either way so the form can't be used to discover accounts.
    res.json({ ok: true });
  })
);

router.post(
  "/reset-password",
  authLimiter,
  validate(z.object({ token: z.string().min(10).max(200), password: passwordSchema })),
  ah(async (req, res) => {
    const user = await db.users.findOne({ resetTokenHash: sha256(req.body.token) });
    if (!user || !user.resetExpires || new Date(user.resetExpires) < new Date()) throw new HttpError(400, "This reset link has expired or was already used. Request a new one.", "BAD_TOKEN");
    const u = await db.users.update(user.userId, {
      passwordHash: await bcrypt.hash(req.body.password, 12), resetTokenHash: null, resetExpires: null,
      tokenVersion: (user.tokenVersion || 0) + 1, failedLogins: 0, lockUntil: null, emailVerified: true,
    });
    await sendMail(u.email, "passwordChanged", { first: u.first, lang: u.lang });
    setSession(res, u);
    res.json({ user: publicUser(u) });
  })
);

export default router;
