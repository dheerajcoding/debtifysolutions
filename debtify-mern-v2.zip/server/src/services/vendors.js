// Simulated third-party vendors for staging: identity check, soft credit pull,
// bank link, e-sign and the AI welcome call. Swap these for real integrations later.

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

// SSN ending 0000 fails, 2222 needs review, anything else passes.
export async function idCheck(ssn) {
  await wait(300);
  const l4 = ssn.slice(-4);
  return l4 === "0000" ? "FAIL" : l4 === "2222" ? "REVIEW" : "PASS";
}

// SSN ending 1111 has no file, 3333 has a thin file, anything else gets the full sample file.
export async function softPull(ssn) {
  await wait(300);
  const l4 = ssn.slice(-4);
  if (l4 === "1111") return null;
  if (l4 === "3333")
    return [
      { creditor: "Capital Bank Card", acct: "Revolving", ind: "Bank card", balance: 3200 },
      { creditor: "Metro Medical Group", acct: "Open", ind: "Medical", balance: 900 },
    ];
  return sampleFile();
}

// The standard sample credit file (7 accounts) used by most test SSNs.
export function sampleFile() {
  return [
    { creditor: "Capital Bank Card", acct: "Revolving", ind: "Bank card", balance: 9800 },
    { creditor: "Summit Rewards Visa", acct: "Revolving", ind: "Bank card", balance: 7400 },
    { creditor: "Harbor Personal Loans", acct: "Installment", ind: "Personal loan", balance: 8600 },
    { creditor: "Metro Medical Group", acct: "Open", ind: "Medical", balance: 2100 },
    { creditor: "Lakeside Home Mortgage", acct: "Mortgage", ind: "Mortgage", balance: 182000 },
    { creditor: "Prairie Auto Finance", acct: "Installment", ind: "Auto", balance: 14300, secured: true },
    { creditor: "Northwind Services LLC", acct: "Open", ind: "", balance: 1250 },
  ];
}

const usd = (n) => "$" + Math.round(n).toLocaleString("en-US");

// Builds the scripted welcome-call transcript. A phone ending in 99 simulates
// a consumer who was promised a result, which routes the call to a person.
export function welcomeCall({ first, phone, program, lang }) {
  const human = String(phone || "").endsWith("99");
  const p = program;
  const es = lang === "es";
  const pct = Math.round(p.clientFeePct * 100);
  const lines = es
    ? [
        ["IA", `Hola ${first}, soy la asistente de Debtify en una línea grabada. ¿Puedes confirmar tu fecha de nacimiento?`],
        ["Cliente", "Sí, está en mi formulario."],
        ["IA", `Tu depósito es de ${usd(p.monthlyDeposit)} al mes durante unos ${p.termMonths} meses. La tarifa es el ${pct}% de la deuda inscrita, solo después de liquidar cada deuda. ¿Está claro?`],
        ["Cliente", human ? "Espera, el señor en línea me dijo que mi deuda desaparecería en un año." : "Sí, está claro."],
        ["IA", human ? "Quiero que recibas la respuesta correcta. Te comunico con una persona de nuestro equipo." : "Tu puntaje bajará y los acreedores aún pueden demandarte. ¿Alguien te prometió un resultado?"],
      ]
    : [
        ["AI", `Hi ${first}, this is Debtify's assistant on a recorded line. Can you confirm your date of birth?`],
        ["Client", "Sure, it's on my form."],
        ["AI", `Your deposit is ${usd(p.monthlyDeposit)} a month for about ${p.termMonths} months. The fee is ${pct}% of enrolled debt, only after each debt settles. Is that clear?`],
        ["Client", human ? "Wait, the guy online said my debt would be gone in a year?" : "Yes, that's clear."],
        ["AI", human ? "I want to make sure you get the right answer. I'm connecting you with a member of our team." : "Your credit score will drop and creditors may still sue. Did anyone promise you a result?"],
      ];
  if (!human) {
    lines.push(es ? ["Cliente", "No."] : ["Client", "No."]);
    lines.push(es ? ["IA", "Gracias. Puedes cancelar cuando quieras. Tu primer depósito está programado. ¡Bienvenido!"] : ["AI", "Thanks. You can cancel any time. Your first deposit is set. Welcome aboard."]);
  }
  return { result: human ? "NEEDS_HUMAN" : "PASSED", lines: lines.map(([who, text]) => ({ who, text })) };
}
