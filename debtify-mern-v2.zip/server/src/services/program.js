import { BACKENDS } from "../data/backends.js";
import { decrypt } from "../lib/crypto.js";

// Quick, honest estimate shown after the first screen: a range across partner programs
// that serve the state and accept this amount of debt. Not a quote.
export function quickEstimate(state, debt) {
  const fits = BACKENDS.filter((b) => b.states.includes(state) && debt >= b.min && debt <= b.max);
  if (!fits.length) return null;
  const totals = fits.map((b) => ({ total: Math.round(debt * (b.settle + b.fee)), min: Math.min(...b.terms), max: Math.max(...b.terms) }));
  const lowDep = Math.min(...totals.map((t) => Math.ceil(t.total / t.max)));
  const highDep = Math.max(...totals.map((t) => Math.ceil(t.total / t.min)));
  const lowTotal = Math.min(...totals.map((t) => t.total));
  const highTotal = Math.max(...totals.map((t) => t.total));
  return {
    debt,
    depositLow: lowDep,
    depositHigh: highDep,
    monthsLow: Math.min(...totals.map((t) => t.min)),
    monthsHigh: Math.max(...totals.map((t) => t.max)),
    totalLow: lowTotal,
    totalHigh: highTotal,
    savingsLow: Math.max(0, debt - highTotal),
    savingsHigh: Math.max(0, debt - lowTotal),
  };
}

const addMonths = (iso, n) => {
  const d = new Date(iso + "T12:00:00Z");
  const day = d.getUTCDate();
  d.setUTCMonth(d.getUTCMonth() + n, 1);
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, last));
  return d.toISOString().slice(0, 10);
};

// Monthly deposit schedule created at enrollment.
export function buildDeposits(program, draftDate) {
  return Array.from({ length: program.termMonths }, (_, i) => ({ n: i + 1, date: addMonths(draftDate, i), amount: program.monthlyDeposit, status: "SCHEDULED" }));
}

// The customer dashboard view of an application.
export function dashboardView(lead) {
  if (!lead) return null;
  const deposits = lead.deposits || [];
  const cleared = deposits.filter((d) => d.status === "CLEARED");
  const saved = cleared.reduce((s, d) => s + d.amount, 0);
  const next = deposits.find((d) => d.status === "SCHEDULED");
  const inc = lead.program?.includedTlIds;
  const enrolledDebts = (lead.tradelines || []).filter((t) => t.selected && t.enrollable && (!inc || inc.includes(t.tlId))).map((t) => ({ tlId: t.tlId, creditor: t.creditor, type: t.type, balance: t.balance, status: t.status || "ENROLLED" }));
  const addr = decrypt(lead.addressEnc);
  return {
    leadId: lead.leadId,
    status: lead.status,
    step: lead.step,
    maxStep: lead.maxStep,
    dropReason: lead.dropReason,
    lang: lead.lang,
    state: lead.state,
    debtRange: lead.debtRange,
    estimate: lead.estimate,
    program: lead.program,
    draftDate: lead.draftDate,
    enrolledAt: lead.enrolledAt,
    signedAt: lead.signedAt,
    cancelledAt: lead.cancelledAt,
    callResult: lead.callResult,
    feeStatus: lead.feeStatus,
    person: lead.person,
    consents: (lead.consents || []).map(({ type, granted, at, version }) => ({ type, granted, at, version })),
    address: addr ? JSON.parse(addr) : null,
    ssnLast4: lead.ssnLast4,
    debts: enrolledDebts,
    deposits,
    summary: {
      saved,
      depositsMade: cleared.length,
      depositsTotal: deposits.length,
      nextDeposit: next || null,
      progressPct: deposits.length ? Math.round((cleared.length / deposits.length) * 100) : 0,
      settled: enrolledDebts.filter((d) => d.status === "SETTLED").length,
    },
    createdAt: lead.createdAt,
    updatedAt: lead.updatedAt,
  };
}
