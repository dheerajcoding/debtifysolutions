import { BACKENDS, DEBTIFY_FEE, SERVED } from "../data/backends.js";

// 180 deterministic example leads so the admin dashboard has something to show.
export function buildSamples() {
  let s = 7;
  const rnd = () => (s = (s * 9301 + 49297) % 233280) / 233280;
  const drops = ["LEFT_AT_STEP_02", "LEFT_AT_STEP_03", "LEFT_AT_STEP_05", "LEFT_AT_STEP_07", "NOT_AFFORDABLE", "DEBT_UNDER_MIN", "STATE_NOT_SERVED", "KYC_FAILED", "NO_BACKEND_FIT"];
  const pts = ["fee", "timing", "estimate", "account", "credit", "collections", "tax", "cancel"];
  const out = [];
  const base = Date.now();
  for (let i = 0; i < 180; i++) {
    const r = rnd();
    const b = BACKENDS[Math.floor(rnd() * 4)];
    const debt = 12000 + Math.round((rnd() * 30000) / 500) * 500;
    const lang = rnd() < 0.3 ? "es" : "en";
    let maxStep, status, drop = null, fee = "NOT_EARNED";
    if (r < 0.09) {
      maxStep = 10;
      status = rnd() < 0.8 ? "PAYMENT1_CLEARED" : "ENROLLED";
      fee = status === "PAYMENT1_CLEARED" ? (rnd() < 0.15 ? "CLAWED_BACK" : rnd() < 0.5 ? "FINAL" : "EARNED") : "NOT_EARNED";
    } else {
      drop = drops[Math.floor(rnd() * drops.length)];
      maxStep = drop.startsWith("LEFT") ? +drop.slice(-2) : drop === "STATE_NOT_SERVED" || drop === "DEBT_UNDER_MIN" ? 1 : drop === "KYC_FAILED" ? 3 : 5;
      status = drop.startsWith("LEFT") ? "STARTED" : "DECLINED";
    }
    const clarity = {};
    pts.forEach((p, k) => {
      if (maxStep >= (k < 4 ? 7 : 8) && rnd() < 0.7) clarity[p] = rnd() < (p === "fee" || p === "tax" ? 0.35 : 0.15) ? "simpler" : "clear";
    });
    const created = new Date(base - Math.floor(rnd() * 30 * 864e5)).toISOString();
    out.push({
      leadId: "sample_" + i, userId: null, source: "sample", maxStep, step: maxStep, status, dropReason: drop,
      backend: maxStep >= 6 ? b.id : null, program: maxStep >= 6 ? { debtifyFee: Math.round(debt * DEBTIFY_FEE) } : null,
      feeStatus: fee, share: rnd() < 0.7, first: ["Ana", "Ben", "Cara", "Dev", "Eli"][i % 5], state: SERVED[i % SERVED.length], lang, clarity, debt,
      createdAt: created, updatedAt: created,
    });
  }
  out.push({ leadId: "sample_x1", userId: null, source: "sample", maxStep: 9, step: 9, status: "SIGNED", dropReason: "CALL_NEEDS_HUMAN", backend: "backend-b", program: { debtifyFee: 1800 }, feeStatus: "NOT_EARNED", share: true, first: "Rae", state: "GA", lang: "es", clarity: {} });
  return out;
}
