// End-to-end API tests against the in-memory store: npm test
process.env.NODE_ENV = "test";
process.env.MONGO_URI = "";
process.env.ADMIN_EMAIL = "";

import test from "node:test";
import assert from "node:assert/strict";

const { createApp } = await import("../app.js");
const { db } = await import("../config/db.js");
const { devOutbox } = await import("../lib/mailer.js");

const server = createApp().listen(0);
const base = `http://127.0.0.1:${server.address().port}/api`;
test.after(() => server.close());

// Tiny client with its own cookie jar, like a browser.
function client() {
  const jar = new Map();
  const call = async (method, path, body, { header = true } = {}) => {
    const res = await fetch(base + path, {
      method,
      headers: { ...(body ? { "content-type": "application/json" } : {}), ...(header ? { "X-Requested-With": "debtify" } : {}), cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; ") },
      body: body ? JSON.stringify(body) : undefined,
    });
    for (const c of res.headers.getSetCookie()) {
      const [kv] = c.split(";");
      const [k, ...v] = kv.split("=");
      if (/Expires=Thu, 01 Jan 1970/.test(c)) jar.delete(k);
      else jar.set(k, v.join("="));
    }
    return { status: res.status, body: await res.json().catch(() => ({})) };
  };
  return { call, jar };
}

const inDays = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
const IDENTITY = { dob: "1984-06-02", ssn: "123-45-6789", address: "100 Main St", city: "Austin", zip: "73301", consents: { CREDIT_PULL: true, ESIGN: true, CALLS_TEXTS: true, SHARING: false } };

test("rejects state-changing calls without the app header (CSRF)", async () => {
  const c = client();
  const r = await c.call("POST", "/auth/login", { email: "a@b.co", password: "x" }, { header: false });
  assert.equal(r.status, 403);
  assert.equal(r.body.code, "CSRF");
});

test("register validates passwords and rejects duplicates", async () => {
  const c = client();
  const weak = await c.call("POST", "/auth/register", { first: "A", last: "B", email: "weak@example.com", phone: "5125550100", password: "password", terms: true });
  assert.equal(weak.status, 400);
  const ok = await c.call("POST", "/auth/register", { first: "A", last: "B", email: "dup@example.com", phone: "5125550100", password: "Sunrise2026", terms: true });
  assert.equal(ok.status, 201);
  const dup = await client().call("POST", "/auth/register", { first: "A", last: "B", email: "DUP@example.com", phone: "5125550100", password: "Sunrise2026", terms: true });
  assert.equal(dup.status, 409);
});

test("full journey: guest quick check → account → enroll → dashboard", async () => {
  const c = client();
  const start = await c.call("POST", "/leads", { debtRange: "25000-50000", state: "TX", paymentStatus: 0, lang: "en" });
  assert.equal(start.status, 201);
  const id = start.body.lead.leadId;
  assert.equal(start.body.lead.step, 2);
  assert.ok(start.body.lead.estimate.depositLow > 0);
  assert.equal(start.body.lead.guestTokenHash, undefined, "guest token hash never leaves the server");

  // identity requires an account
  assert.equal((await c.call("POST", `/leads/${id}/identity`, IDENTITY)).status, 401);

  const reg = await c.call("POST", "/auth/register", { first: "Maria", last: "Lopez", email: "maria@example.com", phone: "(512) 555-0142", password: "Sunrise2026", terms: true });
  assert.equal(reg.status, 201);
  assert.equal(reg.body.user.emailVerified, false);
  let r = await c.call("POST", `/leads/${id}/claim`);
  assert.equal(r.body.lead.step, 3);

  r = await c.call("POST", `/leads/${id}/identity`, IDENTITY);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.lead.step, 4);
  assert.equal(r.body.lead.ssnLast4, "6789");
  const stored = await db.leads.get(id);
  assert.ok(!JSON.stringify(stored).includes("123456789"), "full SSN not stored");
  assert.ok(stored.dobEnc.startsWith("v1:") && !stored.dobEnc.includes("1984"), "DOB encrypted");

  const tls = r.body.lead.tradelines.map((t) => ({ tlId: t.tlId, selected: t.enrollable || t.needsReview, confirmed: t.needsReview ? "MEDICAL" : null }));
  r = await c.call("PUT", `/leads/${id}/debts`, { tradelines: tls, advance: true });
  assert.equal(r.body.lead.step, 5);
  r = await c.call("POST", `/leads/${id}/budget`, { income: 4200, expenses: 3300 });
  assert.equal(r.body.lead.step, 6);
  assert.ok(r.body.lead.program.monthlyDeposit > 0);
  r = await c.call("POST", `/leads/${id}/acknowledge`, { acknowledged: true });
  assert.equal(r.body.lead.step, 7);
  r = await c.call("POST", `/leads/${id}/quiz`, { answers: { fee: 0, credit: 0, sue: 1 } });
  assert.deepEqual(r.body.wrong, ["fee"]);
  r = await c.call("POST", `/leads/${id}/quiz`, { answers: { fee: 2, credit: 0, sue: 1 } });
  assert.equal(r.body.lead.step, 8);
  await c.call("POST", `/leads/${id}/deposits`);

  // must verify email before signing
  r = await c.call("POST", `/leads/${id}/enroll`, { accept: true, draftDate: inDays(10) });
  assert.equal(r.body.code, "EMAIL_UNVERIFIED");
  const mail = devOutbox().find((m) => m.to === "maria@example.com" && m.link?.includes("verify-email"));
  const token = new URL(mail.link).searchParams.get("token");
  assert.equal((await c.call("POST", "/auth/verify-email", { token })).body.user.emailVerified, true);

  assert.equal((await c.call("POST", `/leads/${id}/enroll`, { accept: true, draftDate: inDays(1) })).body.code, "BAD_DATE");
  r = await c.call("POST", `/leads/${id}/enroll`, { accept: true, draftDate: inDays(10) });
  assert.equal(r.body.lead.step, 9);
  r = await c.call("POST", `/leads/${id}/call`);
  assert.equal(r.body.call.result, "PASSED");
  assert.equal(r.body.lead.status, "ENROLLED");

  const dash = await c.call("GET", "/me/application");
  assert.equal(dash.body.application.status, "ENROLLED");
  assert.equal(dash.body.application.deposits.length, dash.body.application.program.termMonths);
  assert.equal(dash.body.application.address.city, "Austin");

  // another user cannot read this application
  const other = client();
  await other.call("POST", "/auth/register", { first: "Eve", last: "X", email: "eve@example.com", phone: "5125550111", password: "Sunrise2026", terms: true });
  assert.equal((await other.call("GET", `/leads/${id}`)).status, 404);
  assert.equal((await other.call("GET", "/admin/stats")).status, 403);

  // cancel any time
  r = await c.call("POST", "/me/application/cancel", {});
  assert.equal(r.body.application.status, "CANCELLED");
});

test("login lockout, logout, password reset", async () => {
  const c = client();
  await c.call("POST", "/auth/register", { first: "Lee", last: "Park", email: "lee@example.com", phone: "4155550123", password: "Sunrise2026", terms: true });
  await c.call("POST", "/auth/logout");
  assert.equal((await c.call("GET", "/auth/me")).body.user, null);
  for (let i = 0; i < 5; i++) await c.call("POST", "/auth/login", { email: "lee@example.com", password: "wrong-pass1" });
  assert.equal((await c.call("POST", "/auth/login", { email: "lee@example.com", password: "Sunrise2026" })).status, 423);

  assert.equal((await c.call("POST", "/auth/forgot-password", { email: "nobody@example.com" })).body.ok, true);
  await c.call("POST", "/auth/forgot-password", { email: "lee@example.com" });
  const link = devOutbox().find((m) => m.to === "lee@example.com" && m.link?.includes("reset-password")).link;
  const token = new URL(link).searchParams.get("token");
  const r = await c.call("POST", "/auth/reset-password", { token, password: "Moonlight2027" });
  assert.equal(r.status, 200);
  assert.equal((await c.call("POST", "/auth/reset-password", { token, password: "Moonlight2028" })).status, 400, "token single-use");
  await c.call("POST", "/auth/logout");
  assert.equal((await c.call("POST", "/auth/login", { email: "lee@example.com", password: "Moonlight2027" })).status, 200);
});

test("declines: state not served and debt too small", async () => {
  const c = client();
  assert.equal((await c.call("POST", "/leads", { debtRange: "25000-50000", state: "ND", paymentStatus: 1 })).body.lead.dropReason, "STATE_NOT_SERVED");
  assert.equal((await c.call("POST", "/leads", { debtRange: "lt7500", state: "TX", paymentStatus: 1 })).body.lead.dropReason, "DEBT_UNDER_MIN");
});
