# Debtify (MERN) — v2

A production-ready build of Debtify: a public website, a **short 9-screen bilingual application** (English / Español) with Jay the guide, **customer accounts** (sign up, log in, email verification, password reset), a **customer dashboard**, and a **staff console** behind a staff login.

- **Frontend:** React 18 + Vite + React Router (`client/`)
- **Backend:** Node.js + Express (`server/`)
- **Database:** MongoDB via Mongoose (in-memory fallback for local development only)

All partner vendors (ID check, soft credit pull, Plaid, e-sign, AI welcome call, partner webhooks) are **simulated**. Swap them in `server/src/services/vendors.js` when you sign real vendor contracts.

---

## What changed from v1 (and why)

Based on how leading debt-relief and lending sites handle sign-up, plus form UX research (easy questions first, sensitive ones later, 3–5 labeled stages, show value before asking for details):

| v1 | v2 |
|---|---|
| 12 screens | **9 screens in 4 labeled stages** (Quick check → Your debts → Your plan → Enroll), with "about N minutes left" |
| Slider for debt | **Tap buttons** for debt range; can start straight from the homepage |
| Personal details before any value | **Instant estimate first** (deposit range, months, total), then a free account |
| Consents pre-checked, long text | Unchecked by default, **plain-words summary first**, full legal text one tap away, optional ones folded away |
| No accounts | Accounts, saved progress, **resume any time**, dashboard |
| Errors as one message | **Inline errors under each field**, input masks for phone/SSN/money, password strength meter |
| Staff console open to anyone | Staff console requires a **staff/admin login** |

## Pages

| Path | What |
|---|---|
| `/` | Homepage with a one-tap quick start |
| `/apply` | The application (works as a guest until step 2, where you create an account) |
| `/signup`, `/login`, `/forgot-password`, `/reset-password`, `/verify-email` | Accounts |
| `/dashboard` | Program status, deposits, enrolled debts, documents, help, cancel any time |
| `/dashboard/agreement` | Printable agreement summary |
| `/settings` | Profile, language, communication preferences, password, download my data, sign out everywhere, delete account |
| `/staff` | Staff console: demo app with personas, applications search + activity log, dashboard, explainer library, users & roles (admin) |
| `/privacy`, `/terms`, `/contact` | Starter legal pages (have counsel complete the bracketed parts) |
| `/dev/outbox` | Development only: emails the app would send (verification, reset) |

## Security built in

- Passwords hashed with **bcrypt** (cost 12); strength rules + common-password block
- Sessions in **httpOnly, SameSite=Lax, Secure (prod) cookies** (JWT); "sign out everywhere" via token versioning
- **CSRF protection**: every state-changing request must send `X-Requested-With: debtify`
- **Rate limits** on login, signup, password reset, email and chat; **account lockout** after 5 wrong passwords (15 min)
- Email verification required before signing; reset links are single-use and expire in 1 hour; forgot-password never reveals whether an email exists
- **Full SSN never stored** (last 4 only); date of birth and address **encrypted at rest (AES-256-GCM)**
- Applications are only visible to their owner; staff APIs require the staff/admin role
- Helmet security headers with a strict **Content Security Policy**, input validation with **zod**, JSON body size limits, no stack traces in production
- The server **refuses to start in production** without `MONGO_URI`, `JWT_SECRET` and `ENCRYPTION_KEY`

---

## Run it locally

Requirements: Node.js 18+ (MongoDB optional for local runs).

```bash
npm run install:all
copy server\.env.example server\.env      # Windows  (cp on macOS/Linux)
npm run dev
```

- Website: http://localhost:5173
- **Staff login:** `admin@debtify.local` / `ChangeMe2026` (set by `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `server/.env`; change them!)
- Verification and reset emails: open http://localhost:5173/dev/outbox and click the link (no SMTP needed in dev)

If MongoDB isn't running locally, the server uses an in-memory store and says so in the console. Data then resets on restart.

## Tests

```bash
npm test
```

Runs API tests covering CSRF, password rules, the full guest → account → enrolled journey, SSN/DOB storage, access control between users, lockout and password reset.

## Deploy to production

### Option A: Docker (MongoDB included)
```bash
set JWT_SECRET=...  & set ENCRYPTION_KEY=...  & set ADMIN_PASSWORD=...     # or export on macOS/Linux
docker compose up --build
```
App on http://localhost:5000.

### Option B: Any Node host (Render, Railway, a VPS) + MongoDB Atlas
1. Create a free MongoDB Atlas cluster and copy its connection string.
2. Set environment variables on the host (see `server/.env.example`):
   `NODE_ENV=production`, `MONGO_URI`, `JWT_SECRET`, `ENCRYPTION_KEY`, `APP_URL=https://yourdomain.com`, `CLIENT_ORIGIN=https://yourdomain.com`, `TRUST_PROXY=1`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and SMTP settings (`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM`) from Resend, SendGrid, Postmark, Amazon SES, etc.
3. Build command: `npm run install:all && npm run build` · Start command: `npm start`
4. Generate secrets with: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
5. Production defaults: `DEMO_MODE` and `SEED_SAMPLES` are **off**. Turn `DEMO_MODE=true` on for a staging site only.

Create more staff later: `npm --prefix server run create-admin -- name@company.com "StrongPassw0rd" staff`

### Before real customers use it
- Replace the simulated vendors with real ones (identity/KYC, soft-pull credit bureau, Plaid, e-sign, partner APIs).
- Have counsel finish the Privacy Policy, Terms, consent wording (TCPA, E-SIGN, FCRA) and Spanish translations.
- Put your real company name, licences, address, phone and support email in the footer and legal pages.
- Turn on backups for MongoDB and add uptime monitoring on `/api/health`.

---

## Project structure

```
server/src/
  app.js                 Express app: security headers, CSRF, rate limits, routes, static hosting
  index.js               connect DB, create first admin, seed samples, graceful shutdown
  config/env.js          validated configuration (fails fast in production)
  config/db.js           MongoDB collections + in-memory fallback
  models/User.js, Lead.js
  middleware/auth.js     sessions, guest token, requireAuth / requireRole
  middleware/security.js CSRF header check, rate limiters
  lib/crypto.js          AES-256-GCM field encryption, tokens
  lib/mailer.js          SMTP email + dev outbox, email templates (EN/ES)
  routes/auth.js         register, login, logout(-all), verify email, forgot/reset password
  routes/leads.js        the 9-step application
  routes/me.js           dashboard, cancel, preferences, profile, password, export, delete
  routes/admin.js        staff: stats, applications, partner events, exceptions, users & roles
  routes/chat.js         Jay
  services/              matching engine, estimates & deposit schedule, vendors (mock), chat, stats, samples
  tests/api.test.js
client/src/
  App.jsx                routes + auth guards
  context/AppContext.jsx language, user, application state, chat
  components/            Layout (header/footer/progress), Flow (actions), Screens (9 steps), Chat, ui (fields)
  pages/                 Home, Apply, Auth, Dashboard, Settings, Staff, Admin, Library, Legal
  lib/                   api client, EN/ES copy, SVG explainers, input masks
```
