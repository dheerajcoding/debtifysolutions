import { useEffect, useMemo, useRef } from "react";
import { useApp } from "../context/AppContext.jsx";
import { api } from "../lib/api.js";
import { CONSENTS, GUIDE } from "../lib/copy.js";
import { AppHead, Screen } from "./Screens.jsx";
import Chat from "./Chat.jsx";

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

// Every button in the enrollment flow maps to one of these actions.
function useActions() {
  const app = useApp();
  const { lead, ui, setUi, run, x, lang, persona, source, addLog, addEvents, setLead, restart, sendChat } = app;
  const ref = useRef(app);
  ref.current = app;

  return useMemo(() => {
    const id = () => ref.current.lead?.leadId;
    const U = () => ref.current.ui;
    return {
      listen: (step) => {
        try {
          speechSynthesis.cancel();
          const u = new SpeechSynthesisUtterance(GUIDE[step][ref.current.lang].join(" "));
          u.lang = ref.current.lang === "es" ? "es-US" : "en-US";
          speechSynthesis.speak(u);
          addLog("UX", `Jay read screen ${step} aloud`);
        } catch {}
      },
      askq: (q) => sendChat(q),
      clarity: (pid, v) => run(null, () => api.patchLead(id(), { clarity: { [pid]: v } })),
      go: (n) => run(null, () => api.patchLead(id(), { step: n })),
      s1: () => {
        const u = U();
        return run(null, () => api.createLead({ state: u.state, debt: u.debt, lang: ref.current.lang, source: ref.current.source, persona: ref.current.persona.id }));
      },
      s2: () => run(null, () => api.patchLead(id(), { hardship: U().hardship, step: 3 })),
      s3: async () => {
        const u = U(), L = ref.current.lang, xx = ref.current.x;
        for (const c of CONSENTS) {
          if (c.req && !u.consents[c.type]) {
            addLog("GUARD", `blocked: ${c.label.en} consent is required`);
            return setUi({ err: xx.needConsent(c.label[L]) });
          }
        }
        const ssn = String(u.form.ssn || "").replace(/\D/g, "");
        if (ssn.length !== 9) return setUi({ err: xx.needSsn });
        const f = u.form;
        const r = await run(xx.checking, () =>
          api.identity(id(), {
            first: f.fn, last: f.ln, email: f.em, phone: f.ph, dob: f.dob, ssn, address: f.a1, city: f.city, zip: f.zip,
            consents: u.consents,
            consentTexts: Object.fromEntries(CONSENTS.map((c) => [c.type, c.text[L]])),
          })
        );
        if (r) setUi({ tls: null });
      },
      pick: (tlId, checked) => setUi((u) => ({ tls: (u.tls || ref.current.lead.tradelines).map((t) => (t.tlId === tlId ? { ...t, selected: checked } : t)) })),
      confirm: (tlId, v) =>
        setUi((u) => ({
          tls: (u.tls || ref.current.lead.tradelines).map((t) => (t.tlId === tlId ? { ...t, confirmed: v || null, enrollable: !!v, selected: !!v } : t)),
        })),
      s4: async () => {
        const tls = U().tls || ref.current.lead.tradelines;
        const r = await run(null, () => api.debts(id(), { tradelines: tls.map((t) => ({ tlId: t.tlId, selected: t.selected, confirmed: t.confirmed })), advance: true }));
        if (r) setUi({ tls: null });
      },
      bank1: () => run(null, () => api.budget(id(), { income: +U().inc || 0, expenses: +U().exp || 0, bankLinked: true, linkOnly: true })),
      s5: () => run(ref.current.x.finding, () => api.budget(id(), { income: +U().inc || 0, expenses: +U().exp || 0, bankLinked: !!ref.current.lead.bankLinked })),
      s7: () => {
        if (!U().ack) return setUi({ err: ref.current.x.needAck });
        return run(null, () => api.acknowledge(id()));
      },
      ans: (qid, i) => setUi((u) => ({ answers: { ...u.answers, [qid]: i } })),
      s8: async () => {
        const r = await run(null, () => api.quiz(id(), U().answers));
        if (r) setUi({ wrong: r.wrong || [] });
      },
      bank2: () => run(null, () => api.deposits(id(), { linkOnly: true })),
      s9: () => {
        const d = new Date(U().draft + "T12:00:00Z").getTime();
        if (!d || d < Date.now() + 3 * 864e5 - 432e5 || d > Date.now() + 45 * 864e5) return setUi({ err: ref.current.x.badDate });
        return run(null, () => api.deposits(id(), { draftDate: U().draft }));
      },
      sign: () => run(null, () => api.sign(id(), true)),
      nosign: () => run(null, () => api.sign(id(), false)),
      call: async () => {
        setUi({ calling: true, call: [], err: null });
        try {
          const r = await api.call(id());
          addEvents(r.events.slice(0, 1));
          for (const line of r.call.lines) {
            await wait(650);
            setUi((u) => ({ call: [...u.call, line] }));
          }
          await wait(500);
          addEvents(r.events.slice(1));
          setLead(r.lead);
        } catch (e) {
          setUi({ err: e.message });
        }
        setUi({ calling: false });
      },
      backend: (type) => run(null, () => api.backendEvent(id(), type)),
      restart: () => restart(ref.current.persona),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}

// The enrollment app: phone frame (staff console) or full-screen column (#apply).
export default function Phone({ full }) {
  const app = useApp();
  const { lead, ui, setUi, x, lang, setLang } = app;
  const act = useActions();
  const screenRef = useRef(null);
  const step = lead ? lead.step : 1;

  useEffect(() => {
    if (screenRef.current) screenRef.current.scrollTop = 0;
    if (full) window.scrollTo(0, 0);
    setUi({ err: null });
  }, [step, lead?.leadId, full, setUi]);

  const props = { x, lang, lead: lead || { step: 1, clarity: {} }, ui, setUi, act, step };
  return (
    <div className={"phone" + (full ? " full" : "")}>
      <div className="screen" ref={screenRef}>
        <div className="app">
          <AppHead x={x} lang={lang} step={step} onLang={setLang} />
          <Screen {...props} />
        </div>
        <Chat />
      </div>
    </div>
  );
}
