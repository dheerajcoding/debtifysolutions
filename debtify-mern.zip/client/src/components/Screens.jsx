import { CONSENTS, DECL, QUIZ, RISKS, disclosures } from "../lib/copy.js";
import { AVATAR, viz } from "../lib/viz.js";
import { usd } from "../lib/format.js";
import GuideCard from "./GuideCard.jsx";
import Html from "./Html.jsx";

export const STATES = "AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY".split(" ");

const Err = ({ ui }) => (ui.err ? <p className="alert err" role="alert">{ui.err}</p> : null);
const MainBtn = ({ ui, onClick, disabled, children }) => (
  <button className="btn" onClick={onClick} disabled={disabled || ui.pending}>
    {ui.busy || children}
  </button>
);

function ClarityRow({ id, x, lead, act }) {
  const v = lead.clarity?.[id];
  return (
    <div className="clarity">
      <span>{x.wasClear}</span>
      <button className={v === "clear" ? "on" : ""} onClick={() => act.clarity(id, "clear")}>👍 {x.clear}</button>
      <button className={"simp " + (v === "simpler" ? "on" : "")} onClick={() => act.clarity(id, "simpler")}>{x.simpler}</button>
    </div>
  );
}

function PointCard({ id, title, body, plain, vizKind, p }) {
  const { x, lead, lang } = p;
  return (
    <div className="card">
      <h2>{title}</h2>
      <Html html={viz(vizKind, lang, { p: lead.program })} />
      <p className="sub">{body}</p>
      {lead.clarity?.[id] === "simpler" && (
        <p className="plain"><b>{x.plain}</b> {plain}</p>
      )}
      <ClarityRow id={id} {...p} />
    </div>
  );
}

const Field = ({ id, label, value, type = "text", onChange, ...extra }) => (
  <label className="f">
    {label}
    <input className="field" id={id} type={type} value={value ?? ""} onChange={(e) => onChange(id, e.target.value)} {...extra} />
  </label>
);

// ---------------- the 12 screens ----------------
const S = {};

S[1] = (p) => {
  const { x, ui, setUi, act } = p;
  return (
    <>
      <GuideCard step={1} {...p} />
      <h1>{x.h1}</h1>
      <p className="sub">{x.s1sub}</p>
      <div className="card">
        <p style={{ fontSize: 34, fontWeight: 800 }}>{usd(ui.debt)}</p>
        <input className="range" type="range" min="1000" max="100000" step="500" value={ui.debt} aria-label={x.h1} onChange={(e) => setUi({ debt: +e.target.value })} />
      </div>
      <label className="f">
        {x.stateQ}
        <select className="field" value={ui.state} onChange={(e) => setUi({ state: e.target.value })}>
          {STATES.map((s) => <option key={s}>{s}</option>)}
        </select>
      </label>
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={act.s1}>{x.cont}</MainBtn>
    </>
  );
};

S[2] = (p) => {
  const { x, ui, setUi, act } = p;
  return (
    <>
      <GuideCard step={2} {...p} />
      <h1>{x.h2}</h1>
      {["reason", "goal", "timing"].map((k, qi) => (
        <fieldset key={k}>
          <legend>{x.hq[qi]}</legend>
          {x.hopt[qi].map((o, i) => (
            <button key={o} className={"choice " + (ui.hardship[k] === i ? "on" : "")} onClick={() => setUi((u) => ({ hardship: { ...u.hardship, [k]: i } }))}>
              {o}
            </button>
          ))}
        </fieldset>
      ))}
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={act.s2} disabled={Object.keys(ui.hardship).length < 3}>{x.cont}</MainBtn>
    </>
  );
};

S[3] = (p) => {
  const { x, ui, setUi, act, lead, lang } = p;
  const f = ui.form;
  const on = (k, v) => setUi((u) => ({ form: { ...u.form, [k]: v } }));
  return (
    <>
      <GuideCard step={3} {...p} />
      <h1>{x.h3}</h1>
      <p className="sub">{x.s3sub}</p>
      <div className="grid2">
        <Field id="fn" label={x.fn} value={f.fn} onChange={on} />
        <Field id="ln" label={x.ln} value={f.ln} onChange={on} />
      </div>
      <Field id="em" label={x.em} value={f.em} type="email" onChange={on} />
      <Field id="ph" label={x.ph} value={f.ph} type="tel" onChange={on} />
      <div className="grid2">
        <Field id="dob" label={x.dob} value={f.dob} type="date" onChange={on} />
        <Field id="ssn" label={x.ssn} value={f.ssn} type="password" onChange={on} inputMode="numeric" autoComplete="off" />
      </div>
      <Field id="a1" label={x.a1} value={f.a1} onChange={on} />
      <div className="grid2">
        <Field id="city" label={x.city} value={f.city} onChange={on} />
        <Field id="zip" label={x.zip} value={f.zip} onChange={on} />
      </div>
      <p className="small">{x.stateLine(lead.state)}</p>
      <fieldset>
        <legend>{x.perms}</legend>
        {CONSENTS.map((c) => (
          <label key={c.type} className="card consent">
            <input type="checkbox" checked={!!ui.consents[c.type]} onChange={(e) => setUi((u) => ({ consents: { ...u.consents, [c.type]: e.target.checked } }))} />
            <span>
              <b>{c.label[lang]} ({c.req ? x.req : x.opt})</b>
              <br />
              <span className="plain" style={{ display: "inline-block", margin: "4px 0" }}>{c.plain[lang]}</span>
              <br />
              {c.text[lang]}
            </span>
          </label>
        ))}
      </fieldset>
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={act.s3}>{x.find}</MainBtn>
    </>
  );
};

S[4] = (p) => {
  const { x, ui, act, lead } = p;
  const tls = ui.tls || lead.tradelines || [];
  const en = tls.filter((tl) => tl.enrollable || tl.type === "OTHER");
  const no = tls.filter((tl) => !tl.enrollable && tl.type !== "OTHER");
  const total = en.filter((tl) => tl.selected && tl.enrollable).reduce((s, tl) => s + tl.balance, 0);
  return (
    <>
      <GuideCard step={4} {...p} />
      <h1>{x.h4(lead.first)}</h1>
      <p className="sub">{x.s4sub}</p>
      {en.map((tl) => (
        <div className="card" key={tl.tlId}>
          <label className="debt">
            <span>
              <b>{tl.creditor}</b>
              <br />
              <span className="small">{tl.type === "OTHER" ? x.tell : x.types[tl.type] || tl.type}</span>
            </span>
            <span style={{ display: "flex", gap: 10, alignItems: "center" }}>
              <b>{usd(tl.balance)}</b>
              <input type="checkbox" checked={!!tl.selected} disabled={tl.type === "OTHER" && !tl.enrollable} onChange={(e) => act.pick(tl.tlId, e.target.checked)} />
            </span>
          </label>
          {tl.type === "OTHER" && (
            <select className="field" value={tl.confirmed || ""} onChange={(e) => act.confirm(tl.tlId, e.target.value)}>
              <option value="">{x.kind}</option>
              {Object.entries(x.kinds).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          )}
        </div>
      ))}
      {no.length > 0 && (
        <details className="card">
          <summary><b>{x.cant(no.length)}</b></summary>
          {no.map((tl) => (
            <p className="small" key={tl.tlId}>{tl.creditor}: {usd(tl.balance)}, {x.types[tl.type]} · {x.cantWhy}</p>
          ))}
        </details>
      )}
      <div className="card kv">
        <span>{x.enrolling}</span>
        <span style={{ fontSize: 20 }}>{usd(total)}</span>
      </div>
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={act.s4} disabled={total === 0}>{x.cont}</MainBtn>
    </>
  );
};

S[5] = (p) => {
  const { x, ui, setUi, act, lead } = p;
  return (
    <>
      <GuideCard step={5} {...p} />
      <h1>{x.h5}</h1>
      <p className="sub">{x.s5sub}</p>
      <button className="ghost" onClick={act.bank1}>{lead.bankLinked ? x.bankOn : x.bankOpt}</button>
      <label className="f">{x.inc}<input className="field" inputMode="numeric" value={ui.inc} onChange={(e) => setUi({ inc: e.target.value.replace(/[^\d]/g, "") })} /></label>
      <label className="f">{x.exp}<input className="field" inputMode="numeric" value={ui.exp} onChange={(e) => setUi({ exp: e.target.value.replace(/[^\d]/g, "") })} /></label>
      <div className="card kv"><span>{x.left}</span><span>{usd((+ui.inc || 0) - (+ui.exp || 0))}</span></div>
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={act.s5}>{x.seeProg}</MainBtn>
    </>
  );
};

S[6] = (p) => {
  const { x, ui, act, lead } = p;
  const pr = lead.program;
  return (
    <>
      <GuideCard step={6} {...p} />
      <h1>{x.h6}</h1>
      <p className="sub" dangerouslySetInnerHTML={{ __html: x.prov(pr.backendName) }} />
      <div className="big">
        <span className="k">{x.dep}</span>
        <span className="v">{usd(pr.monthlyDeposit)}</span>
        <span style={{ opacity: 0.8, fontSize: 13 }}>{x.depSub(pr.termMonths)}</span>
      </div>
      <div className="card">
        <div className="kv"><span>{x.rDebt}</span><span>{usd(pr.enrolledDebt)}</span></div>
        <div className="kv"><span>{x.rCost}</span><span>{usd(pr.estTotalCost)}</span></div>
        <div className="kv"><span>{x.rSave}</span><span>{usd(pr.estSavings)}</span></div>
        <div className="kv"><span>{x.rFee}</span><span>{x.feeTxt(Math.round(pr.clientFeePct * 100))}</span></div>
      </div>
      <p className="small">{x.s6note}</p>
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={() => act.go(7)}>{x.cont}</MainBtn>
    </>
  );
};

S[7] = (p) => {
  const { x, ui, setUi, act, lead, lang } = p;
  return (
    <>
      <GuideCard step={7} {...p} />
      <h1>{x.h7}</h1>
      {disclosures(lead.program, lang).map((d) => (
        <PointCard key={d.id} id={d.id} title={d.title} body={d.body} plain={d.plain} vizKind={d.viz} p={p} />
      ))}
      <label className="consent">
        <input type="checkbox" checked={!!ui.ack} onChange={(e) => setUi({ ack: e.target.checked })} />
        <span>{x.ack}</span>
      </label>
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={act.s7}>{x.cont}</MainBtn>
    </>
  );
};

S[8] = (p) => {
  const { x, ui, act, lang } = p;
  return (
    <>
      <GuideCard step={8} {...p} />
      <h1>{x.h8}</h1>
      {RISKS.map((r) => (
        <PointCard key={r.id} id={r.id} title={r.title[lang]} body={r.body[lang]} plain={r.plain[lang]} vizKind={r.viz} p={p} />
      ))}
      <h2>{x.quizH}</h2>
      {QUIZ.map((q) => (
        <fieldset key={q.id}>
          <legend>{q.q[lang]}</legend>
          {q.o[lang].map((o, i) => (
            <button key={o} className={"choice " + (ui.answers[q.id] === i ? "on" : "")} onClick={() => act.ans(q.id, i)}>{o}</button>
          ))}
          {ui.wrong?.includes(q.id) && <p className="alert">{q.ex[lang]}</p>}
        </fieldset>
      ))}
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={act.s8} disabled={QUIZ.some((q) => ui.answers[q.id] === undefined)}>{x.checkA}</MainBtn>
    </>
  );
};

S[9] = (p) => {
  const { x, ui, setUi, act, lead } = p;
  return (
    <>
      <GuideCard step={9} {...p} />
      <h1>{x.h9}</h1>
      <p className="sub">{x.s9sub}</p>
      <button className="ghost" onClick={act.bank2}>{lead.depositAccountLinked ? x.bankOn : x.bank2}</button>
      <label className="f">{x.draft}<input className="field" type="date" value={ui.draft} onChange={(e) => setUi({ draft: e.target.value })} /></label>
      <p className="small">{x.draftSub}</p>
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={act.s9} disabled={!lead.depositAccountLinked}>{x.cont}</MainBtn>
    </>
  );
};

S[10] = (p) => {
  const { x, ui, act, lead } = p;
  const pr = lead.program;
  return (
    <>
      <GuideCard step={10} {...p} />
      <h1>{x.h10}</h1>
      <div className="card">
        <h2>{x.keyT}</h2>
        <div className="kv"><span>{x.company}</span><span>{pr.backendName}</span></div>
        <div className="kv"><span>{x.mdep}</span><span>{usd(pr.monthlyDeposit)}</span></div>
        <div className="kv"><span>{x.len}</span><span>{x.months(pr.termMonths)}</span></div>
        <div className="kv"><span>{x.feeL}</span><span>{x.feeTxt(Math.round(pr.clientFeePct * 100))}</span></div>
        <div className="kv"><span>{x.cancel}</span><span>{x.anytime}</span></div>
      </div>
      <p className="small">{x.full(pr.backendName)}</p>
      <Err ui={ui} />
      <MainBtn ui={ui} onClick={act.sign}>{x.sign}</MainBtn>
      <button className="ghost" onClick={act.nosign} disabled={ui.pending}>{x.notNow}</button>
    </>
  );
};

S[11] = (p) => {
  const { x, ui, act, lead } = p;
  return (
    <>
      <GuideCard step={11} {...p} />
      <h1>{x.h11}</h1>
      <div className="card">
        {ui.call.length ? ui.call.map((l, i) => <p className="small" key={i}><b>{l.who}:</b> {l.text}</p>) : <p className="small">{x.covers}</p>}
      </div>
      <Err ui={ui} />
      {lead.callResult === "NEEDS_HUMAN" && !ui.calling ? (
        <p className="alert">{x.humanMsg}</p>
      ) : ui.calling ? null : (
        <MainBtn ui={ui} onClick={act.call}>{x.callMe}</MainBtn>
      )}
    </>
  );
};

S[12] = (p) => {
  const { x, ui, act, lead, lang } = p;
  const pr = lead.program;
  const date = lead.draftDate || ui.draft;
  const d = new Date(date + "T12:00:00Z").toLocaleDateString(lang === "es" ? "es-US" : "en-US", { month: "long", day: "numeric", timeZone: "UTC" });
  return (
    <>
      <GuideCard step={12} {...p} />
      <h1>{x.h12(lead.first)}</h1>
      <div className="big">
        <span className="k">{x.first}</span>
        <span className="v">{usd(pr.monthlyDeposit)}</span>
        <span style={{ opacity: 0.8 }}>{x.on(d)}</span>
      </div>
      <div className="card">
        <h2>{x.next}</h2>
        <ol style={{ margin: 0, paddingLeft: 18 }} className="sub">
          {x.nextL(pr.backendName).map((l) => <li key={l}>{l}</li>)}
        </ol>
      </div>
      <div className="card" style={{ borderStyle: "dashed" }}>
        <p className="demo-note">Demo control, not seen by consumers</p>
        <p className="small">Fee status: <b>{lead.feeStatus}</b> · Debtify fee {usd(pr.debtifyFee)} (7% of enrolled debt)</p>
        <Err ui={ui} />
        {lead.feeStatus === "NOT_EARNED" && <button className="ghost" onClick={() => act.backend("PAYMENT1_CLEARED")}>Simulate backend: payment 1 cleared</button>}
        {lead.feeStatus === "EARNED" && (
          <>
            <button className="ghost" onClick={() => act.backend("PAYMENT2_CLEARED")}>Simulate backend: payment 2 cleared</button>
            <button className="ghost" onClick={() => act.backend("PAYMENT2_FAILED")}>Simulate backend: payment 2 failed</button>
          </>
        )}
      </div>
    </>
  );
};

function Declined({ x, lang, lead, act }) {
  const [h, b] = DECL[lang][lead.dropReason] || DECL[lang].NO_BACKEND_FIT;
  return (
    <>
      <div className="guide-card">
        <Html as="span" html={AVATAR} style={{ display: "contents" }} />
        <div className="bubble">
          <div className="who"><span>{x.guideRole}</span></div>
          <p>{b}</p>
        </div>
      </div>
      <h1>{h}</h1>
      <p className="demo-note">Reason code logged: {lead.dropReason}</p>
      <button className="ghost" onClick={act.restart}>{x.restart}</button>
    </>
  );
}

// Header inside the phone frame (hidden on the full-screen enrollment page, which has its own top bar).
export function AppHead({ x, lang, step, onLang }) {
  return (
    <div className="apphead">
      <div className="row">
        <b>Debtify</b>
        {step ? <span>{x.step} {step} {x.of} 12</span> : null}
        {onLang && (
          <div className="lang" role="group" aria-label="Language">
            <button aria-pressed={lang === "en"} onClick={() => onLang("en")}>EN</button>
            <button aria-pressed={lang === "es"} onClick={() => onLang("es")}>ES</button>
          </div>
        )}
      </div>
      {step ? (
        <>
          <div className="bar"><i style={{ width: `${(step / 12) * 100}%` }} /></div>
          <span className="eyebrow">{x.steps[step]}</span>
        </>
      ) : null}
    </div>
  );
}

export function Screen(props) {
  const { step } = props;
  if (!step) return <Declined {...props} />;
  const C = S[step];
  return C ? C(props) : null;
}
