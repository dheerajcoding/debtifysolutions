import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { api } from "../lib/api.js";
import { PERSONAS, T } from "../lib/copy.js";
import { suggestDate } from "../lib/format.js";

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

function initialLang() {
  try {
    const q = new URLSearchParams(location.search).get("lang");
    if (q === "es" || q === "en") return q;
    if (location.hash === "#es" || location.hash === "#apply-es") return "es";
    return (navigator.language || "").toLowerCase().startsWith("es") ? "es" : "en";
  } catch {
    return "en";
  }
}

const hashRoute = () => {
  const h = location.hash.slice(1);
  if (h === "ops") return "ops";
  if (h === "apply" || h === "apply-es") return "apply";
  return "site";
};

// Per-session screen state that is not saved on the server (form inputs, quiz picks, call transcript).
function freshUi(persona) {
  const p = persona.p || PERSONAS[0].p;
  return {
    debt: persona.debt,
    state: persona.state,
    hardship: {},
    form: { ...p },
    consents: { CREDIT_PULL: true, ESIGN: true, CALLS_TEXTS: true, SHARING: true },
    tls: null,
    inc: persona.inc || "",
    exp: persona.exp || "",
    ack: false,
    answers: {},
    wrong: [],
    draft: suggestDate(),
    call: [],
    calling: false,
    err: null,
    busy: null,
  };
}

const ERR = {
  en: { BAD_DATE: T.en.badDate, ACK_REQUIRED: T.en.needAck, BAD_SSN: T.en.needSsn },
  es: { BAD_DATE: T.es.badDate, ACK_REQUIRED: T.es.needAck, BAD_SSN: T.es.needSsn },
};

export function AppProvider({ children }) {
  const [lang, setLangState] = useState(initialLang);
  const [persona, setPersona] = useState(PERSONAS[0]);
  const [lead, setLead] = useState(null);
  const [ui, setUiState] = useState(() => freshUi(PERSONAS[0]));
  const [logs, setLogs] = useState([]);
  const [chat, setChat] = useState({ open: false, msgs: [], typing: false });
  const [meta, setMeta] = useState(null);
  const [route, setRoute] = useState(hashRoute);
  const leadRef = useRef(lead);
  leadRef.current = lead;
  const langRef = useRef(lang);
  langRef.current = lang;
  const chatRef = useRef(chat);
  chatRef.current = chat;

  const x = T[lang];
  const step = lead ? lead.step : 1;

  const setUi = useCallback((patch) => setUiState((u) => ({ ...u, ...(typeof patch === "function" ? patch(u) : patch) })), []);
  const addLog = useCallback((tag, text) => setLogs((l) => [...l, { at: new Date().toISOString(), tag, text }].slice(-400)), []);
  const addEvents = useCallback((evs = []) => evs.length && setLogs((l) => [...l, ...evs].slice(-400)), []);

  useEffect(() => {
    api.meta().then(setMeta).catch(() => setMeta({ offline: true }));
    const onHash = () => {
      const r = hashRoute();
      if (location.hash === "#apply-es" || location.hash === "#es") setLangState("es");
      setRoute((prev) => {
        if (prev !== "apply" && r === "apply") addLog("UX", "opened full-screen enrollment");
        if (prev !== r) window.scrollTo(0, 0);
        return r;
      });
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [addLog]);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  // Runs an API call: shows a busy label, logs returned events, stores the updated lead.
  const run = useCallback(
    async (busyLabel, fn) => {
      setUi({ busy: busyLabel || null, pending: true, err: null });
      try {
        const r = await fn();
        if (r?.events) addEvents(r.events);
        if (r?.lead) setLead(r.lead);
        return r;
      } catch (e) {
        setUi({ err: ERR[langRef.current][e.code] || e.message });
        return null;
      } finally {
        setUi({ busy: null, pending: false });
      }
    },
    [setUi, addEvents]
  );

  const setLang = useCallback(
    (l) => {
      if (langRef.current === l) return;
      setLangState(l);
      const cur = leadRef.current;
      if (cur) api.patchLead(cur.leadId, { lang: l }).then((r) => { addEvents(r.events); setLead(r.lead); }).catch(() => {});
      else addLog("UX", `language → ${l === "es" ? "Español" : "English"}`);
    },
    [addEvents, addLog]
  );

  const restart = useCallback(
    (p) => {
      const cur = leadRef.current;
      if (cur && cur.step > 0 && cur.step < 12 && !cur.dropReason) api.abandon(cur.leadId).catch(() => {});
      setLead(null);
      setUiState(freshUi(p));
      setChat({ open: false, msgs: [], typing: false });
      if (p.lang) setLangState(p.lang);
      setLogs([{ at: new Date().toISOString(), tag: "EVENT", text: `new session · persona: ${p.name}` }]);
    },
    []
  );

  const choosePersona = useCallback((p) => { setPersona(p); restart(p); }, [restart]);

  // ---------- chat with Jay ----------
  const openChat = useCallback(() => setChat((c) => ({ ...c, open: true })), []);
  const closeChat = useCallback(() => setChat((c) => ({ ...c, open: false })), []);
  const sendChat = useCallback(
    async (q) => {
      q = String(q || "").trim();
      if (!q) return;
      const history = [...chatRef.current.msgs, ["u", q]];
      setChat((c) => ({ ...c, open: true, msgs: [...c.msgs, ["u", q]], typing: true }));
      const L = langRef.current;
      const cur = leadRef.current;
      let reply;
      try {
        const r = await api.chat({
          leadId: cur?.leadId,
          lang: L,
          step: cur ? cur.step : 1,
          messages: history.map(([w, t]) => ({ role: w === "u" ? "user" : "assistant", content: t })),
        });
        addEvents(r.events);
        reply = r.reply;
      } catch {
        reply = T[L].notSure;
      }
      setChat((c) => ({ ...c, msgs: [...c.msgs, ["a", reply]], typing: false }));
    },
    [addEvents]
  );
  const askPerson = useCallback(async () => {
    const cur = leadRef.current;
    if (cur) {
      try {
        const r = await api.person(cur.leadId);
        addEvents(r.events);
        setLead(r.lead);
      } catch {}
    } else addLog("EVENT", "talk_to_person → exception desk");
    setChat((c) => ({ ...c, msgs: [...c.msgs, ["a", T[langRef.current].personOk]] }));
  }, [addEvents, addLog]);

  const value = useMemo(
    () => ({
      lang, setLang, x, persona, choosePersona, lead, setLead, step, ui, setUi, logs, addLog, addEvents, run, restart,
      chat, openChat, closeChat, sendChat, askPerson, meta, route, source: route === "ops" ? "demo" : "web",
    }),
    [lang, setLang, x, persona, choosePersona, lead, step, ui, setUi, logs, addLog, addEvents, run, restart, chat, openChat, closeChat, sendChat, askPerson, meta, route]
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
