import { useEffect } from "react";
import { useApp } from "./context/AppContext.jsx";
import Site from "./pages/Site.jsx";
import Apply from "./pages/Apply.jsx";
import Ops from "./pages/Ops.jsx";

// Hash routes: "" → public website, #apply → full-screen enrollment, #ops → staff console.
export default function App() {
  const { route, restart, persona } = useApp();
  useEffect(() => {
    restart(persona);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (route === "ops") return <Ops />;
  if (route === "apply") return <Apply />;
  return <Site />;
}
