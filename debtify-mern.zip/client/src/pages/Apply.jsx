import { useApp } from "../context/AppContext.jsx";
import { AP, SITE } from "../lib/copy.js";
import { CHECK, LOGO } from "../lib/viz.js";
import Html from "../components/Html.jsx";
import Phone from "../components/Flow.jsx";
import { LangSwitch } from "./Site.jsx";

// Full-screen enrollment page: top bar, progress rail and one focused column.
export default function Apply() {
  const { x, lang, lead, openChat } = useApp();
  const a = AP[lang];
  const s = lead ? lead.step : 1;
  return (
    <div id="applyPage">
      <header className="aptop">
        <div className="in">
          <a className="brandmark" href="#" aria-label={a.home}>
            <Html as="span" html={LOGO} style={{ display: "contents" }} />
            <b>Debtify</b>
          </a>
          <span className="apstep">{s ? `${x.step} ${s} ${x.of} 12 · ${x.steps[s]}` : ""}</span>
          <div className="right">
            <LangSwitch />
            <button className="aphelp" onClick={openChat}>{x.ask}</button>
          </div>
        </div>
        <div className="apbar"><i style={{ width: `${s ? (s / 12) * 100 : 0}%` }} /></div>
      </header>
      <div className="apgrid">
        <aside className="rail" aria-label={a.progress}>
          <p className="rail-h">{a.progress}</p>
          <ol className="railsteps">
            {x.steps.slice(1).map((n, i) => {
              const k = i + 1;
              const st = !s ? "" : k < s ? "done" : k === s ? "now" : "";
              return (
                <li key={n} className={st} aria-current={st === "now" ? "step" : undefined}>
                  <span className="dot">{st === "done" ? "✓" : k}</span>
                  <span>{n}</span>
                </li>
              );
            })}
          </ol>
          <ul className="rail-safe">
            {a.safe.map((z) => (
              <li key={z}><Html as="span" html={CHECK} style={{ display: "contents" }} /><span>{z}</span></li>
            ))}
          </ul>
          <p className="small">{SITE[lang].phoneNote}</p>
        </aside>
        <div className="apmain">
          <Phone full />
        </div>
      </div>
    </div>
  );
}
