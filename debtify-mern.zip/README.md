# Debtify (MERN)

A full-stack build of the Debtify staging app: a public website, a 12-step bilingual (English / Español) debt-settlement enrollment flow with Jay the guide, and a staff console with test personas, a live "behind the scenes" event log, an explainer library and an admin dashboard.

- **Frontend:** React 18 + Vite (`client/`)
- **Backend:** Node.js + Express (`server/`)
- **Database:** MongoDB via Mongoose. If MongoDB isn't running, the API falls back to an in-memory store automatically so the app still works.

All vendors (ID check, soft credit pull, Plaid, e-sign, AI welcome call, backend webhooks) are **simulated**. No real credit checks or payments happen, and the full SSN is never stored (only the last 4 digits).

---

## 1. Requirements

- Node.js 18 or newer (`node -v`)
- MongoDB (optional): local MongoDB Community Server, or a free MongoDB Atlas cluster

## 2. Install

From this folder:

```bash
npm run install:all
```

This installs the root runner, the server and the client.

## 3. Configure

```bash
copy server\.env.example server\.env      # Windows
# cp server/.env.example server/.env      # macOS / Linux
```

Edit `server/.env`:

| Variable | What it does |
|---|---|
| `PORT` | API port (default `5000`) |
| `MONGO_URI` | e.g. `mongodb://127.0.0.1:27017/debtify` or your Atlas URI. Leave empty to use the in-memory store |
| `CLIENT_ORIGIN` | React dev server origin (default `http://localhost:5173`) |
| `ANTHROPIC_API_KEY` | Optional. If set, Jay's chat answers with Claude (guard-railed to approved facts). Otherwise answers come from the approved FAQ |
| `SEED_SAMPLES` | `true` seeds 181 sample leads so the admin dashboard has data |

## 4. Run (development)

```bash
npm run dev
```

- Website: http://localhost:5173
- Full-screen enrollment: http://localhost:5173/#apply
- Staff console: http://localhost:5173/#ops
- API: http://localhost:5000/api/health

## 5. Run (production)

```bash
npm run build     # builds client/dist
npm start         # Express serves the API and the built React app on http://localhost:5000
```

---

## Project structure

```
debtifycode/
├── package.json              # root scripts (install:all, dev, build, start)
├── server/
│   ├── .env.example
│   └── src/
│       ├── index.js          # Express app, /api/meta, static hosting of client/dist
│       ├── config/db.js      # MongoDB repository + in-memory fallback
│       ├── models/Lead.js    # Mongoose schema (lead, consents, tradelines, program, events)
│       ├── data/backends.js  # partner companies, served states, quiz answers
│       ├── services/
│       │   ├── routing.js    # debt classification + matching engine
│       │   ├── vendors.js    # mock ID check, soft pull, welcome call
│       │   ├── chat.js       # Jay: Claude (optional) + FAQ + guardrails + distress handling
│       │   ├── stats.js      # admin dashboard aggregation
│       │   └── samples.js    # 181 sample leads
│       ├── routes/
│       │   ├── leads.js      # the enrollment flow API
│       │   ├── admin.js      # /api/admin/stats, /leads, /seed
│       │   └── chat.js       # /api/chat
│       └── scripts/seed.js   # npm run seed (reset samples in MongoDB)
└── client/
    ├── index.html
    ├── vite.config.js        # proxies /api → :5000 in dev
    └── src/
        ├── App.jsx           # hash routes: site / #apply / #ops
        ├── context/AppContext.jsx   # language, lead, UI state, log, chat
        ├── components/       # Flow (actions + phone), Screens (12 steps), GuideCard, Chat
        ├── pages/            # Site, Apply, Ops, Admin, Library
        ├── lib/              # api client, EN/ES copy, SVG explainers, formatting
        └── styles.css
```

## API

| Method | Path | Step |
|---|---|---|
| POST | `/api/leads` | 1 · create lead (state + estimated debt); declines unserved state / low debt |
| PATCH | `/api/leads/:id` | step navigation, language, hardship answers, clarity ratings |
| POST | `/api/leads/:id/identity` | 3 · consents (hashed + versioned), ID check, soft pull, tradeline tagging |
| PUT | `/api/leads/:id/debts` | 4 · choose debts, confirm unclear accounts |
| POST | `/api/leads/:id/budget` | 5 · bank link, routing engine → program or decline |
| POST | `/api/leads/:id/acknowledge` | 7 · costs and timing acknowledged |
| POST | `/api/leads/:id/quiz` | 8 · comprehension quiz graded server-side |
| POST | `/api/leads/:id/deposits` | 9 · deposit account + first draft date (3–45 days) |
| POST | `/api/leads/:id/sign` | 10 · sign or decline |
| POST | `/api/leads/:id/call` | 11 · AI welcome call transcript; promise-of-result → exception desk |
| POST | `/api/leads/:id/backend-event` | PAYMENT1_CLEARED / PAYMENT2_CLEARED / PAYMENT2_FAILED (fee earned / final / clawback) |
| POST | `/api/leads/:id/person` · `/abandon` | talk to a person · left mid-flow |
| POST | `/api/chat` | Jay's answers |
| GET | `/api/admin/stats?samples=1` | admin dashboard |

Every lead endpoint returns `{ lead, events }`; `events` feed the "Behind the scenes" log in the staff console.

## Test personas (staff console)

| Persona | What it shows |
|---|---|
| Maria, Texas | Happy path (~$29k enrollable) |
| Carlos, Florida (ES) | Happy path in Spanish |
| ID check fails | SSN ending 0000 |
| Too little debt | SSN ending 3333 → thin credit file |
| Budget too tight | $50 left each month → not affordable |
| Call needs a person | Phone ending 99 → welcome call routed to a person |
| State not served | North Dakota |

## Notes

- Spanish text and all consent/disclosure wording are drafts for counsel and native-speaker review.
- Backend names and rules (`server/src/data/backends.js`) are placeholders.
