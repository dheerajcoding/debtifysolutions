import mongoose from "mongoose";

const TradelineSchema = new mongoose.Schema(
  {
    tlId: String,
    creditor: String,
    type: String,
    balance: Number,
    enrollable: Boolean,
    selected: Boolean,
    needsReview: Boolean,
    confirmed: { type: String, default: null },
  },
  { _id: false }
);

const ConsentSchema = new mongoose.Schema(
  { type: String, granted: Boolean, lang: String, version: String, textHash: String, at: Date },
  { _id: false }
);

const EventSchema = new mongoose.Schema({ tag: String, text: String, at: Date }, { _id: false });

const LeadSchema = new mongoose.Schema(
  {
    leadId: { type: String, unique: true, index: true },
    source: { type: String, enum: ["demo", "sample", "web"], default: "web", index: true },
    lang: { type: String, default: "en" },
    persona: String,
    state: String,
    debt: Number,
    step: { type: Number, default: 1 },
    maxStep: { type: Number, default: 1 },
    status: { type: String, default: "STARTED", index: true },
    dropReason: { type: String, default: null },
    hardship: { type: mongoose.Schema.Types.Mixed, default: {} },
    // Identity: the full SSN is never stored. DOB and address would be encrypted in production.
    first: String,
    last: String,
    email: String,
    phone: String,
    ssnLast4: String,
    kyc: String,
    consents: [ConsentSchema],
    share: { type: Boolean, default: false },
    tradelines: [TradelineSchema],
    income: Number,
    expenses: Number,
    bankLinked: { type: Boolean, default: false },
    depositAccountLinked: { type: Boolean, default: false },
    program: { type: mongoose.Schema.Types.Mixed, default: null },
    backend: { type: String, default: null },
    costsAcknowledged: { type: Boolean, default: false },
    quizAttempts: { type: Number, default: 0 },
    draftDate: String,
    signedAt: Date,
    callResult: String,
    feeStatus: { type: String, default: "NOT_EARNED" },
    clarity: { type: mongoose.Schema.Types.Mixed, default: {} },
    chats: { type: Number, default: 0 },
    person: { type: Boolean, default: false },
    events: [EventSchema],
  },
  { timestamps: true, minimize: false }
);

export const Lead = mongoose.models.Lead || mongoose.model("Lead", LeadSchema);
