import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { connectDB, repo } from "./config/db.js";
import { BACKENDS, MIN_DEBT, SERVED, STATES } from "./data/backends.js";
import leadsRouter from "./routes/leads.js";
import adminRouter from "./routes/admin.js";
import chatRouter from "./routes/chat.js";
import { buildSamples } from "./services/samples.js";
import { route, tagTradeline } from "./services/routing.js";
import { sampleFile } from "./services/vendors.js";

// Example plan for the homepage, computed by the real routing engine from a sample Texas profile.
function samplePlan() {
  const raw = sampleFile().map(tagTradeline);
  const confirmed = raw.map((t) => (t.type === "OTHER" ? { ...t, type: "MEDICAL", enrollable: true, selected: true, confirmed: "MEDICAL" } : t));
  const plan = (debts) => route({ state: "TX", debts, income: 4200, expenses: 3300 }).program;
  // hero: the 4 clear unsecured debts; tour: the walkthrough where the unclear account is confirmed as medical
  return { hero: plan(raw), tourDebts: raw, tourProgram: plan(confirmed) };
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 5000;

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: (process.env.CLIENT_ORIGIN || "http://localhost:5173").split(","), credentials: true }));
app.use(express.json({ limit: "100kb" }));
app.use(morgan("dev"));

app.get("/api/health", (req, res) => res.json({ ok: true, store: repo.kind, claude: !!process.env.ANTHROPIC_API_KEY }));
app.get("/api/meta", (req, res) =>
  res.json({
    served: SERVED,
    states: STATES,
    minDebt: MIN_DEBT,
    backends: BACKENDS.map(({ id, name, states, min, max }) => ({ id, name, states, min, max })),
    sample: samplePlan(),
    store: repo.kind,
    claude: !!process.env.ANTHROPIC_API_KEY,
  })
);
app.use("/api/leads", leadsRouter);
app.use("/api/admin", adminRouter);
app.use("/api/chat", chatRouter);

// In production, serve the built React app from client/dist.
const dist = path.resolve(__dirname, "../../client/dist");
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^(?!\/api).*/, (req, res) => res.sendFile(path.join(dist, "index.html")));
}

app.use("/api", (req, res) => res.status(404).json({ error: "Not found" }));
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: err.message || "Server error", code: err.code });
});

await connectDB(process.env.MONGO_URI);
if (process.env.SEED_SAMPLES !== "false" && (await repo.count("sample")) === 0) {
  await repo.insertMany(buildSamples());
  console.log("[db] seeded 181 sample leads for the admin dashboard");
}
app.listen(PORT, () => console.log(`[api] Debtify API listening on http://localhost:${PORT}`));
