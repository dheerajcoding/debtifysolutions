// Partner debt-settlement companies ("backends") and their eligibility rules.
// Names and numbers are placeholders for staging.
export const BACKENDS = [
  { id: "backend-a", name: "Backend A", states: "AL AZ CA FL IN KY MD MI MO MS NC NE NM NY OK PA SD TN TX VA WA WI".split(" "), min: 10000, max: 100000, types: ["CREDIT_CARD", "PERSONAL_LOAN", "MEDICAL", "COLLECTION"], minDep: 250, terms: [24, 30, 36, 42, 48], settle: 0.5, fee: 0.25, cb: 0.12 },
  { id: "backend-b", name: "Backend B", states: "AZ CA FL GA IN MI MO NC NV NY OH PA TX VA".split(" "), min: 7500, max: 80000, types: ["CREDIT_CARD", "PERSONAL_LOAN", "MEDICAL", "COLLECTION", "PRIVATE_STUDENT"], minDep: 200, terms: [24, 36, 48], settle: 0.48, fee: 0.23, cb: 0.14 },
  { id: "backend-c", name: "Backend C", states: "AL AR CA FL IA LA MO MT NC NM OK SD TN TX UT WY".split(" "), min: 15000, max: 150000, types: ["CREDIT_CARD", "PERSONAL_LOAN"], minDep: 300, terms: [30, 36, 42, 48, 60], settle: 0.52, fee: 0.2, cb: 0.1 },
  { id: "backend-d", name: "Backend D", states: "CA FL IL MA MI NY OH PA TX VA WA".split(" "), min: 10000, max: 120000, types: ["CREDIT_CARD", "PERSONAL_LOAN", "MEDICAL", "COLLECTION"], minDep: 250, terms: [24, 36, 48], settle: 0.5, fee: 0.25, cb: 0.13 },
];

export const DEBTIFY_FEE = 0.07;
export const SERVED = [...new Set(BACKENDS.flatMap((b) => b.states))].sort();
export const MIN_DEBT = Math.min(...BACKENDS.map((b) => b.min));
export const STATES = "AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY".split(" ");

export const STEP_NAMES = ["", "Debt check", "Your situation", "Identity and permissions", "Your debts", "Budget", "Your program", "Costs and timing", "Risks and quick check", "Deposits", "Sign", "Welcome call", "Welcome"];

export const CONSENT_TYPES = [
  { type: "CREDIT_PULL", required: true },
  { type: "ESIGN", required: true },
  { type: "CALLS_TEXTS", required: false },
  { type: "SHARING", required: false },
];
export const CONSENT_VERSION = "draft-2026-09-30";

// Correct answers to the comprehension quiz (index of the right option).
export const QUIZ_ANSWERS = { fee: 2, credit: 0, sue: 1 };
