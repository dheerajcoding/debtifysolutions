import "dotenv/config";
import mongoose from "mongoose";
import { connectDB, repo } from "../config/db.js";
import { Lead } from "../models/Lead.js";
import { buildSamples } from "../services/samples.js";

// Resets the sample leads in MongoDB: npm run seed
await connectDB(process.env.MONGO_URI);
if (repo.kind !== "mongodb") {
  console.log("MongoDB is not configured; samples are seeded automatically in memory when the server starts.");
  process.exit(0);
}
await Lead.deleteMany({ source: "sample" });
await repo.insertMany(buildSamples());
console.log(`Seeded ${await repo.count("sample")} sample leads.`);
await mongoose.disconnect();
