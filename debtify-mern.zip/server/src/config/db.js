import mongoose from "mongoose";
import { Lead } from "../models/Lead.js";

// Storage layer with two interchangeable implementations:
// MongoDB (when MONGO_URI is set and reachable) or an in-memory store.

const clone = (o) => JSON.parse(JSON.stringify(o));

function memoryRepo() {
  const rows = new Map();
  return {
    kind: "memory",
    async create(doc) {
      const now = new Date().toISOString();
      const row = { createdAt: now, updatedAt: now, ...clone(doc) };
      rows.set(row.leadId, row);
      return clone(row);
    },
    async get(leadId) {
      const r = rows.get(leadId);
      return r ? clone(r) : null;
    },
    async update(leadId, patch) {
      const r = rows.get(leadId);
      if (!r) return null;
      Object.assign(r, clone(patch), { updatedAt: new Date().toISOString() });
      return clone(r);
    },
    async pushEvents(leadId, events) {
      const r = rows.get(leadId);
      if (r) r.events = [...(r.events || []), ...clone(events)].slice(-300);
    },
    async list({ source, limit = 1000 } = {}) {
      let all = [...rows.values()];
      if (source) all = all.filter((r) => (Array.isArray(source) ? source.includes(r.source) : r.source === source));
      all.sort((a, z) => String(z.createdAt).localeCompare(String(a.createdAt)));
      return clone(all.slice(0, limit)).map(({ events, ...r }) => r);
    },
    async insertMany(docs) {
      for (const d of docs) await this.create(d);
    },
    async count(source) {
      return [...rows.values()].filter((r) => !source || r.source === source).length;
    },
  };
}

function mongoRepo() {
  const strip = (d) => {
    if (!d) return null;
    const { _id, __v, ...rest } = d;
    return rest;
  };
  return {
    kind: "mongodb",
    async create(doc) {
      const created = await Lead.create(doc);
      return strip(created.toObject());
    },
    async get(leadId) {
      return strip(await Lead.findOne({ leadId }).lean());
    },
    async update(leadId, patch) {
      return strip(await Lead.findOneAndUpdate({ leadId }, { $set: patch }, { new: true }).lean());
    },
    async pushEvents(leadId, events) {
      await Lead.updateOne({ leadId }, { $push: { events: { $each: events, $slice: -300 } } });
    },
    async list({ source, limit = 1000 } = {}) {
      const q = source ? { source: Array.isArray(source) ? { $in: source } : source } : {};
      const docs = await Lead.find(q).select("-events").sort({ createdAt: -1 }).limit(limit).lean();
      return docs.map(strip);
    },
    async insertMany(docs) {
      await Lead.insertMany(docs);
    },
    async count(source) {
      return Lead.countDocuments(source ? { source } : {});
    },
  };
}

export let repo = memoryRepo();

export async function connectDB(uri) {
  if (!uri) {
    console.log("[db] MONGO_URI not set → using in-memory store (data resets on restart)");
    return repo;
  }
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 4000 });
    repo = mongoRepo();
    console.log(`[db] connected to MongoDB at ${mongoose.connection.host}/${mongoose.connection.name}`);
  } catch (e) {
    console.warn(`[db] could not reach MongoDB (${e.message}) → falling back to in-memory store`);
  }
  return repo;
}
