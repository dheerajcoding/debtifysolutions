import { Router } from "express";
import { repo } from "../config/db.js";
import { answer } from "../services/chat.js";

const router = Router();

// POST /api/chat { leadId?, lang, step, messages: [{ role: "user"|"assistant", content }] }
router.post("/", async (req, res, next) => {
  try {
    const { leadId, lang = "en", step = 1 } = req.body || {};
    const messages = (Array.isArray(req.body?.messages) ? req.body.messages : [])
      .filter((m) => m && typeof m.content === "string")
      .map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.content.slice(0, 500) }));
    if (!messages.some((m) => m.role === "user")) return res.status(400).json({ error: "Ask a question first" });
    const { reply, source, events } = await answer({ messages, lang, step });
    const evs = events.map(([tag, text]) => ({ tag, text, at: new Date().toISOString() }));
    if (leadId) {
      const lead = await repo.get(leadId);
      if (lead) {
        await repo.update(leadId, { chats: (lead.chats || 0) + 1 });
        await repo.pushEvents(leadId, evs);
      }
    }
    res.json({ reply, source, events: evs });
  } catch (e) {
    next(e);
  }
});

export default router;
