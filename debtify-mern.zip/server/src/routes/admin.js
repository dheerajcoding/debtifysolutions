import { Router } from "express";
import { repo } from "../config/db.js";
import { buildSamples } from "../services/samples.js";
import { computeStats } from "../services/stats.js";

const router = Router();

// GET /api/admin/stats?samples=1
router.get("/stats", async (req, res, next) => {
  try {
    const withSamples = req.query.samples !== "0";
    const real = await repo.list({ source: ["demo", "web"], limit: 1000 });
    const samples = withSamples ? await repo.list({ source: "sample", limit: 1000 }) : [];
    res.json({ ...computeStats([...samples, ...real], real), store: repo.kind, sampleCount: samples.length });
  } catch (e) {
    next(e);
  }
});

// GET /api/admin/leads?source=demo
router.get("/leads", async (req, res, next) => {
  try {
    const source = req.query.source || ["demo", "web"];
    res.json({ leads: await repo.list({ source, limit: Math.min(500, Number(req.query.limit) || 100) }) });
  } catch (e) {
    next(e);
  }
});

// POST /api/admin/seed — (re)creates the sample leads if missing
router.post("/seed", async (req, res, next) => {
  try {
    const n = await repo.count("sample");
    if (n === 0) await repo.insertMany(buildSamples());
    res.json({ ok: true, samples: await repo.count("sample") });
  } catch (e) {
    next(e);
  }
});

export default router;
