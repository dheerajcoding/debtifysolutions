import { Router } from "express";
import crypto from "node:crypto";
import { repo } from "../config/db.js";
import { CONSENT_TYPES, CONSENT_VERSION, MIN_DEBT, QUIZ_ANSWERS, SERVED, STATES, STEP_NAMES } from "../data/backends.js";
import { route, tagTradeline } from "../services/routing.js";
import { idCheck, softPull, welcomeCall } from "../services/vendors.js";

const router = Router();
const usd = (n) => "$" + Math.round(n).toLocaleString("en-US");
const pad = (n) => String(n).padStart(2, "0");
const newId = () => "ld_" + Date.now().toString(36) + crypto.randomBytes(2).toString("hex");

class HttpError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

// Wraps a handler: loads the lead, collects log events, saves them, and returns
// { lead, events, ...extra } so the client can show the "behind the scenes" log.
const withLead = (fn) => async (req, res, next) => {
  try {
    const lead = await repo.get(req.params.id);
    if (!lead) throw new HttpError(404, "Lead not found", "NOT_FOUND");
    const events = [];
    const log = (tag, text) => events.push({ tag, text, at: new Date().toISOString() });
    const ctx = { lead, log, patch: {}, extra: {} };
    await fn(req, ctx);
    let saved = lead;
    if (Object.keys(ctx.patch).length) saved = await repo.update(lead.leadId, ctx.patch);
    if (events.length) await repo.pushEvents(lead.leadId, events);
    res.json({ lead: publicLead(saved), events, ...ctx.extra });
  } catch (e) {
    next(e);
  }
};

function publicLead(l) {
  if (!l) return null;
  const { events, ...rest } = l;
  return rest;
}

function goStep(ctx, n) {
  ctx.patch.step = n;
  ctx.patch.maxStep = Math.max(ctx.lead.maxStep || 1, n);
  ctx.log("EVENT", `step_view ${pad(n)} ${STEP_NAMES[n]} · ${(ctx.patch.lang || ctx.lead.lang || "en").toUpperCase()}`);
}

function decline(ctx, code) {
  Object.assign(ctx.patch, { status: "DECLINED", dropReason: code, step: 0 });
  ctx.log("DB", `lead ${ctx.lead.leadId} → DECLINED (${code})`);
}

const requireProgram = (lead) => {
  if (!lead.program?.monthlyDeposit) throw new HttpError(409, "This lead has no matched program yet", "NO_PROGRAM");
};

// ---------- create ----------
router.post("/", async (req, res, next) => {
  try {
    const { state, debt, lang = "en", source = "web", persona = null } = req.body || {};
    if (!STATES.includes(state)) throw new HttpError(400, "Choose a valid US state", "BAD_STATE");
    const d = Math.max(0, Math.round(Number(debt) || 0));
    const events = [];
    const log = (tag, text) => events.push({ tag, text, at: new Date().toISOString() });
    const lead = {
      leadId: newId(), source: ["demo", "web"].includes(source) ? source : "web", persona, lang: lang === "es" ? "es" : "en",
      state, debt: d, step: 1, maxStep: 1, status: "STARTED", dropReason: null, hardship: {}, tradelines: [], program: null,
      feeStatus: "NOT_EARNED", clarity: {}, consents: [], events: [],
    };
    log("DB", `lead ${lead.leadId} created · ${state} · est. ${usd(d)} · ${lead.lang.toUpperCase()}`);
    const ctx = { lead, log, patch: {} };
    if (!SERVED.includes(state)) decline(ctx, "STATE_NOT_SERVED");
    else if (d < MIN_DEBT) decline(ctx, "DEBT_UNDER_MIN");
    else goStep(ctx, 2);
    Object.assign(lead, ctx.patch, { events });
    const saved = await repo.create(lead);
    res.status(201).json({ lead: publicLead(saved), events });
  } catch (e) {
    next(e);
  }
});

router.get("/:id", withLead(async () => {}));
router.get("/:id/events", async (req, res, next) => {
  try {
    const l = await repo.get(req.params.id);
    if (!l) throw new HttpError(404, "Lead not found");
    res.json({ events: l.events || [] });
  } catch (e) {
    next(e);
  }
});

// ---------- small updates: step navigation, language, hardship, clarity ----------
router.patch("/:id", withLead(async (req, ctx) => {
  const { step, lang, hardship, clarity } = req.body || {};
  if (lang && ["en", "es"].includes(lang) && lang !== ctx.lead.lang) {
    ctx.patch.lang = lang;
    ctx.log("UX", `language → ${lang === "es" ? "Español" : "English"}`);
  }
  if (hardship && typeof hardship === "object") {
    const h = {};
    for (const k of ["reason", "goal", "timing"]) if (Number.isInteger(hardship[k])) h[k] = hardship[k];
    ctx.patch.hardship = { ...ctx.lead.hardship, ...h };
  }
  if (clarity && typeof clarity === "object") {
    const next = { ...ctx.lead.clarity };
    for (const [id, v] of Object.entries(clarity)) {
      if (["clear", "simpler"].includes(v)) {
        next[id] = v;
        ctx.log("UX", `clarity · ${id}: ${v === "simpler" ? "asked to explain simpler" : "marked clear"}`);
      }
    }
    ctx.patch.clarity = next;
  }
  if (Number.isInteger(step) && step >= 1 && step <= 12) {
    // Only allow moving back, or forward by one screen that has no server-side gate.
    const freeForward = { 2: 3, 6: 7 };
    const cur = ctx.lead.step;
    if (step <= ctx.lead.maxStep || freeForward[cur] === step) {
      if (cur === 2 && step === 3) {
        const h = ctx.patch.hardship || ctx.lead.hardship || {};
        if (Object.keys(h).length < 3) throw new HttpError(400, "Answer all three questions", "HARDSHIP_INCOMPLETE");
        ctx.log("DB", `hardship saved: reason ${h.reason} · goal ${h.goal} · timing ${h.timing}`);
      }
      goStep(ctx, step);
    } else throw new HttpError(409, "Finish the current step first", "STEP_LOCKED");
  }
}));

// ---------- step 3: identity, consents, ID check and soft credit pull ----------
router.post("/:id/identity", withLead(async (req, ctx) => {
  const b = req.body || {};
  const consents = b.consents || {};
  for (const c of CONSENT_TYPES) {
    if (c.required && !consents[c.type]) {
      ctx.log("GUARD", `blocked: ${c.type} consent is required`);
      throw new HttpError(400, `${c.type} consent is required`, "CONSENT_REQUIRED");
    }
  }
  const ssn = String(b.ssn || "").replace(/\D/g, "");
  if (ssn.length !== 9) throw new HttpError(400, "SSN must be 9 digits", "BAD_SSN");
  for (const k of ["first", "last", "email", "phone"]) if (!String(b[k] || "").trim()) throw new HttpError(400, `${k} is required`, "MISSING_FIELD");

  const lang = ctx.lead.lang || "en";
  const texts = b.consentTexts || {};
  ctx.patch.consents = CONSENT_TYPES.map((c) => {
    const granted = !!consents[c.type];
    ctx.log("CONSENT", `${c.type} ${granted ? "granted" : "declined"} · ${lang.toUpperCase()} text v ${CONSENT_VERSION} · sha256 stored`);
    return { type: c.type, granted, lang, version: CONSENT_VERSION, textHash: crypto.createHash("sha256").update(String(texts[c.type] || c.type)).digest("hex"), at: new Date() };
  });
  Object.assign(ctx.patch, { first: b.first.trim(), last: b.last.trim(), email: b.email.trim(), phone: String(b.phone).replace(/\D/g, ""), ssnLast4: ssn.slice(-4), share: !!consents.SHARING });

  const kyc = await idCheck(ssn);
  ctx.patch.kyc = kyc;
  ctx.log("VENDOR", `ID check (mock) → ${kyc}`);
  if (kyc === "FAIL") return decline(ctx, "KYC_FAILED");

  const raw = await softPull(ssn);
  if (!raw) {
    ctx.log("VENDOR", "soft pull → no credit file");
    return decline(ctx, "NO_CREDIT_FILE");
  }
  ctx.log("VENDOR", `soft pull (mock) → ${raw.length} accounts, score 598`);
  const tradelines = raw.map(tagTradeline);
  tradelines.forEach((tl) => ctx.log(tl.needsReview ? "AI" : "ROUTING", `${tl.creditor}: ${tl.type}${tl.needsReview ? " (unclear → ask user)" : ""} → ${tl.enrollable ? "enrollable" : "excluded"}`));
  ctx.log("DB", "SSN dropped after vendor calls; only the last 4 digits are kept");
  Object.assign(ctx.patch, { tradelines, status: "QUALIFIED" });
  goStep(ctx, 4);
}));

// ---------- step 4: choose debts, confirm unclear accounts ----------
router.put("/:id/debts", withLead(async (req, ctx) => {
  const picks = Array.isArray(req.body?.tradelines) ? req.body.tradelines : [];
  const allowed = ["MEDICAL", "CREDIT_CARD", "COLLECTION"];
  const tradelines = ctx.lead.tradelines.map((tl) => {
    const p = picks.find((z) => z.tlId === tl.tlId);
    if (!p) return tl;
    const next = { ...tl };
    if (tl.type === "OTHER" || tl.confirmed) {
      if (allowed.includes(p.confirmed)) {
        if (next.confirmed !== p.confirmed) ctx.log("DB", `${tl.creditor} confirmed by user as ${p.confirmed}`);
        Object.assign(next, { confirmed: p.confirmed, type: p.confirmed, enrollable: true });
      } else if (!p.confirmed && !tl.confirmed) next.enrollable = false;
    }
    next.selected = next.enrollable ? !!p.selected : false;
    return next;
  });
  const total = tradelines.filter((z) => z.selected && z.enrollable).reduce((s, z) => s + z.balance, 0);
  ctx.patch.tradelines = tradelines;
  ctx.extra.total = total;
  if (req.body?.advance) {
    if (!total) throw new HttpError(400, "Choose at least one debt", "NO_DEBTS");
    ctx.log("DB", `debts selected: ${usd(total)}`);
    goStep(ctx, 5);
  }
}));

// ---------- step 5: budget → routing engine ----------
router.post("/:id/budget", withLead(async (req, ctx) => {
  const income = Math.max(0, Number(req.body?.income) || 0);
  const expenses = Math.max(0, Number(req.body?.expenses) || 0);
  if (req.body?.bankLinked && !ctx.lead.bankLinked) ctx.log("VENDOR", "Plaid Link (mock) → account linked");
  Object.assign(ctx.patch, { income, expenses, bankLinked: !!req.body?.bankLinked || ctx.lead.bankLinked });
  if (req.body?.linkOnly) return;
  const r = route({ state: ctx.lead.state, debts: ctx.lead.tradelines, income, expenses });
  r.rejected.forEach((z) => ctx.log("ROUTING", `${z.id}: rejected (${z.r.join(", ")})`));
  if (r.decision !== "MATCH") {
    ctx.log("ROUTING", `no fit → ${r.reasonCode}`);
    return decline(ctx, r.reasonCode);
  }
  r.scores.forEach(([n, s]) => ctx.log("ROUTING", `${n}: fits · payment-2 score ${s}`));
  Object.assign(ctx.patch, { program: r.program, backend: r.program.backendId, status: "MATCHED" });
  ctx.log("ROUTING", `matched ${r.program.backendName}: ${usd(r.program.monthlyDeposit)}/mo × ${r.program.termMonths}`);
  goStep(ctx, 6);
}));

// ---------- step 7: costs acknowledged ----------
router.post("/:id/acknowledge", withLead(async (req, ctx) => {
  requireProgram(ctx.lead);
  if (!req.body?.acknowledged) throw new HttpError(400, "Please confirm you've read this", "ACK_REQUIRED");
  ctx.patch.costsAcknowledged = true;
  ctx.log("CONSENT", `costs and timing acknowledged · ${(ctx.lead.lang || "en").toUpperCase()}`);
  goStep(ctx, 8);
}));

// ---------- step 8: comprehension quiz (graded on the server) ----------
router.post("/:id/quiz", withLead(async (req, ctx) => {
  requireProgram(ctx.lead);
  const answers = req.body?.answers || {};
  const wrong = Object.entries(QUIZ_ANSWERS).filter(([id, c]) => answers[id] !== c).map(([id]) => id);
  const attempts = (ctx.lead.quizAttempts || 0) + 1;
  ctx.patch.quizAttempts = attempts;
  ctx.extra.wrong = wrong;
  if (wrong.length) {
    ctx.log("AI", `quiz attempt ${attempts}: ${wrong.length} wrong → re-explained`);
    return;
  }
  ctx.log("EVENT", `quiz passed on attempt ${attempts}`);
  goStep(ctx, 9);
}));

// ---------- step 9: deposit account + first draft date ----------
router.post("/:id/deposits", withLead(async (req, ctx) => {
  requireProgram(ctx.lead);
  if (req.body?.linkOnly) {
    ctx.patch.depositAccountLinked = true;
    ctx.log("VENDOR", "Plaid Link (mock) → deposit account verified");
    return;
  }
  if (!ctx.lead.depositAccountLinked) throw new HttpError(400, "Link your bank account first", "BANK_REQUIRED");
  const draftDate = String(req.body?.draftDate || "");
  const d = new Date(draftDate + "T12:00:00Z").getTime();
  if (!d || d < Date.now() + 3 * 864e5 - 864e5 / 2 || d > Date.now() + 45 * 864e5) throw new HttpError(400, "Choose a date between 3 and 45 days from today", "BAD_DATE");
  ctx.patch.draftDate = draftDate;
  ctx.log("DB", `first draft date ${draftDate}`);
  goStep(ctx, 10);
  ctx.log("VENDOR", `e-sign envelope created (${(ctx.lead.lang || "en").toUpperCase()} summary)`);
}));

// ---------- step 10: sign or decline ----------
router.post("/:id/sign", withLead(async (req, ctx) => {
  requireProgram(ctx.lead);
  if (!req.body?.accept) {
    ctx.log("EVENT", "declined to sign");
    return decline(ctx, "ESIGN_DECLINED");
  }
  ctx.log("VENDOR", "envelope signed");
  Object.assign(ctx.patch, { status: "SIGNED", signedAt: new Date() });
  goStep(ctx, 11);
}));

// ---------- step 11: AI welcome call ----------
router.post("/:id/call", withLead(async (req, ctx) => {
  requireProgram(ctx.lead);
  if (ctx.lead.status !== "SIGNED") throw new HttpError(409, "Sign the agreement first", "NOT_SIGNED");
  const l = ctx.lead;
  ctx.log("VENDOR", `AI voice call (mock, ${l.lang === "es" ? "Spanish" : "English"}) → dialing ***${String(l.phone).slice(-4)}, recording on`);
  const call = welcomeCall({ first: l.first, phone: l.phone, program: l.program, lang: l.lang });
  ctx.extra.call = call;
  ctx.patch.callResult = call.result;
  if (call.result === "NEEDS_HUMAN") {
    ctx.patch.dropReason = "CALL_NEEDS_HUMAN";
    ctx.log("GUARD", "promise-of-result detected → exception desk");
    return;
  }
  ctx.log("VENDOR", "call PASSED");
  ctx.log("BACKEND", `enrollment POSTed to ${l.program.backendName} (HMAC-signed)`);
  ctx.patch.status = "ENROLLED";
  goStep(ctx, 12);
}));

// ---------- backend webhooks (simulated from the demo control) ----------
router.post("/:id/backend-event", withLead(async (req, ctx) => {
  requireProgram(ctx.lead);
  const type = req.body?.type;
  const fee = usd(ctx.lead.program.debtifyFee);
  if (type === "PAYMENT1_CLEARED" && ctx.lead.feeStatus === "NOT_EARNED") {
    Object.assign(ctx.patch, { feeStatus: "EARNED", status: "PAYMENT1_CLEARED" });
    ctx.log("BACKEND", `PAYMENT1_CLEARED → fee ${fee} EARNED`);
  } else if (type === "PAYMENT2_CLEARED" && ctx.lead.feeStatus === "EARNED") {
    Object.assign(ctx.patch, { feeStatus: "FINAL", status: "PAYMENT2_CLEARED" });
    ctx.log("BACKEND", "PAYMENT2_CLEARED → fee FINAL");
  } else if (type === "PAYMENT2_FAILED" && ctx.lead.feeStatus === "EARNED") {
    Object.assign(ctx.patch, { feeStatus: "CLAWED_BACK", status: "CLAWBACK" });
    ctx.log("BACKEND", "PAYMENT2_FAILED → fee CLAWED BACK");
  } else throw new HttpError(409, `Event ${type} not valid when fee is ${ctx.lead.feeStatus}`, "BAD_EVENT");
}));

// ---------- talk to a person / abandon ----------
router.post("/:id/person", withLead(async (req, ctx) => {
  ctx.patch.person = true;
  ctx.log("EVENT", "talk_to_person → exception desk");
}));

router.post("/:id/abandon", withLead(async (req, ctx) => {
  const l = ctx.lead;
  if (l.step > 0 && l.step < 12 && !l.dropReason) {
    ctx.patch.dropReason = "LEFT_AT_STEP_" + pad(l.step);
    ctx.log("EVENT", `exit at step ${l.step} → ${ctx.patch.dropReason}`);
  }
}));

router.post("/:id/chat-count", withLead(async (req, ctx) => {
  ctx.patch.chats = (ctx.lead.chats || 0) + 1;
}));

export { HttpError };
export default router;
